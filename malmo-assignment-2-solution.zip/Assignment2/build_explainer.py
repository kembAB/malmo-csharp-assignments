#!/usr/bin/env python3
"""Builds the explainer PDF for Assignment 2.

Hard rule for this document: the prose written for the
explainer contains no parentheses at all. Every prose
string is collected and checked before the PDF is built.
Code and program output are quoted verbatim and are
exempt from the rule.
"""

from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (PageBreak, Paragraph, Preformatted,
                                SimpleDocTemplate, Spacer)

BASE = Path(__file__).resolve().parent
PDF_PATH = BASE / "malmo-csharp-assignment-2-explainer.pdf"

PROSE = []


def check_prose(text):
    PROSE.append(text)
    assert "(" not in text, text
    assert ")" not in text, text
    return text


STYLES = {
    "title": ParagraphStyle("title", fontName="Helvetica-Bold",
                            fontSize=22, leading=27,
                            spaceAfter=6),
    "subtitle": ParagraphStyle("subtitle", fontName="Helvetica",
                               fontSize=13, leading=17,
                               spaceAfter=4),
    "author": ParagraphStyle("author", fontName="Helvetica-Bold",
                             fontSize=12, leading=16,
                             spaceAfter=14),
    "h1": ParagraphStyle("h1", fontName="Helvetica-Bold",
                         fontSize=15, leading=19, spaceBefore=14,
                         spaceAfter=6),
    "h2": ParagraphStyle("h2", fontName="Helvetica-Bold",
                         fontSize=11.5, leading=15,
                         spaceBefore=12, spaceAfter=4),
    "body": ParagraphStyle("body", fontName="Helvetica",
                           fontSize=10.5, leading=15,
                           spaceAfter=6),
    "code": ParagraphStyle("code", fontName="Courier",
                           fontSize=7, leading=9),
}


def heading(text, level=1):
    check_prose(text)
    return Paragraph(text, STYLES["h1" if level == 1 else "h2"])


def para(text):
    check_prose(text)
    return Paragraph(text, STYLES["body"])


def code_block(text):
    return Preformatted(escape(text.rstrip("\n")), STYLES["code"])


def build():
    story = []

    story.append(Paragraph(check_prose(
        "Assignment 2 - Apu's Animal Motel, Version 2"),
        STYLES["title"]))
    story.append(Paragraph(check_prose(
        "Programming in C# II - Malmö University"),
        STYLES["subtitle"]))
    story.append(Paragraph(check_prose(
        "Abel Haile Magicho"), STYLES["author"]))

    story.append(heading("What the assignment asks"))
    story.append(para(
        "The assignment rebuilds the Animal Motel from the "
        "first assignment as a second version. <b>The heart "
        "of the task is polymorphism.</b> The program must "
        "train the use of interfaces, abstract classes and "
        "dynamic binding, so shared animal behaviour is "
        "declared once at the top of the class tree and "
        "each species supplies its own version lower down."))
    story.append(para(
        "Every species is classified by what it eats. An "
        "enum named EaterType carries the three values "
        "Carnivore, Herbivore and Omnivore. Every animal "
        "also has a name, an id and a gender, and gender "
        "is held in a second enum named GenderType."))
    story.append(para(
        "Every species provides a feeding plan. The plan "
        "lives in a new class named FoodSchedule, the "
        "lines of the plan are hard coded inside each "
        "species class, and the form shows the lines for "
        "the animal the user selects, together with the "
        "eater type of that animal."))
    story.append(para(
        "An interface named IAnimal sets the rules for "
        "all animals. It declares the Id, Name and Gender "
        "properties together with methods for the eater "
        "type, the food schedule and the species name. "
        "<b>The abstract class Animal implements the "
        "interface.</b> The three methods are declared "
        "abstract in Animal, because the answers depend "
        "on the concrete species and not on the base class."))
    story.append(para(
        "The category classes Mammal, Bird and Insect "
        "must be abstract. Each category adds one shared "
        "attribute, and each concrete species adds one "
        "attribute of its own beside its hard coded food "
        "schedule. A manager class keeps the animal list "
        "and gives every added animal a unique id."))
    story.append(para(
        "<b>Two higher grade items are included as well.</b>"))
    story.append(para(
        "For grade B, the animal manager sorts the list "
        "in two ways. The default sort compares animals "
        "by name through the IComparable interface of "
        "Animal, and a separate comparer class sorts by "
        "species through IComparer. The user picks the "
        "sort in the form."))
    story.append(para(
        "For grade A, the animals are shown in a ListView "
        "control. The ListView carries columns for Id, "
        "Name, Age, Gender, Species, Category and Eater "
        "Type, and it refreshes after every addition and "
        "after every sort."))

    story.append(heading("How the code answers, step by step"))
    story.append(para(
        "Step 1 - The Enums.cs file defines GenderType "
        "with Male, Female and Unknown, and EaterType "
        "with Carnivore, Herbivore and Omnivore."))
    story.append(para(
        "Step 2 - The IAnimal.cs file holds the interface "
        "on its own. It fixes the contract every animal "
        "must honour, without fixing any implementation."))
    story.append(para(
        "Step 3 - FoodSchedule keeps its lines in a "
        "strictly private list named foodDescriptionList. "
        "A Count property reports the number of lines, "
        "ValidateIndex returns false for an index outside "
        "the list, and further methods add a line, read "
        "one line, return all lines as a string array and "
        "join the lines in ToString."))
    story.append(para(
        "Step 4 - The abstract class Animal stores Id, "
        "Name, Age and Gender and declares the eater "
        "type, food schedule and species methods as "
        "abstract. Its ToString gives the general animal "
        "info. <b>Animal also carries the grade B default "
        "sort.</b> Its CompareTo method compares by name "
        "and ignores letter case."))
    story.append(para(
        "Step 5 - The abstract category classes sit "
        "between Animal and the species. Mammal adds "
        "NumberOfTeeth, Bird adds FlyingSpeed and Insect "
        "adds NumberOfLegs, and each one reports its own "
        "category name."))
    story.append(para(
        "Step 6 - Six concrete species follow. Dog and "
        "Cat extend Mammal, Dove and Eagle extend Bird, "
        "and Butterfly and Bee extend Insect. Each "
        "species overrides the three abstract methods, "
        "hard codes realistic feeding lines and carries "
        "one species attribute, such as the tail length "
        "of a dog, the breed of a cat or the wing color "
        "of a butterfly."))
    story.append(para(
        "Step 7 - AnimalManager guards the motel list. "
        "The list and the id counter are strictly "
        "private, AddAnimal stamps a unique id on each "
        "new animal, GetAnimalAt reads one animal at a "
        "time, Count reports the size of the list and a "
        "string array method returns every info string."))
    story.append(para(
        "Step 8 - The grade B sorting has two routes, "
        "and both are marked with comments in the code. "
        "One manager method sorts with no argument and "
        "the list then uses CompareTo from Animal. The "
        "other manager method takes an IComparer and the "
        "form passes an AnimalSpeciesComparer, which "
        "orders by species name and then by animal name."))
    story.append(para(
        "Step 9 - MainForm is the only class that reads "
        "input and shows output. A category list drives "
        "a species list, so Mammal offers Dog and Cat, "
        "Bird offers Dove and Eagle, and Insect offers "
        "Butterfly and Bee. The category attribute label "
        "and the species attribute label follow the "
        "selection, so the species field is the extra "
        "field the assignment shows for a butterfly, "
        "here serving every species."))
    story.append(para(
        "Step 10 - The Add button builds the concrete "
        "animal and stores it in a variable of type "
        "Animal. <b>That single reference is the dynamic "
        "binding point of the whole program.</b> Later "
        "calls for the eater type, the species and the "
        "food schedule run the code of the real species "
        "behind the reference."))
    story.append(para(
        "Step 11 - The grade A ListView shows one row "
        "per animal with the seven required columns. "
        "Two radio buttons sort by name or by species "
        "through the two manager routes, and the "
        "ListView is rebuilt after each sort. Selecting "
        "a row fills the food schedule list and the "
        "eater type label."))
    story.append(para(
        "Step 12 - The form starts empty of sample data, "
        "validates every field before an animal is "
        "created and answers bad input with a message "
        "instead of a crash. A separate console harness "
        "links the same model files and proves the "
        "model without the form."))

    story.append(PageBreak())
    story.append(heading("The full code"))
    story.append(para(
        "Every source file of the project follows "
        "verbatim, in reading order. The two project "
        "files are listed with their code files. <b>The "
        "last file, the harness Program.cs, is a test "
        "harness and not part of the form app.</b> It "
        "links the same model files and prints the run "
        "shown after the code."))

    files = [
        "AnimalMotel/AnimalMotel.csproj",
        "AnimalMotel/Enums.cs",
        "AnimalMotel/IAnimal.cs",
        "AnimalMotel/FoodSchedule.cs",
        "AnimalMotel/Animals/Animal.cs",
        "AnimalMotel/Animals/Mammal.cs",
        "AnimalMotel/Animals/Bird.cs",
        "AnimalMotel/Animals/Insect.cs",
        "AnimalMotel/Animals/Dog.cs",
        "AnimalMotel/Animals/Cat.cs",
        "AnimalMotel/Animals/Dove.cs",
        "AnimalMotel/Animals/Eagle.cs",
        "AnimalMotel/Animals/Butterfly.cs",
        "AnimalMotel/Animals/Bee.cs",
        "AnimalMotel/Managers/AnimalSpeciesComparer.cs",
        "AnimalMotel/Managers/AnimalManager.cs",
        "AnimalMotel/Program.cs",
        "AnimalMotel/MainForm.cs",
        "AnimalMotel/MainForm.Designer.cs",
        "Harness/Harness.csproj",
        "Harness/Program.cs - test harness",
    ]
    for label in files:
        path = BASE / label.split(" - ")[0]
        story.append(Paragraph(escape(label), STYLES["h2"]))
        story.append(code_block(path.read_text(encoding="utf-8")))
        story.append(Spacer(1, 4 * mm))

    story.append(PageBreak())
    story.append(heading("The real run output"))
    story.append(para(
        "The harness was built and run with the .NET "
        "SDK, and the console text was saved without "
        "edits into output.txt. <b>The two sorted lists "
        "prove both sorting routes.</b> The name order "
        "and the species order are clearly different, "
        "and each animal line still carries its own "
        "species data after both sorts."))
    output_text = (BASE / "output.txt").read_text(
        encoding="utf-8")
    story.append(code_block(output_text))

    story.append(heading("How to run"))
    story.append(para(
        "Open a terminal in the Assignment2 folder and "
        "build the form project with the .NET 8 SDK."))
    story.append(code_block(
        "dotnet build AnimalMotel/AnimalMotel.csproj"))
    story.append(para(
        "The build must end with zero errors. The form "
        "app is a Windows Forms app and runs on Windows. "
        "The test harness is a plain console project, "
        "and the next command runs it on any system "
        "where the SDK is installed."))
    story.append(code_block(
        "dotnet run --project Harness/Harness.csproj"))
    story.append(para(
        "In the form, pick a category and a species, "
        "fill every field and press Add animal. Repeat "
        "for more animals, then use the two radio "
        "buttons to sort the ListView and click a row "
        "to read its food schedule."))

    story.append(heading("Glossary"))
    glossary = [
        "<b>Abstract class</b> - a class that cannot be "
        "created on its own and that hands duties to its "
        "subclasses as abstract methods.",
        "<b>Comparer</b> - a small helper class that "
        "decides the order of two objects for a sort, "
        "used here for the sort by species.",
        "<b>Dynamic binding</b> - the choice of method "
        "version at run time, based on the real object "
        "behind a base class reference.",
        "<b>Encapsulation</b> - keeping fields private "
        "and letting outside code work through properties "
        "and methods only.",
        "<b>Enum</b> - a named set of fixed values, such "
        "as the three eater types or the three genders.",
        "<b>Food schedule</b> - the feeding plan of one "
        "species, stored as a list of text lines in a "
        "FoodSchedule object.",
        "<b>Interface</b> - a contract that names the "
        "properties and methods a class must provide, "
        "without providing the code for them.",
        "<b>ListView</b> - a Windows Forms control that "
        "shows items in rows with several columns, used "
        "here for the animal list of grade A.",
        "<b>Polymorphism</b> - the ability of one call "
        "through a shared type to run different code "
        "depending on the real object that receives it.",
    ]
    for entry in glossary:
        story.append(para(entry))

    for text in PROSE:
        assert "(" not in text and ")" not in text, text

    doc = SimpleDocTemplate(
        str(PDF_PATH), pagesize=A4,
        leftMargin=16 * mm, rightMargin=16 * mm,
        topMargin=16 * mm, bottomMargin=16 * mm,
        title="Assignment 2 - Apu's Animal Motel",
        author="Abel Haile Magicho")
    doc.build(story)
    print("Built:", PDF_PATH)


if __name__ == "__main__":
    build()

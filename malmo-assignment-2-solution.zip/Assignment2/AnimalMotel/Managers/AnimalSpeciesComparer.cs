using System;
using System.Collections.Generic;
using AnimalMotel.Animals;

namespace AnimalMotel.Managers
{
    /// <summary>
    /// VG part for grade B: the second way of sorting.
    /// This comparer orders animals by species name, so all
    /// bees come before all butterflies, and so on. Animals
    /// of the same species are ordered by name, so the
    /// result is always fully decided.
    /// </summary>
    public class AnimalSpeciesComparer : IComparer<Animal>
    {
        public int Compare(Animal x, Animal y)
        {
            if (x == null && y == null)
                return 0;
            if (x == null)
                return -1;
            if (y == null)
                return 1;

            int result = string.Compare(x.GetSpecies(),
                y.GetSpecies(),
                StringComparison.OrdinalIgnoreCase);

            if (result == 0)
            {
                result = string.Compare(x.Name, y.Name,
                    StringComparison.OrdinalIgnoreCase);
            }

            return result;
        }
    }
}

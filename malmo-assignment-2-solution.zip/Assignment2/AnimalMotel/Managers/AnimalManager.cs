using System.Collections.Generic;
using AnimalMotel.Animals;

namespace AnimalMotel.Managers
{
    /// <summary>
    /// Keeps the list of animals checked in at the motel.
    /// The list and the id counter are strictly private.
    /// Outside code reaches the animals only through the
    /// methods of this class, one animal at a time.
    /// </summary>
    public class AnimalManager
    {
        private List<Animal> animalList;
        private int nextId;

        public AnimalManager()
        {
            animalList = new List<Animal>();
            nextId = 1;
        }

        /// <summary>The number of animals in the motel.</summary>
        public int Count
        {
            get { return animalList.Count; }
        }

        /// <summary>
        /// Gives the animal a unique id and adds it to the
        /// list. A missing animal is refused.
        /// </summary>
        public bool AddAnimal(Animal animal)
        {
            if (animal == null)
                return false;

            animal.Id = nextId.ToString();
            nextId++;
            animalList.Add(animal);
            return true;
        }

        /// <summary>
        /// Reads the animal at the given index. An invalid
        /// index gives null instead of a crash.
        /// </summary>
        public Animal GetAnimalAt(int index)
        {
            if (index < 0 || index >= animalList.Count)
                return null;

            return animalList[index];
        }

        /// <summary>Every animal info string as a string array.</summary>
        public string[] GetAnimalListAsStringArray()
        {
            List<string> lines = new List<string>();

            foreach (Animal animal in animalList)
                lines.Add(animal.ToString());

            return lines.ToArray();
        }

        /// <summary>
        /// VG grade B, sort one: the default sort. The list
        /// sort calls CompareTo on Animal, which compares
        /// by name.
        /// </summary>
        public void SortAnimals()
        {
            animalList.Sort();
        }

        /// <summary>
        /// VG grade B, sort two: sort with a comparer given
        /// by the caller, for example an
        /// AnimalSpeciesComparer for a sort by species.
        /// </summary>
        public void SortAnimals(IComparer<Animal> comparer)
        {
            if (comparer != null)
                animalList.Sort(comparer);
        }
    }
}

using System;
using System.Windows.Forms;
using AnimalMotel.Animals;
using AnimalMotel.Managers;

namespace AnimalMotel
{
    /// <summary>
    /// The only class in the project that reads input and
    /// shows output. All animal data lives in the
    /// AnimalManager, and every animal is handled through
    /// an Animal reference, so the form never needs to know
    /// which concrete species it is showing. The species
    /// answers arrive by dynamic binding.
    /// </summary>
    public partial class MainForm : Form
    {
        private readonly AnimalManager animalManager;

        // The species offered for the selected category.
        private readonly string[] mammalSpecies = { "Dog", "Cat" };
        private readonly string[] birdSpecies = { "Dove", "Eagle" };
        private readonly string[] insectSpecies =
            { "Butterfly", "Bee" };

        public MainForm()
        {
            InitializeComponent();
            animalManager = new AnimalManager();
            InitializeGui();
        }

        private void InitializeGui()
        {
            lstCategories.Items.AddRange(
                new object[] { "Mammal", "Bird", "Insect" });
            cmbGender.Items.AddRange(
                Enum.GetNames(typeof(GenderType)));
            cmbGender.SelectedIndex = 2;
            lstCategories.SelectedIndex = 0;
        }

        private void lstCategories_SelectedIndexChanged(
            object sender, EventArgs e)
        {
            UpdateSpeciesList();
        }

        private void UpdateSpeciesList()
        {
            lstSpecies.Items.Clear();

            switch (SelectedCategory())
            {
                case "Bird":
                    lstSpecies.Items.AddRange(birdSpecies);
                    break;
                case "Insect":
                    lstSpecies.Items.AddRange(insectSpecies);
                    break;
                default:
                    lstSpecies.Items.AddRange(mammalSpecies);
                    break;
            }

            if (lstSpecies.Items.Count > 0)
                lstSpecies.SelectedIndex = 0;

            UpdateAttributeLabels();
        }

        private void lstSpecies_SelectedIndexChanged(
            object sender, EventArgs e)
        {
            UpdateAttributeLabels();
        }

        /// <summary>
        /// The two attribute labels follow the selection.
        /// The category label names the category attribute,
        /// and the species label names the species attribute.
        /// This species field is the extra field that the
        /// assignment shows for butterfly objects, here
        /// serving every species with its own attribute.
        /// </summary>
        private void UpdateAttributeLabels()
        {
            switch (SelectedCategory())
            {
                case "Bird":
                    lblCategoryAttribute.Text = "Flying speed km/h:";
                    break;
                case "Insect":
                    lblCategoryAttribute.Text = "Number of legs:";
                    break;
                default:
                    lblCategoryAttribute.Text = "Number of teeth:";
                    break;
            }

            switch (SelectedSpecies())
            {
                case "Cat":
                    lblSpeciesAttribute.Text = "Breed:";
                    break;
                case "Dove":
                    lblSpeciesAttribute.Text = "Wing span cm:";
                    break;
                case "Eagle":
                    lblSpeciesAttribute.Text = "Beak length cm:";
                    break;
                case "Butterfly":
                    lblSpeciesAttribute.Text = "Wing color:";
                    break;
                case "Bee":
                    lblSpeciesAttribute.Text = "Number of wings:";
                    break;
                default:
                    lblSpeciesAttribute.Text = "Tail length cm:";
                    break;
            }
        }

        private string SelectedCategory()
        {
            if (lstCategories.SelectedItem == null)
                return "Mammal";

            return lstCategories.SelectedItem.ToString();
        }

        private string SelectedSpecies()
        {
            if (lstSpecies.SelectedItem == null)
                return "Dog";

            return lstSpecies.SelectedItem.ToString();
        }

        private GenderType SelectedGender()
        {
            GenderType gender;
            if (cmbGender.SelectedItem != null && Enum.TryParse(
                    cmbGender.SelectedItem.ToString(), out gender))
                return gender;

            return GenderType.Unknown;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Animal animal = CreateAnimal();

            if (animal == null)
                return;

            // Dynamic binding in action: the manager and the
            // form only ever see an Animal, while the object
            // behind the reference is a Dog, a Bee, and so on.
            animalManager.AddAnimal(animal);
            RefreshListView(animalManager.Count - 1);
            txtName.Clear();
            txtName.Focus();
        }

        /// <summary>
        /// Reads and validates the input fields and builds
        /// the concrete animal. Bad input gives a message
        /// and a null result, never a crash.
        /// </summary>
        private Animal CreateAnimal()
        {
            string name = txtName.Text.Trim();
            if (name.Length == 0)
            {
                ShowInputError("Write a name for the animal.");
                return null;
            }

            int age;
            if (!int.TryParse(txtAge.Text.Trim(), out age)
                || age < 0)
            {
                ShowInputError(
                    "Age must be a whole number, zero or more.");
                return null;
            }

            string categoryText = txtCategoryValue.Text.Trim();
            string speciesText = txtSpeciesValue.Text.Trim();
            GenderType gender = SelectedGender();
            Animal animal = null;

            switch (SelectedSpecies())
            {
                case "Dog":
                    int dogTeeth;
                    double tailLength;
                    if (!ReadInt(categoryText, out dogTeeth)
                        || !ReadDouble(speciesText, out tailLength))
                    {
                        ShowInputError("Teeth and tail length " +
                            "must be numbers.");
                        return null;
                    }
                    animal = new Dog(name, age, gender,
                        dogTeeth, tailLength);
                    break;

                case "Cat":
                    int catTeeth;
                    if (!ReadInt(categoryText, out catTeeth)
                        || speciesText.Length == 0)
                    {
                        ShowInputError("Teeth must be a number " +
                            "and a breed must be written.");
                        return null;
                    }
                    animal = new Cat(name, age, gender,
                        catTeeth, speciesText);
                    break;

                case "Dove":
                    double doveSpeed;
                    double wingSpan;
                    if (!ReadDouble(categoryText, out doveSpeed)
                        || !ReadDouble(speciesText, out wingSpan))
                    {
                        ShowInputError("Flying speed and wing " +
                            "span must be numbers.");
                        return null;
                    }
                    animal = new Dove(name, age, gender,
                        doveSpeed, wingSpan);
                    break;

                case "Eagle":
                    double eagleSpeed;
                    double beakLength;
                    if (!ReadDouble(categoryText, out eagleSpeed)
                        || !ReadDouble(speciesText, out beakLength))
                    {
                        ShowInputError("Flying speed and beak " +
                            "length must be numbers.");
                        return null;
                    }
                    animal = new Eagle(name, age, gender,
                        eagleSpeed, beakLength);
                    break;

                case "Butterfly":
                    int butterflyLegs;
                    if (!ReadInt(categoryText, out butterflyLegs)
                        || speciesText.Length == 0)
                    {
                        ShowInputError("Legs must be a number " +
                            "and a wing color must be written.");
                        return null;
                    }
                    animal = new Butterfly(name, age, gender,
                        butterflyLegs, speciesText);
                    break;

                case "Bee":
                    int beeLegs;
                    int numberOfWings;
                    if (!ReadInt(categoryText, out beeLegs)
                        || !ReadInt(speciesText, out numberOfWings))
                    {
                        ShowInputError("Legs and number of " +
                            "wings must be numbers.");
                        return null;
                    }
                    animal = new Bee(name, age, gender,
                        beeLegs, numberOfWings);
                    break;
            }

            return animal;
        }

        private bool ReadInt(string text, out int value)
        {
            return int.TryParse(text, out value) && value >= 0;
        }

        private bool ReadDouble(string text, out double value)
        {
            return double.TryParse(text, out value) && value >= 0;
        }

        private void ShowInputError(string message)
        {
            MessageBox.Show(message, "Check the input",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// VG part for grade A: the animals are shown in a
        /// ListView with one column per fact, and the view
        /// is rebuilt from the manager every time it changes.
        /// </summary>
        private void RefreshListView(int selectedIndex)
        {
            lvAnimals.Items.Clear();

            for (int index = 0; index < animalManager.Count;
                index++)
            {
                Animal animal = animalManager.GetAnimalAt(index);
                if (animal == null)
                    continue;

                ListViewItem item =
                    new ListViewItem(animal.Id);
                item.SubItems.Add(animal.Name);
                item.SubItems.Add(animal.Age.ToString());
                item.SubItems.Add(animal.Gender.ToString());
                item.SubItems.Add(animal.GetSpecies());
                item.SubItems.Add(animal.GetCategory());
                item.SubItems.Add(animal.GetEaterType().ToString());
                lvAnimals.Items.Add(item);
            }

            if (selectedIndex >= 0
                && selectedIndex < lvAnimals.Items.Count)
            {
                lvAnimals.Items[selectedIndex].Selected = true;
                lvAnimals.Items[selectedIndex].Focused = true;
            }
        }

        private void lvAnimals_SelectedIndexChanged(
            object sender, EventArgs e)
        {
            if (lvAnimals.SelectedIndices.Count == 0)
                return;

            int index = lvAnimals.SelectedIndices[0];
            Animal animal = animalManager.GetAnimalAt(index);
            ShowFoodSchedule(animal);
        }

        private void ShowFoodSchedule(Animal animal)
        {
            lstFoodSchedule.Items.Clear();
            lblEaterTypeValue.Text = string.Empty;

            if (animal == null)
                return;

            lblEaterTypeValue.Text =
                animal.GetEaterType().ToString();
            lstFoodSchedule.Items.AddRange(
                animal.GetFoodSchedule()
                    .GetAllFoodDescriptions());
        }

        // VG part for grade A, sorting from the form: the
        // radio buttons choose the sorting, and the ListView
        // refreshes after the manager has sorted the list.
        private void rbSortByName_CheckedChanged(
            object sender, EventArgs e)
        {
            if (!rbSortByName.Checked)
                return;

            // VG grade B, sort one: default sort by name.
            animalManager.SortAnimals();
            RefreshListView(-1);
            lstFoodSchedule.Items.Clear();
            lblEaterTypeValue.Text = string.Empty;
        }

        private void rbSortBySpecies_CheckedChanged(
            object sender, EventArgs e)
        {
            if (!rbSortBySpecies.Checked)
                return;

            // VG grade B, sort two: comparer sort by species.
            animalManager.SortAnimals(
                new AnimalSpeciesComparer());
            RefreshListView(-1);
            lstFoodSchedule.Items.Clear();
            lblEaterTypeValue.Text = string.Empty;
        }
    }
}

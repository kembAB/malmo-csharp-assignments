namespace AnimalMotel
{
    /// <summary>
    /// The rules that every animal in the motel must follow.
    /// The interface says what an animal must be able to do,
    /// without saying how each species does it. The concrete
    /// species classes carry the real implementations.
    /// </summary>
    public interface IAnimal
    {
        string Id { get; set; }

        string Name { get; set; }

        GenderType Gender { get; set; }

        EaterType GetEaterType();

        FoodSchedule GetFoodSchedule();

        string GetSpecies();
    }
}

namespace AnimalMotel
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            grpAnimalInput = new System.Windows.Forms.GroupBox();
            lblCategory = new System.Windows.Forms.Label();
            lstCategories = new System.Windows.Forms.ListBox();
            lblSpecies = new System.Windows.Forms.Label();
            lstSpecies = new System.Windows.Forms.ListBox();
            lblName = new System.Windows.Forms.Label();
            txtName = new System.Windows.Forms.TextBox();
            lblAge = new System.Windows.Forms.Label();
            txtAge = new System.Windows.Forms.TextBox();
            lblGender = new System.Windows.Forms.Label();
            cmbGender = new System.Windows.Forms.ComboBox();
            lblCategoryAttribute = new System.Windows.Forms.Label();
            txtCategoryValue = new System.Windows.Forms.TextBox();
            lblSpeciesAttribute = new System.Windows.Forms.Label();
            txtSpeciesValue = new System.Windows.Forms.TextBox();
            btnAdd = new System.Windows.Forms.Button();
            grpAnimals = new System.Windows.Forms.GroupBox();
            lblSortBy = new System.Windows.Forms.Label();
            rbSortByName = new System.Windows.Forms.RadioButton();
            rbSortBySpecies = new System.Windows.Forms.RadioButton();
            lvAnimals = new System.Windows.Forms.ListView();
            colId = new System.Windows.Forms.ColumnHeader();
            colName = new System.Windows.Forms.ColumnHeader();
            colAge = new System.Windows.Forms.ColumnHeader();
            colGender = new System.Windows.Forms.ColumnHeader();
            colSpecies = new System.Windows.Forms.ColumnHeader();
            colCategory = new System.Windows.Forms.ColumnHeader();
            colEaterType = new System.Windows.Forms.ColumnHeader();
            grpFoodSchedule = new System.Windows.Forms.GroupBox();
            lblEaterType = new System.Windows.Forms.Label();
            lblEaterTypeValue = new System.Windows.Forms.Label();
            lstFoodSchedule = new System.Windows.Forms.ListBox();
            grpAnimalInput.SuspendLayout();
            grpAnimals.SuspendLayout();
            grpFoodSchedule.SuspendLayout();
            SuspendLayout();
            //
            // grpAnimalInput
            //
            grpAnimalInput.Controls.Add(lblCategory);
            grpAnimalInput.Controls.Add(lstCategories);
            grpAnimalInput.Controls.Add(lblSpecies);
            grpAnimalInput.Controls.Add(lstSpecies);
            grpAnimalInput.Controls.Add(lblName);
            grpAnimalInput.Controls.Add(txtName);
            grpAnimalInput.Controls.Add(lblAge);
            grpAnimalInput.Controls.Add(txtAge);
            grpAnimalInput.Controls.Add(lblGender);
            grpAnimalInput.Controls.Add(cmbGender);
            grpAnimalInput.Controls.Add(lblCategoryAttribute);
            grpAnimalInput.Controls.Add(txtCategoryValue);
            grpAnimalInput.Controls.Add(lblSpeciesAttribute);
            grpAnimalInput.Controls.Add(txtSpeciesValue);
            grpAnimalInput.Controls.Add(btnAdd);
            grpAnimalInput.Location =
                new System.Drawing.Point(12, 12);
            grpAnimalInput.Name = "grpAnimalInput";
            grpAnimalInput.Size =
                new System.Drawing.Size(360, 560);
            grpAnimalInput.TabIndex = 0;
            grpAnimalInput.TabStop = false;
            grpAnimalInput.Text = "New animal";
            //
            // lblCategory
            //
            lblCategory.AutoSize = true;
            lblCategory.Location =
                new System.Drawing.Point(16, 28);
            lblCategory.Name = "lblCategory";
            lblCategory.Text = "Category:";
            //
            // lstCategories
            //
            lstCategories.FormattingEnabled = true;
            lstCategories.Location =
                new System.Drawing.Point(16, 48);
            lstCategories.Name = "lstCategories";
            lstCategories.Size =
                new System.Drawing.Size(150, 69);
            lstCategories.TabIndex = 0;
            lstCategories.SelectedIndexChanged +=
                lstCategories_SelectedIndexChanged;
            //
            // lblSpecies
            //
            lblSpecies.AutoSize = true;
            lblSpecies.Location =
                new System.Drawing.Point(190, 28);
            lblSpecies.Name = "lblSpecies";
            lblSpecies.Text = "Species:";
            //
            // lstSpecies
            //
            lstSpecies.FormattingEnabled = true;
            lstSpecies.Location =
                new System.Drawing.Point(190, 48);
            lstSpecies.Name = "lstSpecies";
            lstSpecies.Size =
                new System.Drawing.Size(150, 69);
            lstSpecies.TabIndex = 1;
            lstSpecies.SelectedIndexChanged +=
                lstSpecies_SelectedIndexChanged;
            //
            // lblName
            //
            lblName.AutoSize = true;
            lblName.Location =
                new System.Drawing.Point(16, 136);
            lblName.Name = "lblName";
            lblName.Text = "Name:";
            //
            // txtName
            //
            txtName.Location =
                new System.Drawing.Point(16, 156);
            txtName.Name = "txtName";
            txtName.Size =
                new System.Drawing.Size(324, 23);
            txtName.TabIndex = 2;
            //
            // lblAge
            //
            lblAge.AutoSize = true;
            lblAge.Location =
                new System.Drawing.Point(16, 192);
            lblAge.Name = "lblAge";
            lblAge.Text = "Age:";
            //
            // txtAge
            //
            txtAge.Location =
                new System.Drawing.Point(16, 212);
            txtAge.Name = "txtAge";
            txtAge.Size =
                new System.Drawing.Size(150, 23);
            txtAge.TabIndex = 3;
            //
            // lblGender
            //
            lblGender.AutoSize = true;
            lblGender.Location =
                new System.Drawing.Point(190, 192);
            lblGender.Name = "lblGender";
            lblGender.Text = "Gender:";
            //
            // cmbGender
            //
            cmbGender.DropDownStyle =
                System.Windows.Forms.ComboBoxStyle.DropDownList;
            cmbGender.FormattingEnabled = true;
            cmbGender.Location =
                new System.Drawing.Point(190, 212);
            cmbGender.Name = "cmbGender";
            cmbGender.Size =
                new System.Drawing.Size(150, 23);
            cmbGender.TabIndex = 4;
            //
            // lblCategoryAttribute
            //
            lblCategoryAttribute.AutoSize = true;
            lblCategoryAttribute.Location =
                new System.Drawing.Point(16, 252);
            lblCategoryAttribute.Name = "lblCategoryAttribute";
            lblCategoryAttribute.Text = "Category attribute:";
            //
            // txtCategoryValue
            //
            txtCategoryValue.Location =
                new System.Drawing.Point(16, 272);
            txtCategoryValue.Name = "txtCategoryValue";
            txtCategoryValue.Size =
                new System.Drawing.Size(324, 23);
            txtCategoryValue.TabIndex = 5;
            //
            // lblSpeciesAttribute
            //
            lblSpeciesAttribute.AutoSize = true;
            lblSpeciesAttribute.Location =
                new System.Drawing.Point(16, 312);
            lblSpeciesAttribute.Name = "lblSpeciesAttribute";
            lblSpeciesAttribute.Text = "Species attribute:";
            //
            // txtSpeciesValue
            //
            txtSpeciesValue.Location =
                new System.Drawing.Point(16, 332);
            txtSpeciesValue.Name = "txtSpeciesValue";
            txtSpeciesValue.Size =
                new System.Drawing.Size(324, 23);
            txtSpeciesValue.TabIndex = 6;
            //
            // btnAdd
            //
            btnAdd.Location =
                new System.Drawing.Point(16, 380);
            btnAdd.Name = "btnAdd";
            btnAdd.Size =
                new System.Drawing.Size(324, 36);
            btnAdd.TabIndex = 7;
            btnAdd.Text = "Add animal";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            //
            // grpAnimals
            //
            grpAnimals.Controls.Add(lblSortBy);
            grpAnimals.Controls.Add(rbSortByName);
            grpAnimals.Controls.Add(rbSortBySpecies);
            grpAnimals.Controls.Add(lvAnimals);
            grpAnimals.Location =
                new System.Drawing.Point(388, 12);
            grpAnimals.Name = "grpAnimals";
            grpAnimals.Size =
                new System.Drawing.Size(584, 330);
            grpAnimals.TabIndex = 1;
            grpAnimals.TabStop = false;
            grpAnimals.Text = "Animals at the motel";
            //
            // lblSortBy
            //
            lblSortBy.AutoSize = true;
            lblSortBy.Location =
                new System.Drawing.Point(16, 292);
            lblSortBy.Name = "lblSortBy";
            lblSortBy.Text = "Sort by:";
            //
            // rbSortByName
            //
            rbSortByName.AutoSize = true;
            rbSortByName.Location =
                new System.Drawing.Point(76, 290);
            rbSortByName.Name = "rbSortByName";
            rbSortByName.Text = "Name";
            rbSortByName.UseVisualStyleBackColor = true;
            rbSortByName.CheckedChanged +=
                rbSortByName_CheckedChanged;
            //
            // rbSortBySpecies
            //
            rbSortBySpecies.AutoSize = true;
            rbSortBySpecies.Location =
                new System.Drawing.Point(156, 290);
            rbSortBySpecies.Name = "rbSortBySpecies";
            rbSortBySpecies.Text = "Species";
            rbSortBySpecies.UseVisualStyleBackColor = true;
            rbSortBySpecies.CheckedChanged +=
                rbSortBySpecies_CheckedChanged;
            //
            // lvAnimals
            //
            lvAnimals.Columns.AddRange(
                new System.Windows.Forms.ColumnHeader[]
                {
                    colId, colName, colAge, colGender,
                    colSpecies, colCategory, colEaterType
                });
            lvAnimals.FullRowSelect = true;
            lvAnimals.GridLines = true;
            lvAnimals.Location =
                new System.Drawing.Point(16, 28);
            lvAnimals.Name = "lvAnimals";
            lvAnimals.Size =
                new System.Drawing.Size(552, 250);
            lvAnimals.TabIndex = 0;
            lvAnimals.UseCompatibleStateImageBehavior = false;
            lvAnimals.View = System.Windows.Forms.View.Details;
            lvAnimals.SelectedIndexChanged +=
                lvAnimals_SelectedIndexChanged;
            //
            // colId
            //
            colId.Text = "Id";
            colId.Width = 40;
            //
            // colName
            //
            colName.Text = "Name";
            colName.Width = 110;
            //
            // colAge
            //
            colAge.Text = "Age";
            colAge.Width = 45;
            //
            // colGender
            //
            colGender.Text = "Gender";
            colGender.Width = 75;
            //
            // colSpecies
            //
            colSpecies.Text = "Species";
            colSpecies.Width = 90;
            //
            // colCategory
            //
            colCategory.Text = "Category";
            colCategory.Width = 85;
            //
            // colEaterType
            //
            colEaterType.Text = "Eater Type";
            colEaterType.Width = 95;
            //
            // grpFoodSchedule
            //
            grpFoodSchedule.Controls.Add(lblEaterType);
            grpFoodSchedule.Controls.Add(lblEaterTypeValue);
            grpFoodSchedule.Controls.Add(lstFoodSchedule);
            grpFoodSchedule.Location =
                new System.Drawing.Point(388, 358);
            grpFoodSchedule.Name = "grpFoodSchedule";
            grpFoodSchedule.Size =
                new System.Drawing.Size(584, 214);
            grpFoodSchedule.TabIndex = 2;
            grpFoodSchedule.TabStop = false;
            grpFoodSchedule.Text = "Food schedule";
            //
            // lblEaterType
            //
            lblEaterType.AutoSize = true;
            lblEaterType.Location =
                new System.Drawing.Point(16, 28);
            lblEaterType.Name = "lblEaterType";
            lblEaterType.Text = "Eater type:";
            //
            // lblEaterTypeValue
            //
            lblEaterTypeValue.AutoSize = true;
            lblEaterTypeValue.Font = new System.Drawing.Font(
                "Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            lblEaterTypeValue.Location =
                new System.Drawing.Point(90, 28);
            lblEaterTypeValue.Name = "lblEaterTypeValue";
            lblEaterTypeValue.Text = "";
            //
            // lstFoodSchedule
            //
            lstFoodSchedule.FormattingEnabled = true;
            lstFoodSchedule.Location =
                new System.Drawing.Point(16, 56);
            lstFoodSchedule.Name = "lstFoodSchedule";
            lstFoodSchedule.Size =
                new System.Drawing.Size(552, 142);
            lstFoodSchedule.TabIndex = 0;
            //
            // MainForm
            //
            AutoScaleDimensions =
                new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(984, 584);
            Controls.Add(grpAnimalInput);
            Controls.Add(grpAnimals);
            Controls.Add(grpFoodSchedule);
            Name = "MainForm";
            Text = "Apu's Animal Motel - Version 2";
            grpAnimalInput.ResumeLayout(false);
            grpAnimalInput.PerformLayout();
            grpAnimals.ResumeLayout(false);
            grpAnimals.PerformLayout();
            grpFoodSchedule.ResumeLayout(false);
            grpFoodSchedule.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox grpAnimalInput;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.ListBox lstCategories;
        private System.Windows.Forms.Label lblSpecies;
        private System.Windows.Forms.ListBox lstSpecies;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.ComboBox cmbGender;
        private System.Windows.Forms.Label lblCategoryAttribute;
        private System.Windows.Forms.TextBox txtCategoryValue;
        private System.Windows.Forms.Label lblSpeciesAttribute;
        private System.Windows.Forms.TextBox txtSpeciesValue;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.GroupBox grpAnimals;
        private System.Windows.Forms.Label lblSortBy;
        private System.Windows.Forms.RadioButton rbSortByName;
        private System.Windows.Forms.RadioButton rbSortBySpecies;
        private System.Windows.Forms.ListView lvAnimals;
        private System.Windows.Forms.ColumnHeader colId;
        private System.Windows.Forms.ColumnHeader colName;
        private System.Windows.Forms.ColumnHeader colAge;
        private System.Windows.Forms.ColumnHeader colGender;
        private System.Windows.Forms.ColumnHeader colSpecies;
        private System.Windows.Forms.ColumnHeader colCategory;
        private System.Windows.Forms.ColumnHeader colEaterType;
        private System.Windows.Forms.GroupBox grpFoodSchedule;
        private System.Windows.Forms.Label lblEaterType;
        private System.Windows.Forms.Label lblEaterTypeValue;
        private System.Windows.Forms.ListBox lstFoodSchedule;
    }
}

namespace AnimalMotel.Animals
{
    /// <summary>
    /// A butterfly is an insect. The species attribute is
    /// the wing colour. A butterfly is a herbivore and
    /// feeds on nectar and sugar water.
    /// </summary>
    public class Butterfly : Insect
    {
        private string wingColor;

        public Butterfly(string name, int age, GenderType gender,
            int numberOfLegs, string wingColor)
            : base(name, age, gender, numberOfLegs)
        {
            this.wingColor = wingColor;
        }

        public string WingColor
        {
            get { return wingColor; }
            set { wingColor = value; }
        }

        public override EaterType GetEaterType()
        {
            return EaterType.Herbivore;
        }

        public override string GetSpecies()
        {
            return "Butterfly";
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFoodDescription(
                "Morning 09:00: fresh nectar flowers, marigold and lavender.");
            schedule.AddFoodDescription(
                "Midday: a sponge soaked in sugar water, one to ten mix.");
            schedule.AddFoodDescription(
                "Afternoon 15:00: a thin slice of ripe orange or banana.");
            schedule.AddFoodDescription(
                "Evening: remove fruit and mist the enclosure with water.");
            return schedule;
        }

        public override string ToString()
        {
            return base.ToString() +
                ", Wing color: " + WingColor;
        }
    }
}

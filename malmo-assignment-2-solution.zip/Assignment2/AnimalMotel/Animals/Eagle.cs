namespace AnimalMotel.Animals
{
    /// <summary>
    /// An eagle is a bird. The species attribute is the beak
    /// length in centimetres. An eagle is a carnivore.
    /// </summary>
    public class Eagle : Bird
    {
        private double beakLength;

        public Eagle(string name, int age, GenderType gender,
            double flyingSpeed, double beakLength)
            : base(name, age, gender, flyingSpeed)
        {
            this.beakLength = beakLength;
        }

        public double BeakLength
        {
            get { return beakLength; }
            set { beakLength = value; }
        }

        public override EaterType GetEaterType()
        {
            return EaterType.Carnivore;
        }

        public override string GetSpecies()
        {
            return "Eagle";
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFoodDescription(
                "Morning 08:00: raw meat, about 200 grams, on a clean perch.");
            schedule.AddFoodDescription(
                "Midday: fresh water and a check for leftover meat.");
            schedule.AddFoodDescription(
                "Afternoon 15:00: a fish or a day old chick as meal two.");
            schedule.AddFoodDescription(
                "Note: one fasting day per week is normal for an adult eagle.");
            return schedule;
        }

        public override string ToString()
        {
            return base.ToString() +
                ", Beak length cm: " + BeakLength;
        }
    }
}

namespace AnimalMotel.Animals
{
    /// <summary>
    /// A dove is a bird. The species attribute is the wing
    /// span in centimetres. A dove is a herbivore.
    /// </summary>
    public class Dove : Bird
    {
        private double wingSpan;

        public Dove(string name, int age, GenderType gender,
            double flyingSpeed, double wingSpan)
            : base(name, age, gender, flyingSpeed)
        {
            this.wingSpan = wingSpan;
        }

        public double WingSpan
        {
            get { return wingSpan; }
            set { wingSpan = value; }
        }

        public override EaterType GetEaterType()
        {
            return EaterType.Herbivore;
        }

        public override string GetSpecies()
        {
            return "Dove";
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFoodDescription(
                "Morning 07:00: two spoons of mixed seeds, millet and wheat.");
            schedule.AddFoodDescription(
                "Midday: lettuce and a shallow dish of water for bathing.");
            schedule.AddFoodDescription(
                "Afternoon 16:00: one spoon of seeds and a pinch of grit.");
            schedule.AddFoodDescription(
                "Evening: remove old food and refill the water dish.");
            return schedule;
        }

        public override string ToString()
        {
            return base.ToString() +
                ", Wing span cm: " + WingSpan;
        }
    }
}

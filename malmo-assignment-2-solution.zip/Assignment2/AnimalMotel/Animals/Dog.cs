namespace AnimalMotel.Animals
{
    /// <summary>
    /// A dog is a mammal. The species attribute is the tail
    /// length in centimetres. A dog is an omnivore.
    /// </summary>
    public class Dog : Mammal
    {
        private double tailLength;

        public Dog(string name, int age, GenderType gender,
            int numberOfTeeth, double tailLength)
            : base(name, age, gender, numberOfTeeth)
        {
            this.tailLength = tailLength;
        }

        public double TailLength
        {
            get { return tailLength; }
            set { tailLength = value; }
        }

        public override EaterType GetEaterType()
        {
            return EaterType.Omnivore;
        }

        public override string GetSpecies()
        {
            return "Dog";
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFoodDescription(
                "Breakfast 07:00: one bowl of dry dog food mixed with warm water.");
            schedule.AddFoodDescription(
                "Midday 12:00: a few training treats and fresh drinking water.");
            schedule.AddFoodDescription(
                "Dinner 18:00: one bowl of dry food with rice and carrot pieces.");
            schedule.AddFoodDescription(
                "Evening: refill the water bowl and check the food bowl is clean.");
            return schedule;
        }

        public override string ToString()
        {
            return base.ToString() +
                ", Tail length cm: " + TailLength;
        }
    }
}

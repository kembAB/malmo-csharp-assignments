namespace AnimalMotel.Animals
{
    /// <summary>
    /// A cat is a mammal. The species attribute is the breed.
    /// A cat is a carnivore.
    /// </summary>
    public class Cat : Mammal
    {
        private string breed;

        public Cat(string name, int age, GenderType gender,
            int numberOfTeeth, string breed)
            : base(name, age, gender, numberOfTeeth)
        {
            this.breed = breed;
        }

        public string Breed
        {
            get { return breed; }
            set { breed = value; }
        }

        public override EaterType GetEaterType()
        {
            return EaterType.Carnivore;
        }

        public override string GetSpecies()
        {
            return "Cat";
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFoodDescription(
                "Breakfast 06:30: half a pouch of wet food with chicken.");
            schedule.AddFoodDescription(
                "Lunch 12:30: a small bowl of dry cat food left out for grazing.");
            schedule.AddFoodDescription(
                "Dinner 18:30: half a pouch of wet food with fish.");
            schedule.AddFoodDescription(
                "Evening: clean water again. Note: no milk, cats get water.");
            return schedule;
        }

        public override string ToString()
        {
            return base.ToString() + ", Breed: " + Breed;
        }
    }
}

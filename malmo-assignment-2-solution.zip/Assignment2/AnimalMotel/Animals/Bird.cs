namespace AnimalMotel.Animals
{
    /// <summary>
    /// Abstract category class for birds. Adds the flying
    /// speed in kilometres per hour.
    /// </summary>
    public abstract class Bird : Animal
    {
        private double flyingSpeed;

        protected Bird(string name, int age, GenderType gender,
            double flyingSpeed)
            : base(name, age, gender)
        {
            this.flyingSpeed = flyingSpeed;
        }

        public double FlyingSpeed
        {
            get { return flyingSpeed; }
            set { flyingSpeed = value; }
        }

        public override string GetCategory()
        {
            return "Bird";
        }

        public override string ToString()
        {
            return base.ToString() +
                ", Flying speed km/h: " + FlyingSpeed;
        }
    }
}

namespace AnimalMotel.Animals
{
    /// <summary>
    /// Abstract category class for mammals. Adds the number
    /// of teeth that every mammal in the motel is given.
    /// </summary>
    public abstract class Mammal : Animal
    {
        private int numberOfTeeth;

        protected Mammal(string name, int age, GenderType gender,
            int numberOfTeeth)
            : base(name, age, gender)
        {
            this.numberOfTeeth = numberOfTeeth;
        }

        public int NumberOfTeeth
        {
            get { return numberOfTeeth; }
            set { numberOfTeeth = value; }
        }

        public override string GetCategory()
        {
            return "Mammal";
        }

        public override string ToString()
        {
            return base.ToString() +
                ", Number of teeth: " + NumberOfTeeth;
        }
    }
}

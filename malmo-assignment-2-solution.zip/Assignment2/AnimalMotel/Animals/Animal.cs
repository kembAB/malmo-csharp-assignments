using System;

namespace AnimalMotel.Animals
{
    /// <summary>
    /// The abstract base class for every animal.
    /// It holds the data that all animals share and it
    /// implements the IAnimal interface by declaring the
    /// species dependent methods as abstract. Each concrete
    /// species writes its own version of those methods, and
    /// a call through an Animal reference runs the version
    /// of the real object. That is dynamic binding.
    ///
    /// VG part for grade B: Animal also implements
    /// IComparable of Animal, so the default sort compares
    /// animals by name.
    /// </summary>
    public abstract class Animal : IAnimal, IComparable<Animal>
    {
        private string id;
        private string name;
        private int age;
        private GenderType gender;

        protected Animal(string name, int age, GenderType gender)
        {
            this.name = name;
            this.age = age;
            this.gender = gender;
            id = string.Empty;
        }

        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public GenderType Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        // The species data lives in the concrete classes, so
        // these three methods are abstract here.
        public abstract EaterType GetEaterType();

        public abstract FoodSchedule GetFoodSchedule();

        public abstract string GetSpecies();

        /// <summary>
        /// The category name, Mammal, Bird or Insect. The
        /// abstract category classes override this method.
        /// </summary>
        public virtual string GetCategory()
        {
            return "Unknown";
        }

        /// <summary>
        /// VG grade B, default sort: compare by name, and
        /// ignore letter case. A missing other object sorts
        /// after this animal.
        /// </summary>
        public int CompareTo(Animal other)
        {
            if (other == null)
                return 1;

            return string.Compare(Name, other.Name,
                StringComparison.OrdinalIgnoreCase);
        }

        public override string ToString()
        {
            return "Id: " + Id + ", Name: " + Name +
                ", Age: " + Age + ", Gender: " + Gender +
                ", Species: " + GetSpecies() +
                ", Category: " + GetCategory();
        }
    }
}

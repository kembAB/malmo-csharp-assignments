namespace AnimalMotel.Animals
{
    /// <summary>
    /// A bee is an insect. The species attribute is the
    /// number of wings. A bee is a herbivore and feeds on
    /// nectar and pollen.
    /// </summary>
    public class Bee : Insect
    {
        private int numberOfWings;

        public Bee(string name, int age, GenderType gender,
            int numberOfLegs, int numberOfWings)
            : base(name, age, gender, numberOfLegs)
        {
            this.numberOfWings = numberOfWings;
        }

        public int NumberOfWings
        {
            get { return numberOfWings; }
            set { numberOfWings = value; }
        }

        public override EaterType GetEaterType()
        {
            return EaterType.Herbivore;
        }

        public override string GetSpecies()
        {
            return "Bee";
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFoodDescription(
                "Morning 08:00: open access to nectar rich flowers.");
            schedule.AddFoodDescription(
                "Midday: sugar water feeder with stones for safe landing.");
            schedule.AddFoodDescription(
                "Afternoon: a pollen patty near the hive box for protein.");
            schedule.AddFoodDescription(
                "Note: never feed honey that comes from another hive.");
            return schedule;
        }

        public override string ToString()
        {
            return base.ToString() +
                ", Number of wings: " + NumberOfWings;
        }
    }
}

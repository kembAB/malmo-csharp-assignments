namespace AnimalMotel.Animals
{
    /// <summary>
    /// Abstract category class for insects. Adds the number
    /// of legs that every insect in the motel is given.
    /// </summary>
    public abstract class Insect : Animal
    {
        private int numberOfLegs;

        protected Insect(string name, int age, GenderType gender,
            int numberOfLegs)
            : base(name, age, gender)
        {
            this.numberOfLegs = numberOfLegs;
        }

        public int NumberOfLegs
        {
            get { return numberOfLegs; }
            set { numberOfLegs = value; }
        }

        public override string GetCategory()
        {
            return "Insect";
        }

        public override string ToString()
        {
            return base.ToString() +
                ", Number of legs: " + NumberOfLegs;
        }
    }
}

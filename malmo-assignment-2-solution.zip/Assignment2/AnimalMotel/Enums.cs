namespace AnimalMotel
{
    /// <summary>
    /// The gender of an animal. Unknown is used when the
    /// gender has not been decided or is not known.
    /// </summary>
    public enum GenderType
    {
        Male,
        Female,
        Unknown
    }

    /// <summary>
    /// The kind of eater an animal is, as required by the
    /// assignment: meat eater, plant eater or all eater.
    /// </summary>
    public enum EaterType
    {
        Carnivore,
        Herbivore,
        Omnivore
    }
}

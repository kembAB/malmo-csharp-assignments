using System;
using System.Collections.Generic;

namespace AnimalMotel
{
    /// <summary>
    /// A feeding plan for one species. Each item in the
    /// private list is one line of text, and the lines are
    /// shown together on the form as the food schedule.
    /// </summary>
    public class FoodSchedule
    {
        // Strictly private. Outside code works through the
        // methods of this class only.
        private List<string> foodDescriptionList;

        public FoodSchedule()
        {
            foodDescriptionList = new List<string>();
        }

        /// <summary>The number of lines in the schedule.</summary>
        public int Count
        {
            get { return foodDescriptionList.Count; }
        }

        /// <summary>
        /// Returns false when the index is outside the list,
        /// and true when the index points at a real line.
        /// </summary>
        public bool ValidateIndex(int index)
        {
            return index >= 0 && index < foodDescriptionList.Count;
        }

        /// <summary>Adds one description line to the schedule.</summary>
        public void AddFoodDescription(string description)
        {
            if (!string.IsNullOrWhiteSpace(description))
                foodDescriptionList.Add(description.Trim());
        }

        /// <summary>
        /// Reads one line. An invalid index gives an empty
        /// string instead of a crash.
        /// </summary>
        public string GetFoodDescriptionAt(int index)
        {
            if (ValidateIndex(index))
                return foodDescriptionList[index];

            return string.Empty;
        }

        /// <summary>All lines of the schedule as a string array.</summary>
        public string[] GetAllFoodDescriptions()
        {
            return foodDescriptionList.ToArray();
        }

        public override string ToString()
        {
            return string.Join(Environment.NewLine,
                foodDescriptionList);
        }
    }
}

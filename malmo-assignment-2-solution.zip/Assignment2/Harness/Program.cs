using AnimalMotel;
using AnimalMotel.Animals;
using AnimalMotel.Managers;

// Test harness for Assignment 2, Apu's Animal Motel.
// It exercises the same model classes as the Windows
// Forms project, through Animal references only.

AnimalManager manager = new AnimalManager();

// One animal of each of the six species, each held
// through an Animal reference. The calls below are
// answered by the concrete species by dynamic binding.
Animal rex = new Dog("Rex", 5, GenderType.Male, 42, 30.5);
Animal maja = new Cat("Maja", 3, GenderType.Female, 30,
    "Siamese");
Animal hope = new Dove("Hope", 2, GenderType.Female, 40.0,
    68.0);
Animal sisu = new Eagle("Sisu", 7, GenderType.Male, 120.0,
    6.5);
Animal ladyJ = new Butterfly("Lady J.", 1,
    GenderType.Female, 6, "Orange");
Animal buzz = new Bee("Buzz", 1, GenderType.Male, 6, 4);

manager.AddAnimal(rex);
manager.AddAnimal(maja);
manager.AddAnimal(hope);
manager.AddAnimal(sisu);
manager.AddAnimal(ladyJ);
manager.AddAnimal(buzz);

Console.WriteLine("=== Animals in the motel, " +
    "in the order they were added ===");
Console.WriteLine("Count: " + manager.Count);
for (int index = 0; index < manager.Count; index++)
{
    Animal animal = manager.GetAnimalAt(index);
    Console.WriteLine(animal.ToString());
    Console.WriteLine("  Eater type: " +
        animal.GetEaterType());
}

Console.WriteLine();
Console.WriteLine("=== Food schedule for the dog, " +
    manager.GetAnimalAt(0).Name + " ===");
FoodSchedule dogSchedule = rex.GetFoodSchedule();
Console.WriteLine("Lines in schedule: " + dogSchedule.Count);
foreach (string line in dogSchedule.GetAllFoodDescriptions())
    Console.WriteLine(line);
Console.WriteLine("ValidateIndex check, index 0 valid: " +
    dogSchedule.ValidateIndex(0));
Console.WriteLine("ValidateIndex check, index 99 valid: " +
    dogSchedule.ValidateIndex(99));

Console.WriteLine();
Console.WriteLine("=== Food schedule for the butterfly, " +
    ladyJ.Name + " ===");
FoodSchedule butterflySchedule = ladyJ.GetFoodSchedule();
Console.WriteLine(butterflySchedule.ToString());

Console.WriteLine();
Console.WriteLine("=== Animals sorted by name, " +
    "default sort ===");
manager.SortAnimals();
foreach (string line in manager.GetAnimalListAsStringArray())
    Console.WriteLine(line);

Console.WriteLine();
Console.WriteLine("=== Animals sorted by species, " +
    "comparer sort ===");
manager.SortAnimals(new AnimalSpeciesComparer());
foreach (string line in manager.GetAnimalListAsStringArray())
    Console.WriteLine(line);

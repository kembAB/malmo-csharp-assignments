import os
from xml.sax.saxutils import escape
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_CENTER
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Preformatted, PageBreak

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "malmo-csharp-assignment-4-explainer.pdf")

PROSE = {}

PROSE["title"] = "Assignment 4 Explainer"
PROSE["subtitle"] = "Apu's Animal Motel, Version 4: Persistence with Binary and XML Serialization"
PROSE["author"] = "Abel Haile Magicho"
PROSE["course"] = "Programming in C Sharp II, Malmö University"

PROSE["ask_heading"] = "What the Assignment Asks"
PROSE["ask_intro"] = "Assignment 4 is the final version of the Animal Motel application. <b>Its whole point is persistence: data must survive after the program closes.</b> The earlier versions kept every animal, recipe and staff member in memory only, so all work vanished at exit. This version saves the data to files and reads it back, handles the errors that file work can cause, and improves the graphical user interface with a real File menu."
PROSE["ask_items"] = [
    "The animal registry must be saved to a file in binary form with binary serialization through BinaryFormatter, and a saved registry must be loaded back into the program.",
    "The recipe list must be exported to an XML file with XmlSerializer, and the user must be able to read such an XML file back into the program.",
    "The user must select the drive, folder and file name for every read and write through the OpenFileDialog and SaveFileDialog controls. <b>No file path may be hard coded anywhere.</b>",
    "The Open and Save As menu items must work with either a binary file or a plain text file, and the program must remember the chosen file and its type so that Save writes the data correctly.",
    "The New menu item must reinitialize the program exactly as at start up, and it must ask through a MessageBox before unsaved data is thrown away.",
    "The File menu must be built with a MenuStrip component named mnuFile, and every submenu name must start with the same mnuFile prefix.",
    "All animal objects inside the AnimalManager must be serializable.",
    "The interface IListManager must gain four void serialization methods under a comment marking them as the Assignment 4 additions, and ListManager must implement them. The methods return void because an exception carries the failure information when something goes wrong.",
    "Error messages from serialization must never be shown by a utility class or by a manager class. <b>Only the graphical user interface may talk to the user.</b>",
    "At least one demo file of each serialization type must ship with the project so the teacher can test the application: Demo1.bin for the binary registry and Demo1.xml for the recipes.",
    "For the higher grade, the XML serialization of recipes must be complete, carrying both the name and the ingredients of each recipe, and the Import from XML File submenu must deserialize a saved XML file back into the RecipeManager.",
    "As an optional extra for the higher grade, the assignment invites a custom exception class of your own design, thrown at a proper place in the code.",
    "This solution also ships a third demo file, Demo1.txt, holding the animal registry in the plain text format described further down.",
]

PROSE["how_heading"] = "How the Code Answers, Step by Step"
PROSE["how_items"] = [
    "<b>Step 1, the base model stands alone.</b> The Version 3 state is rebuilt inside this project because every assignment is submitted on its own. The model holds the GenderType and EaterType enumerations, the IAnimal interface, the FoodSchedule class, the abstract Animal class with its abstract category classes Mammal, Bird and Insect, and the six species Dog, Cat, Dove, Eagle, Butterfly and Bee, each with its own specific attribute and its own hard coded food schedule.",
    "<b>Step 2, generics carry the lists.</b> IListManager of T declares the ordinary list operations, and ListManager of T implements them once on a private List of T. AnimalManager inherits from ListManager of Animal and adds a private id counter and the AddAnimal method. RecipeManager inherits from ListManager of Recipe and needs no further code. Staff keeps its qualifications in a field typed as the interface IListManager of string, exactly as the earlier version prescribed.",
    "<b>Step 3, the whole animal graph is marked serializable.</b> The Serializable attribute sits on Animal, on Mammal, Bird and Insect, on every one of the six species and on FoodSchedule. That single attribute chain is what lets BinaryFormatter walk the whole object graph and write it to a stream.",
    "<b>Step 4, BinaryFormatter is switched back on.</b> The formatter is disabled by default in dot net 8, yet the assignment explicitly demands binary serialization with BinaryFormatter. The project file therefore sets EnableUnsafeBinaryFormatterSerialization to true, and a pragma at the top of BinSerializerUtility suppresses the SYSLIB0011 warning in that one file.",
    "<b>Step 5, two utility classes do the file work.</b> The Utilities folder holds BinSerializerUtility and XMLSerializerUtility. Each is a static class with two methods: one writes a List of T to a file and one reads a List of T back from a file. ListManager implements the four new interface methods by calling these utilities on its private list, and deserialization replaces the list contents with the loaded list.",
    "<b>Step 6, the utilities never catch.</b> Neither utility class and neither manager class contains a catch block for serialization errors. Every stream is opened inside a using statement, so the stream always closes, and any exception simply travels up the call chain until it reaches the graphical user interface.",
    "<b>Step 7, the GUI owns every error message.</b> Each File menu handler in MainForm wraps its manager call in a try and catch block and shows the Message property of the caught exception in a MessageBox. The design keeps one single place responsible for talking to the user, and the lower layers stay free of any user interface code.",
    "<b>Step 8, Recipe is reshaped for XML.</b> Following the note in the assignment, the ingredients of a Recipe now live in a public List of string property instead of a ListManager of string. Recipe also gains a parameterless constructor and public settable Name and Ingredients properties, because XmlSerializer can only work with public settable members and a parameterless constructor. This is what makes the VG requirement possible: the XML file carries the ingredients as well as the names. XmlInclude attributes on the Animal class register all six species, so XML serialization works for animal lists too.",
    "<b>Step 9, the File menu remembers.</b> MainForm keeps the current file name and a flag telling whether that file is binary or text. Save As writes through a SaveFileDialog as binary or as text according to the chosen filter and then remembers both the name and the type. Save writes to the remembered file with binary serialization when the remembered file is a binary file, writes text when it is a text file, and calls Save As automatically when no file has been remembered yet. Open reads through an OpenFileDialog, choosing binary deserialization or the text loader from the chosen filter, and remembers the file and its type in the same way. New reinitializes the registry exactly as at start up and asks with a MessageBox before discarding unsaved data.",
    "<b>Step 10, recipes travel as XML.</b> Export to XML File asks for a file through a SaveFileDialog and serializes the recipe list, names and ingredients together. Import from XML File asks through an OpenFileDialog and deserializes the file straight back into the RecipeManager. Both handlers follow the same try and catch and MessageBox pattern as the rest of the menu.",
    "<b>Step 11, a plain text format covers the text menu choices.</b> AnimalManager can save the registry to a text file and load it back. The format is one animal per line with the fields separated by semicolons and the species name first, followed by name, age, gender and the species specific value. A small factory class, AnimalFactory, recreates the right species from each line and also writes each line, and the format is documented in a code comment in both classes.",
    "<b>Step 12, the custom exception guards the registry.</b> The optional VG item is included and marked clearly in the code. AnimalMotelException is a custom exception class in the Utilities folder. AnimalManager.AddAnimal throws it when the animal handed in is null and when the animal name is empty. The graphical user interface catches it in the same catch block as every other exception and shows its message, and the harness at the end of this document triggers it on purpose and prints the caught message.",
    "<b>Step 13, demo files prove the formats.</b> The harness program generates Demo1.bin with the binary registry, Demo1.xml with the recipes as an ArrayOfRecipe document and Demo1.txt with the text registry, and saves all three into the Assignment4 folder beside the project, ready for the teacher to open inside the application.",
]

PROSE["run_heading"] = "How to Run"
PROSE["run_items"] = [
    "Build the graphical application with the dot net tool from the Assignment4 folder: dotnet build AnimalMotel/AnimalMotel.csproj. The build must finish with zero errors. The application is a Windows Forms program and runs on Windows.",
    "Run the demonstration harness with dotnet run from the Harness folder. The harness adds animals and recipes, performs the binary round trip, the text round trip and the XML round trip, triggers the custom exception on purpose, writes the three demo files and prints every step.",
    "The real printed output of that harness run is reproduced verbatim further down in this document, and the original is saved as output.txt in the Assignment4 folder.",
]

PROSE["code_heading"] = "Full Source Code"
PROSE["code_intro"] = "<b>Every source file of both projects follows verbatim, under its own file name.</b> The harness Program.cs file is labelled as the harness so it cannot be confused with the Program.cs file of the graphical application."
PROSE["output_heading"] = "Real Output of the Harness Run"
PROSE["output_intro"] = "The block below is the real output exactly as the harness printed it. <b>It contains the Demo1.xml content verbatim</b>, because the harness prints the XML file right after writing it, and it also shows both caught AnimalMotelException messages at the end."
PROSE["glossary_heading"] = "Glossary"
PROSE["glossary_items"] = [
    "<b>Serialization.</b> Turning an object or a whole object graph into a stream of bytes or text so it can be stored in a file and rebuilt later.",
    "<b>BinaryFormatter.</b> The classic dot net formatter that writes objects in a compact binary form. It is disabled by default in dot net 8 and must be switched on in the project file when an assignment demands it.",
    "<b>XmlSerializer.</b> The dot net serializer that writes objects as readable XML. It needs a parameterless constructor and public settable properties on every class it writes.",
    "<b>Generic type.</b> A class or interface written with a type parameter such as T, so the same code works for animals, recipes and plain strings alike.",
    "<b>Interface.</b> A contract listing methods and properties without any code, which other classes then implement in their own way.",
    "<b>Abstract class.</b> A class that cannot be created on its own and exists to be inherited from, often holding shared code and abstract methods that subclasses must supply.",
    "<b>Exception.</b> An object carrying error information that is thrown when something fails and travels up the call chain until a catch block handles it.",
    "<b>Custom exception.</b> An exception class written by the programmer, here AnimalMotelException, used to signal rule violations in one specific application.",
    "<b>MenuStrip.</b> The Windows Forms component that builds the main menu bar of a window.",
    "<b>Stream.</b> A flow of bytes between the program and a file. A using statement guarantees the stream is closed even when an exception is thrown.",
    "<b>Invariant culture.</b> A fixed culture setting for reading and writing numbers, used in the text format so a decimal point always means the same thing on every computer.",
    "<b>VG requirement.</b> A requirement for the higher grades. In this assignment it means the complete XML export with ingredients plus the XML import, and it is met by this solution.",
]

for key, value in PROSE.items():
    texts = value if isinstance(value, list) else [value]
    for text in texts:
        assert "(" not in text and ")" not in text, "Parenthesis found in prose key: " + key

styles = {
    "title": ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=22, leading=27, alignment=TA_CENTER, spaceAfter=8),
    "subtitle": ParagraphStyle("subtitle", fontName="Helvetica", fontSize=13, leading=17, alignment=TA_CENTER, spaceAfter=6),
    "author": ParagraphStyle("author", fontName="Helvetica-Bold", fontSize=12, leading=16, alignment=TA_CENTER, spaceAfter=4),
    "course": ParagraphStyle("course", fontName="Helvetica", fontSize=11, leading=15, alignment=TA_CENTER, spaceAfter=14),
    "h1": ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=15, leading=19, spaceBefore=14, spaceAfter=7),
    "h2": ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=10.5, leading=13, spaceBefore=10, spaceAfter=3),
    "body": ParagraphStyle("body", fontName="Helvetica", fontSize=10.5, leading=14.5, spaceAfter=6),
    "code": ParagraphStyle("code", fontName="Courier", fontSize=6, leading=7.4),
}

def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.drawCentredString(A4[0] / 2.0, 12 * mm, "Assignment 4 Explainer - Abel Haile Magicho - Page %d" % doc.page)
    canvas.restoreState()

story = []
story.append(Paragraph(PROSE["title"], styles["title"]))
story.append(Paragraph(PROSE["subtitle"], styles["subtitle"]))
story.append(Paragraph(PROSE["author"], styles["author"]))
story.append(Paragraph(PROSE["course"], styles["course"]))

story.append(Paragraph(PROSE["ask_heading"], styles["h1"]))
story.append(Paragraph(PROSE["ask_intro"], styles["body"]))
for item in PROSE["ask_items"]:
    story.append(Paragraph(item, styles["body"]))

story.append(Paragraph(PROSE["how_heading"], styles["h1"]))
for item in PROSE["how_items"]:
    story.append(Paragraph(item, styles["body"]))

story.append(Paragraph(PROSE["run_heading"], styles["h1"]))
for item in PROSE["run_items"]:
    story.append(Paragraph(item, styles["body"]))

story.append(PageBreak())
story.append(Paragraph(PROSE["code_heading"], styles["h1"]))
story.append(Paragraph(PROSE["code_intro"], styles["body"]))

FILES = [
    ("AnimalMotel project file: AnimalMotel/AnimalMotel.csproj", "AnimalMotel/AnimalMotel.csproj"),
    ("AnimalMotel/Program.cs", "AnimalMotel/Program.cs"),
    ("AnimalMotel/Animals/GenderType.cs", "AnimalMotel/Animals/GenderType.cs"),
    ("AnimalMotel/Animals/EaterType.cs", "AnimalMotel/Animals/EaterType.cs"),
    ("AnimalMotel/Animals/IAnimal.cs", "AnimalMotel/Animals/IAnimal.cs"),
    ("AnimalMotel/Animals/FoodSchedule.cs", "AnimalMotel/Animals/FoodSchedule.cs"),
    ("AnimalMotel/Animals/Animal.cs", "AnimalMotel/Animals/Animal.cs"),
    ("AnimalMotel/Animals/Mammal.cs", "AnimalMotel/Animals/Mammal.cs"),
    ("AnimalMotel/Animals/Bird.cs", "AnimalMotel/Animals/Bird.cs"),
    ("AnimalMotel/Animals/Insect.cs", "AnimalMotel/Animals/Insect.cs"),
    ("AnimalMotel/Animals/Dog.cs", "AnimalMotel/Animals/Dog.cs"),
    ("AnimalMotel/Animals/Cat.cs", "AnimalMotel/Animals/Cat.cs"),
    ("AnimalMotel/Animals/Dove.cs", "AnimalMotel/Animals/Dove.cs"),
    ("AnimalMotel/Animals/Eagle.cs", "AnimalMotel/Animals/Eagle.cs"),
    ("AnimalMotel/Animals/Butterfly.cs", "AnimalMotel/Animals/Butterfly.cs"),
    ("AnimalMotel/Animals/Bee.cs", "AnimalMotel/Animals/Bee.cs"),
    ("AnimalMotel/Animals/AnimalFactory.cs", "AnimalMotel/Animals/AnimalFactory.cs"),
    ("AnimalMotel/Managers/IListManager.cs", "AnimalMotel/Managers/IListManager.cs"),
    ("AnimalMotel/Managers/ListManager.cs", "AnimalMotel/Managers/ListManager.cs"),
    ("AnimalMotel/Managers/AnimalManager.cs", "AnimalMotel/Managers/AnimalManager.cs"),
    ("AnimalMotel/Managers/RecipeManager.cs", "AnimalMotel/Managers/RecipeManager.cs"),
    ("AnimalMotel/Food/Recipe.cs", "AnimalMotel/Food/Recipe.cs"),
    ("AnimalMotel/Staff/Staff.cs", "AnimalMotel/Staff/Staff.cs"),
    ("AnimalMotel/Utilities/BinSerializerUtility.cs", "AnimalMotel/Utilities/BinSerializerUtility.cs"),
    ("AnimalMotel/Utilities/XMLSerializerUtility.cs", "AnimalMotel/Utilities/XMLSerializerUtility.cs"),
    ("AnimalMotel/Utilities/AnimalMotelException.cs", "AnimalMotel/Utilities/AnimalMotelException.cs"),
    ("AnimalMotel/Forms/MainForm.cs", "AnimalMotel/Forms/MainForm.cs"),
    ("AnimalMotel/Forms/RecipeForm.cs", "AnimalMotel/Forms/RecipeForm.cs"),
    ("AnimalMotel/Forms/StaffForm.cs", "AnimalMotel/Forms/StaffForm.cs"),
    ("Harness project file: Harness/Harness.csproj", "Harness/Harness.csproj"),
    ("Harness Program.cs, the demonstration harness: Harness/Program.cs", "Harness/Program.cs"),
]

for heading, rel in FILES:
    with open(os.path.join(BASE, rel), "r", encoding="utf-8") as fh:
        code = fh.read()
    story.append(Paragraph(escape(heading), styles["h2"]))
    story.append(Preformatted(escape(code.rstrip("\n")), styles["code"]))
    story.append(Spacer(1, 4))

story.append(PageBreak())
story.append(Paragraph(PROSE["output_heading"], styles["h1"]))
story.append(Paragraph(PROSE["output_intro"], styles["body"]))
with open(os.path.join(BASE, "output.txt"), "r", encoding="utf-8") as fh:
    output_text = fh.read()
story.append(Preformatted(escape(output_text.rstrip("\n")), styles["code"]))

story.append(PageBreak())
story.append(Paragraph(PROSE["glossary_heading"], styles["h1"]))
for item in PROSE["glossary_items"]:
    story.append(Paragraph(item, styles["body"]))

doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=30, rightMargin=30, topMargin=36, bottomMargin=36,
                        title="Assignment 4 Explainer - Abel Haile Magicho", author="Abel Haile Magicho")
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print("Built:", OUT)

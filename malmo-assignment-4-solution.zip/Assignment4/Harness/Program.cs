using System;
using System.IO;
using AnimalMotel.Animals;
using AnimalMotel.Food;
using AnimalMotel.Managers;
using AnimalMotel.Utilities;

namespace Harness
{
    internal static class Program
    {
        private static void Main()
        {
            // Demo files belong in the Assignment4 folder, which is the
            // parent folder of this Harness folder when the harness runs
            // from its own project directory.
            string baseFolder = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), ".."));
            string binFile = Path.Combine(baseFolder, "Demo1.bin");
            string xmlFile = Path.Combine(baseFolder, "Demo1.xml");
            string txtFile = Path.Combine(baseFolder, "Demo1.txt");

            Console.WriteLine("=== Assignment 4 harness: Apu's Animal Motel, Version 4 ===");
            Console.WriteLine("Demo folder: " + baseFolder);
            Console.WriteLine();

            Console.WriteLine("Step 1: Adding animals to the registry");
            AnimalManager animalManager = new AnimalManager();
            animalManager.AddAnimal(new Dog("Rex", 5, GenderType.Male, 25.5));
            animalManager.AddAnimal(new Cat("Misty", 3, GenderType.Female, "Siamese"));
            animalManager.AddAnimal(new Dove("Peace", 2, GenderType.Female, 32.0));
            animalManager.AddAnimal(new Eagle("Aquila", 7, GenderType.Male, 6.5));
            animalManager.AddAnimal(new Butterfly("Lady J.", 1, GenderType.Female, "Blue"));
            animalManager.AddAnimal(new Bee("Buzz", 1, GenderType.Male, 4));
            PrintAnimals(animalManager);
            Console.WriteLine("Food schedule of the first animal, Rex the Dog:");
            foreach (string line in animalManager.GetAt(0).GetFoodSchedule().GetFoodList())
                Console.WriteLine("  " + line);
            Console.WriteLine();

            Console.WriteLine("Step 2: Adding recipes");
            RecipeManager recipeManager = new RecipeManager();
            Recipe dogFood = new Recipe("Daily dog food");
            dogFood.AddIngredient("Dog kibble");
            dogFood.AddIngredient("Cooked meat");
            dogFood.AddIngredient("Carrots");
            recipeManager.Add(dogFood);
            Recipe catFood = new Recipe("Fish dinner for cats");
            catFood.AddIngredient("Fish");
            catFood.AddIngredient("Rice");
            recipeManager.Add(catFood);
            Recipe seedMix = new Recipe("Seed mix for birds");
            seedMix.AddIngredient("Mixed seeds");
            seedMix.AddIngredient("Chopped greens");
            recipeManager.Add(seedMix);
            PrintRecipes(recipeManager);
            Console.WriteLine();

            Console.WriteLine("Step 3: Binary serialization of the animal registry");
            animalManager.BinarySerialize(binFile);
            Console.WriteLine("Saved binary file: " + binFile);
            Console.WriteLine("Clearing the registry. Count now: " +
                ClearAnimals(animalManager));
            animalManager.BinaryDeSerialize(binFile);
            Console.WriteLine("Restored from binary file. Count now: " + animalManager.Count);
            PrintAnimals(animalManager);
            Console.WriteLine();

            Console.WriteLine("Step 4: Text file save and reload of the animal registry");
            animalManager.SaveToTextFile(txtFile);
            Console.WriteLine("Saved text file: " + txtFile);
            Console.WriteLine("Text file content:");
            Console.WriteLine(File.ReadAllText(txtFile));
            AnimalManager textManager = new AnimalManager();
            textManager.LoadFromTextFile(txtFile);
            Console.WriteLine("Reloaded from text file. Count: " + textManager.Count);
            PrintAnimals(textManager);
            Console.WriteLine();

            Console.WriteLine("Step 5: XML export of the recipes, names and ingredients");
            recipeManager.XMLSerialize(xmlFile);
            Console.WriteLine("Saved XML file: " + xmlFile);
            Console.WriteLine("XML file content:");
            Console.WriteLine(File.ReadAllText(xmlFile));
            recipeManager.Clear();
            Console.WriteLine("Cleared the recipe manager. Count now: " + recipeManager.Count);
            recipeManager.XMLDeSerialize(xmlFile);
            Console.WriteLine("Imported from XML file. Count now: " + recipeManager.Count);
            PrintRecipes(recipeManager);
            Console.WriteLine();

            Console.WriteLine("Step 6: Custom exception AnimalMotelException");
            try
            {
                animalManager.AddAnimal(new Dog("", 2, GenderType.Male, 10.0));
                Console.WriteLine("ERROR: no exception was thrown.");
            }
            catch (AnimalMotelException ex)
            {
                Console.WriteLine("Caught AnimalMotelException: " + ex.Message);
            }
            try
            {
                animalManager.AddAnimal(null);
                Console.WriteLine("ERROR: no exception was thrown for null.");
            }
            catch (AnimalMotelException ex)
            {
                Console.WriteLine("Caught AnimalMotelException: " + ex.Message);
            }
            Console.WriteLine();
            Console.WriteLine("Demo files created: Demo1.bin, Demo1.xml, Demo1.txt");
            Console.WriteLine("=== Harness finished ===");
        }

        private static int ClearAnimals(AnimalManager manager)
        {
            manager.Clear();
            return manager.Count;
        }

        private static void PrintAnimals(AnimalManager manager)
        {
            Console.WriteLine("Animals in the registry: " + manager.Count);
            foreach (string line in manager.ToStringList())
                Console.WriteLine("  " + line);
        }

        private static void PrintRecipes(RecipeManager manager)
        {
            Console.WriteLine("Recipes in the manager: " + manager.Count);
            foreach (string line in manager.ToStringList())
                Console.WriteLine("  " + line);
        }
    }
}

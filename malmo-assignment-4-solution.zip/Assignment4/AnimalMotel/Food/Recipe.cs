using System;
using System.Collections.Generic;

namespace AnimalMotel.Food
{
    /// <summary>
    /// A recipe with a name and a list of ingredients.
    /// Assignment 4 change: the ingredients are held in a public
    /// List of string property, and the class has a parameterless
    /// constructor plus public settable properties, so that the
    /// XmlSerializer can carry both the name AND the ingredients.
    /// </summary>
    [Serializable]
    public class Recipe
    {
        public Recipe()
        {
            Ingredients = new List<string>();
        }

        public Recipe(string name)
            : this()
        {
            Name = name;
        }

        public string Name { get; set; }

        public List<string> Ingredients { get; set; }

        public void AddIngredient(string ingredient)
        {
            if (!string.IsNullOrWhiteSpace(ingredient))
                Ingredients.Add(ingredient.Trim());
        }

        public override string ToString()
        {
            return string.Format("{0}: {1}", Name, string.Join(", ", Ingredients.ToArray()));
        }
    }
}

using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace AnimalMotel.Utilities
{
    /// <summary>
    /// Utility class for XML serialization of a List of T.
    /// The methods in this class do NOT catch exceptions. The streams are
    /// closed by using statements, and any exception travels up to the
    /// caller. Only the GUI may show error messages to the user.
    /// </summary>
    public static class XMLSerializerUtility
    {
        public static void XMLSerialize<T>(List<T> list, string fileName)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<T>));
            using (StreamWriter writer = new StreamWriter(fileName))
            {
                serializer.Serialize(writer, list);
            }
        }

        public static List<T> XMLDeSerialize<T>(string fileName)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<T>));
            using (StreamReader reader = new StreamReader(fileName))
            {
                return (List<T>)serializer.Deserialize(reader);
            }
        }
    }
}

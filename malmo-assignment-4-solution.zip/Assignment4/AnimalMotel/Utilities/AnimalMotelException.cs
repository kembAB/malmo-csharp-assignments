using System;

namespace AnimalMotel.Utilities
{
    /// <summary>
    /// VG item: a custom exception for Animal Motel rule violations.
    /// AnimalManager throws this exception when an animal cannot be
    /// accepted into the registry, and the GUI catches it and shows the
    /// message to the user.
    /// </summary>
    [Serializable]
    public class AnimalMotelException : Exception
    {
        public AnimalMotelException()
        {
        }

        public AnimalMotelException(string message)
            : base(message)
        {
        }

        public AnimalMotelException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}

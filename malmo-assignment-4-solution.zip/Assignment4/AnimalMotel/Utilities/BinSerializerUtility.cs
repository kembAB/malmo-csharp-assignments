#pragma warning disable SYSLIB0011
// BinaryFormatter is obsolete in .NET 8 and disabled by default, but
// Assignment 4 explicitly demands binary serialization with
// BinaryFormatter, so the project enables it in the csproj file and the
// SYSLIB0011 warning is suppressed here.
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace AnimalMotel.Utilities
{
    /// <summary>
    /// Utility class for binary serialization of a List of T.
    /// The methods in this class do NOT catch exceptions. The stream is
    /// closed by a using statement, and any exception travels up to the
    /// caller. Only the GUI may show error messages to the user.
    /// </summary>
    public static class BinSerializerUtility
    {
        public static void BinarySerialize<T>(List<T> list, string fileName)
        {
            using (FileStream stream = new FileStream(fileName, FileMode.Create, FileAccess.Write))
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, list);
            }
        }

        public static List<T> BinaryDeSerialize<T>(string fileName)
        {
            using (FileStream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                BinaryFormatter formatter = new BinaryFormatter();
                return (List<T>)formatter.Deserialize(stream);
            }
        }
    }
}
#pragma warning restore SYSLIB0011

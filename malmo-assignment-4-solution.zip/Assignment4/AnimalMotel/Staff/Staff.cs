using AnimalMotel.Managers;

namespace AnimalMotel.Staff
{
    /// <summary>
    /// A staff member with a name and a list of qualifications.
    /// The qualifications field is typed as the interface
    /// IListManager of string and filled with a ListManager of string,
    /// exactly as Assignment 3 prescribed, to show interface based
    /// polymorphism.
    /// </summary>
    public class Staff
    {
        private IListManager<string> qualifications = new ListManager<string>();

        public Staff()
        {
        }

        public Staff(string name)
        {
            Name = name;
        }

        public string Name { get; set; }

        public IListManager<string> Qualifications
        {
            get { return qualifications; }
        }

        public void AddQualification(string qualification)
        {
            if (!string.IsNullOrWhiteSpace(qualification))
                qualifications.Add(qualification.Trim());
        }

        public string[] GetQualificationStrings()
        {
            return qualifications.ToStringArray();
        }

        public override string ToString()
        {
            return string.Format("{0}: {1}", Name,
                string.Join(", ", qualifications.ToStringArray()));
        }
    }
}

using System;
using System.Windows.Forms;
using StaffMember = AnimalMotel.Staff.Staff;

namespace AnimalMotel.Forms
{
    /// <summary>
    /// Dialog for entering a staff member: a name plus qualifications
    /// stored through the interface typed list inside the Staff object.
    /// </summary>
    public class StaffForm : Form
    {
        private TextBox txtStaffName;
        private TextBox txtQualification;
        private ListBox lstQualifications;
        private StaffMember currentStaff = new StaffMember();

        public StaffForm()
        {
            BuildControls();
        }

        public StaffMember Staff
        {
            get { return currentStaff; }
        }

        private void BuildControls()
        {
            Text = "Staff";
            Width = 420;
            Height = 380;
            StartPosition = FormStartPosition.CenterParent;

            Label lblName = new Label { Text = "Staff name", Left = 16, Top = 16, Width = 120 };
            txtStaffName = new TextBox { Left = 16, Top = 40, Width = 240 };
            Label lblQualification = new Label { Text = "Qualification", Left = 16, Top = 76, Width = 120 };
            txtQualification = new TextBox { Left = 16, Top = 100, Width = 240 };

            Button btnAdd = new Button { Text = "Add", Left = 16, Top = 132, Width = 110 };
            btnAdd.Click += btnAdd_Click;
            Button btnChange = new Button { Text = "Change", Left = 134, Top = 132, Width = 110 };
            btnChange.Click += btnChange_Click;
            Button btnDelete = new Button { Text = "Delete", Left = 252, Top = 132, Width = 110 };
            btnDelete.Click += btnDelete_Click;

            lstQualifications = new ListBox { Left = 16, Top = 168, Width = 360, Height = 110 };
            lstQualifications.SelectedIndexChanged += lstQualifications_SelectedIndexChanged;

            Button btnOk = new Button { Text = "OK", Left = 136, Top = 292, Width = 110, DialogResult = DialogResult.OK };
            Button btnCancel = new Button { Text = "Cancel", Left = 254, Top = 292, Width = 110, DialogResult = DialogResult.Cancel };

            Controls.AddRange(new Control[]
            {
                lblName, txtStaffName, lblQualification, txtQualification,
                btnAdd, btnChange, btnDelete, lstQualifications, btnOk, btnCancel
            });
            AcceptButton = btnOk;
            CancelButton = btnCancel;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            currentStaff.Name = txtStaffName.Text.Trim();
            currentStaff.AddQualification(txtQualification.Text);
            txtQualification.Clear();
            UpdateList();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            int index = lstQualifications.SelectedIndex;
            if (index >= 0)
            {
                currentStaff.Qualifications.ChangeAt(txtQualification.Text.Trim(), index);
                UpdateList();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int index = lstQualifications.SelectedIndex;
            if (index >= 0)
            {
                currentStaff.Qualifications.DeleteAt(index);
                UpdateList();
            }
        }

        private void lstQualifications_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = lstQualifications.SelectedIndex;
            if (index >= 0)
                txtQualification.Text = currentStaff.Qualifications.GetAt(index);
        }

        private void UpdateList()
        {
            lstQualifications.Items.Clear();
            lstQualifications.Items.AddRange(currentStaff.GetQualificationStrings());
        }
    }
}

using System;
using System.Windows.Forms;
using AnimalMotel.Animals;
using AnimalMotel.Managers;
using StaffMember = AnimalMotel.Staff.Staff;

namespace AnimalMotel.Forms
{
    /// <summary>
    /// Main window of Apu's Animal Motel, Version 4.
    /// The File menu, built on the MenuStrip named mnuFile, drives all
    /// persistence: binary serialization, plain text files and XML
    /// export and import of recipes. Every file handler catches
    /// exceptions here in the GUI and shows the message, because error
    /// messages are shown only by the GUI, never by the utilities or
    /// the managers. No file path is hard coded anywhere; every path
    /// comes from a file dialog.
    /// </summary>
    public class MainForm : Form
    {
        private AnimalManager animalManager;
        private RecipeManager recipeManager;
        private StaffMember staff;

        // The file remembered between Open, Save As and Save, plus a
        // flag telling whether that file holds binary or text data.
        private string currentFileName;
        private bool currentFileIsBinary;
        private bool dataSaved;

        private MenuStrip mnuFile;
        private ToolStripMenuItem mnuFileNew;
        private ToolStripMenuItem mnuFileOpen;
        private ToolStripMenuItem mnuFileSave;
        private ToolStripMenuItem mnuFileSaveAs;
        private ToolStripMenuItem mnuFileExportToXml;
        private ToolStripMenuItem mnuFileImportFromXml;
        private ToolStripMenuItem mnuFileExit;

        private TextBox txtName;
        private TextBox txtAge;
        private TextBox txtSpecific;
        private ComboBox cmbSpecies;
        private ComboBox cmbGender;
        private Label lblSpecific;
        private ListBox lstAnimals;
        private ListBox lstFoodSchedule;

        public MainForm()
        {
            InitializeRegistry();
            BuildMenu();
            BuildControls();
            UpdateAnimalList();
        }

        private void InitializeRegistry()
        {
            animalManager = new AnimalManager();
            recipeManager = new RecipeManager();
            staff = new StaffMember();
            currentFileName = null;
            currentFileIsBinary = true;
            dataSaved = true;
        }

        private void BuildMenu()
        {
            mnuFile = new MenuStrip();
            ToolStripMenuItem fileMenu = new ToolStripMenuItem("File");

            mnuFileNew = new ToolStripMenuItem("New");
            mnuFileNew.Click += mnuFileNew_Click;
            mnuFileOpen = new ToolStripMenuItem("Open");
            mnuFileOpen.Click += mnuFileOpen_Click;
            mnuFileSave = new ToolStripMenuItem("Save");
            mnuFileSave.Click += mnuFileSave_Click;
            mnuFileSaveAs = new ToolStripMenuItem("Save As");
            mnuFileSaveAs.Click += mnuFileSaveAs_Click;
            mnuFileExportToXml = new ToolStripMenuItem("Export to XML File");
            mnuFileExportToXml.Click += mnuFileExportToXml_Click;
            mnuFileImportFromXml = new ToolStripMenuItem("Import from XML File");
            mnuFileImportFromXml.Click += mnuFileImportFromXml_Click;
            mnuFileExit = new ToolStripMenuItem("Exit");
            mnuFileExit.Click += mnuFileExit_Click;

            fileMenu.DropDownItems.AddRange(new ToolStripItem[]
            {
                mnuFileNew, mnuFileOpen, mnuFileSave, mnuFileSaveAs,
                new ToolStripSeparator(),
                mnuFileExportToXml, mnuFileImportFromXml,
                new ToolStripSeparator(),
                mnuFileExit
            });
            mnuFile.Items.Add(fileMenu);
            MainMenuStrip = mnuFile;
            Controls.Add(mnuFile);
        }

        private void BuildControls()
        {
            Text = "Apu's Animal Motel - Version 4";
            Width = 760;
            Height = 560;
            StartPosition = FormStartPosition.CenterScreen;

            Label lblSpecies = new Label { Text = "Species", Left = 16, Top = 40, Width = 80 };
            cmbSpecies = new ComboBox { Left = 16, Top = 64, Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbSpecies.Items.AddRange(new object[] { "Dog", "Cat", "Dove", "Eagle", "Butterfly", "Bee" });
            cmbSpecies.SelectedIndex = 0;
            cmbSpecies.SelectedIndexChanged += cmbSpecies_SelectedIndexChanged;

            Label lblName = new Label { Text = "Name", Left = 16, Top = 100, Width = 80 };
            txtName = new TextBox { Left = 16, Top = 124, Width = 180 };
            Label lblAge = new Label { Text = "Age", Left = 16, Top = 156, Width = 80 };
            txtAge = new TextBox { Left = 16, Top = 180, Width = 180 };
            Label lblGender = new Label { Text = "Gender", Left = 16, Top = 212, Width = 80 };
            cmbGender = new ComboBox { Left = 16, Top = 236, Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbGender.Items.AddRange(Enum.GetNames(typeof(GenderType)));
            cmbGender.SelectedIndex = 0;

            lblSpecific = new Label { Text = "Tail length in cm", Left = 16, Top = 268, Width = 180 };
            txtSpecific = new TextBox { Left = 16, Top = 292, Width = 180 };

            Button btnAdd = new Button { Text = "Add animal", Left = 16, Top = 332, Width = 110 };
            btnAdd.Click += btnAdd_Click;
            Button btnChange = new Button { Text = "Change", Left = 134, Top = 332, Width = 110 };
            btnChange.Click += btnChange_Click;
            Button btnDelete = new Button { Text = "Delete", Left = 252, Top = 332, Width = 110 };
            btnDelete.Click += btnDelete_Click;

            Button btnRecipe = new Button { Text = "Recipes", Left = 16, Top = 372, Width = 110 };
            btnRecipe.Click += btnRecipe_Click;
            Button btnStaff = new Button { Text = "Add staff", Left = 134, Top = 372, Width = 110 };
            btnStaff.Click += btnStaff_Click;

            Label lblAnimals = new Label { Text = "Animal registry", Left = 380, Top = 40, Width = 200 };
            lstAnimals = new ListBox { Left = 380, Top = 64, Width = 350, Height = 220 };
            lstAnimals.SelectedIndexChanged += lstAnimals_SelectedIndexChanged;

            Label lblFood = new Label { Text = "Food schedule of the selected animal", Left = 380, Top = 296, Width = 300 };
            lstFoodSchedule = new ListBox { Left = 380, Top = 320, Width = 350, Height = 110 };

            Controls.AddRange(new Control[]
            {
                lblSpecies, cmbSpecies, lblName, txtName, lblAge, txtAge,
                lblGender, cmbGender, lblSpecific, txtSpecific,
                btnAdd, btnChange, btnDelete, btnRecipe, btnStaff,
                lblAnimals, lstAnimals, lblFood, lstFoodSchedule
            });
        }

        // ---------------------------------------------------------------
        // File menu handlers. Each one wraps the manager call in a try
        // catch and shows the exception Message in a MessageBox.
        // ---------------------------------------------------------------

        private void mnuFileNew_Click(object sender, EventArgs e)
        {
            try
            {
                if (!dataSaved)
                {
                    DialogResult answer = MessageBox.Show(
                        "Current data has not been saved. Do you want to continue without saving?",
                        "New registry", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (answer == DialogResult.No)
                        return;
                }
                InitializeRegistry();
                UpdateAnimalList();
                lstFoodSchedule.Items.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            try
            {
                using (OpenFileDialog dialog = new OpenFileDialog())
                {
                    dialog.Filter = "Binary files (*.bin)|*.bin|Text files (*.txt)|*.txt|All files (*.*)|*.*";
                    dialog.Title = "Open animal registry";
                    if (dialog.ShowDialog() != DialogResult.OK)
                        return;

                    if (dialog.FilterIndex == 2)
                    {
                        animalManager.LoadFromTextFile(dialog.FileName);
                        currentFileIsBinary = false;
                    }
                    else
                    {
                        animalManager.BinaryDeSerialize(dialog.FileName);
                        currentFileIsBinary = true;
                    }
                    currentFileName = dialog.FileName;
                    dataSaved = true;
                    UpdateAnimalList();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mnuFileSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(currentFileName))
                {
                    mnuFileSaveAs_Click(sender, e);
                    return;
                }
                if (currentFileIsBinary)
                    animalManager.BinarySerialize(currentFileName);
                else
                    animalManager.SaveToTextFile(currentFileName);
                dataSaved = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mnuFileSaveAs_Click(object sender, EventArgs e)
        {
            try
            {
                using (SaveFileDialog dialog = new SaveFileDialog())
                {
                    dialog.Filter = "Binary files (*.bin)|*.bin|Text files (*.txt)|*.txt|All files (*.*)|*.*";
                    dialog.Title = "Save animal registry as";
                    if (dialog.ShowDialog() != DialogResult.OK)
                        return;

                    if (dialog.FilterIndex == 2)
                    {
                        animalManager.SaveToTextFile(dialog.FileName);
                        currentFileIsBinary = false;
                    }
                    else
                    {
                        animalManager.BinarySerialize(dialog.FileName);
                        currentFileIsBinary = true;
                    }
                    currentFileName = dialog.FileName;
                    dataSaved = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mnuFileExportToXml_Click(object sender, EventArgs e)
        {
            try
            {
                using (SaveFileDialog dialog = new SaveFileDialog())
                {
                    dialog.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";
                    dialog.Title = "Export recipes to XML file";
                    if (dialog.ShowDialog() != DialogResult.OK)
                        return;
                    recipeManager.XMLSerialize(dialog.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mnuFileImportFromXml_Click(object sender, EventArgs e)
        {
            try
            {
                using (OpenFileDialog dialog = new OpenFileDialog())
                {
                    dialog.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";
                    dialog.Title = "Import recipes from XML file";
                    if (dialog.ShowDialog() != DialogResult.OK)
                        return;
                    recipeManager.XMLDeSerialize(dialog.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        // ---------------------------------------------------------------
        // Animal and dialog buttons
        // ---------------------------------------------------------------

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Animal animal = ReadAnimalFromGui();
                animalManager.AddAnimal(animal);
                dataSaved = false;
                UpdateAnimalList();
            }
            catch (Exception ex)
            {
                // This catch also handles the custom AnimalMotelException
                // thrown by AddAnimal for an empty animal name.
                MessageBox.Show(ex.Message);
            }
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            try
            {
                int index = lstAnimals.SelectedIndex;
                if (index < 0)
                    return;
                Animal animal = ReadAnimalFromGui();
                animal.Id = animalManager.GetAt(index).Id;
                animalManager.ChangeAt(animal, index);
                dataSaved = false;
                UpdateAnimalList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int index = lstAnimals.SelectedIndex;
            if (index >= 0)
            {
                animalManager.DeleteAt(index);
                dataSaved = false;
                UpdateAnimalList();
            }
        }

        private void btnRecipe_Click(object sender, EventArgs e)
        {
            using (RecipeForm form = new RecipeForm(recipeManager))
            {
                form.ShowDialog(this);
            }
            dataSaved = false;
        }

        private void btnStaff_Click(object sender, EventArgs e)
        {
            using (StaffForm form = new StaffForm())
            {
                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    staff = form.Staff;
                    MessageBox.Show("Staff member saved: " + staff.ToString());
                }
            }
        }

        private Animal ReadAnimalFromGui()
        {
            string species = cmbSpecies.SelectedItem.ToString();
            string name = txtName.Text.Trim();
            int age;
            if (!int.TryParse(txtAge.Text.Trim(), out age))
                age = 0;
            GenderType gender = (GenderType)Enum.Parse(typeof(GenderType), cmbGender.SelectedItem.ToString());
            string specific = txtSpecific.Text.Trim();

            double number;
            switch (species)
            {
                case "Dog":
                    double.TryParse(specific, out number);
                    return new Dog(name, age, gender, number);
                case "Cat":
                    return new Cat(name, age, gender, specific);
                case "Dove":
                    double.TryParse(specific, out number);
                    return new Dove(name, age, gender, number);
                case "Eagle":
                    double.TryParse(specific, out number);
                    return new Eagle(name, age, gender, number);
                case "Butterfly":
                    return new Butterfly(name, age, gender, specific);
                default:
                    int wings;
                    int.TryParse(specific, out wings);
                    return new Bee(name, age, gender, wings);
            }
        }

        private void cmbSpecies_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbSpecies.SelectedItem.ToString())
            {
                case "Dog": lblSpecific.Text = "Tail length in cm"; break;
                case "Cat": lblSpecific.Text = "Breed"; break;
                case "Dove": lblSpecific.Text = "Wing span in cm"; break;
                case "Eagle": lblSpecific.Text = "Beak length in cm"; break;
                case "Butterfly": lblSpecific.Text = "Wing colour"; break;
                default: lblSpecific.Text = "Number of wings"; break;
            }
        }

        private void lstAnimals_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = lstAnimals.SelectedIndex;
            if (index < 0)
                return;
            Animal animal = animalManager.GetAt(index);
            lstFoodSchedule.Items.Clear();
            lstFoodSchedule.Items.Add("Eater type: " + animal.GetEaterType());
            lstFoodSchedule.Items.AddRange(animal.GetFoodSchedule().GetFoodList());
        }

        private void UpdateAnimalList()
        {
            lstAnimals.Items.Clear();
            lstAnimals.Items.AddRange(animalManager.ToStringArray());
        }
    }
}

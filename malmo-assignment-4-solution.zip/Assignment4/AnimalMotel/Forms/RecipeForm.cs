using System;
using System.Windows.Forms;
using AnimalMotel.Food;
using AnimalMotel.Managers;

namespace AnimalMotel.Forms
{
    /// <summary>
    /// Dialog for entering recipes: a name plus ingredients, with Add,
    /// Change and Delete working on the shared RecipeManager.
    /// </summary>
    public class RecipeForm : Form
    {
        private readonly RecipeManager recipeManager;
        private TextBox txtRecipeName;
        private TextBox txtIngredient;
        private ListBox lstIngredients;
        private ListBox lstRecipes;
        private Recipe currentRecipe = new Recipe();

        public RecipeForm(RecipeManager recipeManager)
        {
            this.recipeManager = recipeManager;
            BuildControls();
            UpdateRecipeList();
        }

        public Recipe Recipe
        {
            get { return currentRecipe; }
        }

        private void BuildControls()
        {
            Text = "Recipe";
            Width = 520;
            Height = 420;
            StartPosition = FormStartPosition.CenterParent;

            Label lblName = new Label { Text = "Recipe name", Left = 16, Top = 16, Width = 120 };
            txtRecipeName = new TextBox { Left = 16, Top = 40, Width = 220 };
            Label lblIngredient = new Label { Text = "Ingredient", Left = 16, Top = 76, Width = 120 };
            txtIngredient = new TextBox { Left = 16, Top = 100, Width = 220 };

            Button btnAddIngredient = new Button { Text = "Add ingredient", Left = 16, Top = 132, Width = 140 };
            btnAddIngredient.Click += btnAddIngredient_Click;
            Button btnDeleteIngredient = new Button { Text = "Delete ingredient", Left = 164, Top = 132, Width = 140 };
            btnDeleteIngredient.Click += btnDeleteIngredient_Click;

            lstIngredients = new ListBox { Left = 16, Top = 168, Width = 288, Height = 120 };

            Button btnAdd = new Button { Text = "Add recipe", Left = 16, Top = 300, Width = 110 };
            btnAdd.Click += btnAdd_Click;
            Button btnChange = new Button { Text = "Change", Left = 134, Top = 300, Width = 110 };
            btnChange.Click += btnChange_Click;
            Button btnDelete = new Button { Text = "Delete", Left = 252, Top = 300, Width = 110 };
            btnDelete.Click += btnDelete_Click;
            Button btnOk = new Button { Text = "OK", Left = 370, Top = 300, Width = 110, DialogResult = DialogResult.OK };

            Label lblRecipes = new Label { Text = "Saved recipes", Left = 320, Top = 16, Width = 160 };
            lstRecipes = new ListBox { Left = 320, Top = 40, Width = 170, Height = 248 };
            lstRecipes.SelectedIndexChanged += lstRecipes_SelectedIndexChanged;

            Controls.AddRange(new Control[]
            {
                lblName, txtRecipeName, lblIngredient, txtIngredient,
                btnAddIngredient, btnDeleteIngredient, lstIngredients,
                btnAdd, btnChange, btnDelete, btnOk, lblRecipes, lstRecipes
            });
            AcceptButton = btnOk;
        }

        private void btnAddIngredient_Click(object sender, EventArgs e)
        {
            currentRecipe.AddIngredient(txtIngredient.Text);
            txtIngredient.Clear();
            UpdateIngredientList();
        }

        private void btnDeleteIngredient_Click(object sender, EventArgs e)
        {
            int index = lstIngredients.SelectedIndex;
            if (index >= 0 && index < currentRecipe.Ingredients.Count)
            {
                currentRecipe.Ingredients.RemoveAt(index);
                UpdateIngredientList();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                currentRecipe.Name = txtRecipeName.Text.Trim();
                if (string.IsNullOrEmpty(currentRecipe.Name))
                {
                    MessageBox.Show("Give the recipe a name first.");
                    return;
                }
                recipeManager.Add(currentRecipe);
                currentRecipe = new Recipe();
                txtRecipeName.Clear();
                UpdateIngredientList();
                UpdateRecipeList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            int index = lstRecipes.SelectedIndex;
            if (index < 0)
                return;
            currentRecipe.Name = txtRecipeName.Text.Trim();
            recipeManager.ChangeAt(currentRecipe, index);
            UpdateRecipeList();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int index = lstRecipes.SelectedIndex;
            if (index >= 0)
            {
                recipeManager.DeleteAt(index);
                currentRecipe = new Recipe();
                txtRecipeName.Clear();
                UpdateIngredientList();
                UpdateRecipeList();
            }
        }

        private void lstRecipes_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = lstRecipes.SelectedIndex;
            if (index < 0)
                return;
            currentRecipe = recipeManager.GetAt(index);
            txtRecipeName.Text = currentRecipe.Name;
            UpdateIngredientList();
        }

        private void UpdateIngredientList()
        {
            lstIngredients.Items.Clear();
            lstIngredients.Items.AddRange(currentRecipe.Ingredients.ToArray());
        }

        private void UpdateRecipeList()
        {
            lstRecipes.Items.Clear();
            lstRecipes.Items.AddRange(recipeManager.ToStringArray());
        }
    }
}

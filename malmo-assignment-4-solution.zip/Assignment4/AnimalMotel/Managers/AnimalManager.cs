using System.IO;
using AnimalMotel.Animals;
using AnimalMotel.Utilities;

namespace AnimalMotel.Managers
{
    /// <summary>
    /// Manager for the animal registry. It inherits all list operations
    /// and all four serialization methods from ListManager of Animal and
    /// adds id generation, validation and plain text file handling.
    ///
    /// Text file format: one animal per line, fields separated by
    /// semicolons, species name first, then name, age, gender and the
    /// species specific value. See AnimalFactory for the exact rules.
    /// Example line: Dog;Rex;5;Male;25.5
    /// </summary>
    public class AnimalManager : ListManager<Animal>
    {
        private int idCounter = 0;

        /// <summary>
        /// Adds an animal after giving it a fresh unique id.
        /// VG item: throws the custom AnimalMotelException when the
        /// animal is null or its name is empty.
        /// </summary>
        public void AddAnimal(Animal animal)
        {
            if (animal == null)
                throw new AnimalMotelException("The animal is null and cannot be added to the registry.");
            if (string.IsNullOrWhiteSpace(animal.Name))
                throw new AnimalMotelException("The animal must have a name. An animal with an empty name cannot be added to the registry.");

            idCounter++;
            animal.Id = idCounter.ToString("D3");
            Add(animal);
        }

        /// <summary>Saves the whole registry to a plain text file.</summary>
        public void SaveToTextFile(string fileName)
        {
            using (StreamWriter writer = new StreamWriter(fileName))
            {
                for (int i = 0; i < Count; i++)
                    writer.WriteLine(AnimalFactory.ToTextLine(GetAt(i)));
            }
        }

        /// <summary>
        /// Loads the registry from a plain text file, replacing the
        /// current contents. Each line is parsed back into the right
        /// species by AnimalFactory.
        /// </summary>
        public void LoadFromTextFile(string fileName)
        {
            Clear();
            idCounter = 0;
            using (StreamReader reader = new StreamReader(fileName))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    Animal animal = AnimalFactory.FromTextLine(line);
                    if (animal != null)
                        AddAnimal(animal);
                }
            }
        }
    }
}

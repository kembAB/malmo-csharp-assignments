using AnimalMotel.Food;

namespace AnimalMotel.Managers
{
    /// <summary>
    /// Manager for recipes. The whole class is this inheritance, as the
    /// assignment prescribes: every operation, including the Assignment 4
    /// XML and binary serialization, comes from ListManager of Recipe.
    /// </summary>
    public class RecipeManager : ListManager<Recipe>
    {
    }
}

using System.Collections.Generic;
using AnimalMotel.Utilities;

namespace AnimalMotel.Managers
{
    /// <summary>
    /// Generic container class built on a private List of T. It implements
    /// IListManager and is reused for animals, recipes and plain strings.
    /// The four serialization methods delegate the real work to the two
    /// utility classes and never catch exceptions themselves.
    /// </summary>
    public class ListManager<T> : IListManager<T>
    {
        private List<T> list = new List<T>();

        public int Count
        {
            get { return list.Count; }
        }

        public bool Add(T type)
        {
            if (type == null)
                return false;
            list.Add(type);
            return true;
        }

        public bool CheckIndex(int index)
        {
            return index >= 0 && index < list.Count;
        }

        public void Clear()
        {
            list.Clear();
        }

        public bool DeleteAt(int index)
        {
            if (!CheckIndex(index))
                return false;
            list.RemoveAt(index);
            return true;
        }

        public T GetAt(int index)
        {
            if (!CheckIndex(index))
                return default(T);
            return list[index];
        }

        public bool ChangeAt(T type, int index)
        {
            if (!CheckIndex(index) || type == null)
                return false;
            list[index] = type;
            return true;
        }

        public string[] ToStringArray()
        {
            return ToStringList().ToArray();
        }

        public List<string> ToStringList()
        {
            List<string> result = new List<string>();
            foreach (T item in list)
                result.Add(item == null ? string.Empty : item.ToString());
            return result;
        }

        // Assignment 4: persistence. Deserialization replaces the
        // current contents of the private list with the loaded list.
        public void BinarySerialize(string fileName)
        {
            BinSerializerUtility.BinarySerialize(list, fileName);
        }

        public void BinaryDeSerialize(string fileName)
        {
            list = BinSerializerUtility.BinaryDeSerialize<T>(fileName);
        }

        public void XMLSerialize(string fileName)
        {
            XMLSerializerUtility.XMLSerialize(list, fileName);
        }

        public void XMLDeSerialize(string fileName)
        {
            list = XMLSerializerUtility.XMLDeSerialize<T>(fileName);
        }
    }
}

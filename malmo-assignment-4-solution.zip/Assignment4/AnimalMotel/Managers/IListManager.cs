using System.Collections.Generic;

namespace AnimalMotel.Managers
{
    /// <summary>
    /// Interface for a generic list manager. It declares the ordinary list
    /// operations plus, below the Assignment 4 comment, the four
    /// serialization methods added in Version 4.
    /// </summary>
    public interface IListManager<T>
    {
        int Count { get; }

        bool Add(T type);
        bool CheckIndex(int index);
        void Clear();
        bool DeleteAt(int index);
        T GetAt(int index);
        bool ChangeAt(T type, int index);
        string[] ToStringArray();
        List<string> ToStringList();

        // -------------------------------------------------------------
        // Assignment 4 additions: persistence by serialization.
        // The methods return void because an exception, when something
        // goes wrong, carries the failure information up to the caller.
        // -------------------------------------------------------------
        void BinarySerialize(string fileName);
        void BinaryDeSerialize(string fileName);
        void XMLSerialize(string fileName);
        void XMLDeSerialize(string fileName);
    }
}

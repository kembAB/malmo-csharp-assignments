using System;
using System.Xml.Serialization;

namespace AnimalMotel.Animals
{
    /// <summary>
    /// Abstract base class for every animal kept at the motel.
    /// The XmlInclude attributes register all known species so that the
    /// XmlSerializer can also handle a list of Animal references.
    /// </summary>
    [Serializable]
    [XmlInclude(typeof(Dog))]
    [XmlInclude(typeof(Cat))]
    [XmlInclude(typeof(Dove))]
    [XmlInclude(typeof(Eagle))]
    [XmlInclude(typeof(Butterfly))]
    [XmlInclude(typeof(Bee))]
    public abstract class Animal : IAnimal
    {
        private string id;
        private string name;
        private int age;
        private GenderType gender;

        protected Animal()
        {
        }

        protected Animal(string name, int age, GenderType gender)
        {
            this.name = name;
            this.age = age;
            this.gender = gender;
        }

        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public GenderType Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        public abstract EaterType GetEaterType();
        public abstract FoodSchedule GetFoodSchedule();
        public abstract string GetSpecies();

        public override string ToString()
        {
            return string.Format("Id: {0}, Name: {1}, Species: {2}, Age: {3}, Gender: {4}, Eater: {5}",
                Id, Name, GetSpecies(), Age, Gender, GetEaterType());
        }
    }
}

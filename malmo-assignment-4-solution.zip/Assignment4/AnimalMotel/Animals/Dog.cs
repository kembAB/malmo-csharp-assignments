using System;

namespace AnimalMotel.Animals
{
    /// <summary>A dog. Specific attribute: tail length in centimetres.</summary>
    [Serializable]
    public class Dog : Mammal
    {
        public Dog()
        {
        }

        public Dog(string name, int age, GenderType gender, double tailLength)
            : base(name, age, gender)
        {
            TailLength = tailLength;
        }

        public double TailLength { get; set; }

        public override EaterType GetEaterType()
        {
            return EaterType.Omnivore;
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFood("Morning: one bowl of dog kibble with water.");
            schedule.AddFood("Midday: a small portion of cooked meat and vegetables.");
            schedule.AddFood("Evening: one bowl of dog kibble and a chew stick.");
            return schedule;
        }

        public override string GetSpecies()
        {
            return "Dog";
        }

        public override string ToString()
        {
            return base.ToString() + string.Format(", TailLength: {0} cm", TailLength);
        }
    }
}

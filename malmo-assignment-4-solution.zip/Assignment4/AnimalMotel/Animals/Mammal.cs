using System;

namespace AnimalMotel.Animals
{
    /// <summary>Abstract category class for mammals.</summary>
    [Serializable]
    public abstract class Mammal : Animal
    {
        protected Mammal()
        {
        }

        protected Mammal(string name, int age, GenderType gender)
            : base(name, age, gender)
        {
        }
    }
}

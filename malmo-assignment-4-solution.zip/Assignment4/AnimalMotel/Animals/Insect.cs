using System;

namespace AnimalMotel.Animals
{
    /// <summary>Abstract category class for insects.</summary>
    [Serializable]
    public abstract class Insect : Animal
    {
        protected Insect()
        {
        }

        protected Insect(string name, int age, GenderType gender)
            : base(name, age, gender)
        {
        }
    }
}

using System;

namespace AnimalMotel.Animals
{
    /// <summary>A butterfly. Specific attribute: wing colour.</summary>
    [Serializable]
    public class Butterfly : Insect
    {
        public Butterfly()
        {
        }

        public Butterfly(string name, int age, GenderType gender, string wingColor)
            : base(name, age, gender)
        {
            WingColor = wingColor;
        }

        public string WingColor { get; set; }

        public override EaterType GetEaterType()
        {
            return EaterType.Herbivore;
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFood("All day: nectar from flowers in the enclosure.");
            schedule.AddFood("Afternoon: sugar water on a sponge.");
            return schedule;
        }

        public override string GetSpecies()
        {
            return "Butterfly";
        }

        public override string ToString()
        {
            return base.ToString() + string.Format(", WingColor: {0}", WingColor);
        }
    }
}

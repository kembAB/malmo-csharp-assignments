using System;

namespace AnimalMotel.Animals
{
    /// <summary>A bee. Specific attribute: number of wings.</summary>
    [Serializable]
    public class Bee : Insect
    {
        public Bee()
        {
        }

        public Bee(string name, int age, GenderType gender, int numberOfWings)
            : base(name, age, gender)
        {
            NumberOfWings = numberOfWings;
        }

        public int NumberOfWings { get; set; }

        public override EaterType GetEaterType()
        {
            return EaterType.Herbivore;
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFood("All day: pollen and nectar from the flower box.");
            schedule.AddFood("Evening: a drop of honey water.");
            return schedule;
        }

        public override string GetSpecies()
        {
            return "Bee";
        }

        public override string ToString()
        {
            return base.ToString() + string.Format(", NumberOfWings: {0}", NumberOfWings);
        }
    }
}

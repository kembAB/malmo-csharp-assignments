using System;

namespace AnimalMotel.Animals
{
    /// <summary>An eagle. Specific attribute: beak length in centimetres.</summary>
    [Serializable]
    public class Eagle : Bird
    {
        public Eagle()
        {
        }

        public Eagle(string name, int age, GenderType gender, double beakLength)
            : base(name, age, gender)
        {
            BeakLength = beakLength;
        }

        public double BeakLength { get; set; }

        public override EaterType GetEaterType()
        {
            return EaterType.Carnivore;
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFood("Morning: raw meat strips.");
            schedule.AddFood("Evening: a whole fish or a small rodent portion.");
            return schedule;
        }

        public override string GetSpecies()
        {
            return "Eagle";
        }

        public override string ToString()
        {
            return base.ToString() + string.Format(", BeakLength: {0} cm", BeakLength);
        }
    }
}

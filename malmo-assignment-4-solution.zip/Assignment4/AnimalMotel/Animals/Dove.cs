using System;

namespace AnimalMotel.Animals
{
    /// <summary>A dove. Specific attribute: wing span in centimetres.</summary>
    [Serializable]
    public class Dove : Bird
    {
        public Dove()
        {
        }

        public Dove(string name, int age, GenderType gender, double wingSpan)
            : base(name, age, gender)
        {
            WingSpan = wingSpan;
        }

        public double WingSpan { get; set; }

        public override EaterType GetEaterType()
        {
            return EaterType.Herbivore;
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFood("Morning: a handful of mixed seeds.");
            schedule.AddFood("Afternoon: chopped greens and grit.");
            return schedule;
        }

        public override string GetSpecies()
        {
            return "Dove";
        }

        public override string ToString()
        {
            return base.ToString() + string.Format(", WingSpan: {0} cm", WingSpan);
        }
    }
}

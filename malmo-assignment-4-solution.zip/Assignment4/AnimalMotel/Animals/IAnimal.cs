namespace AnimalMotel.Animals
{
    /// <summary>
    /// Interface implemented by the abstract Animal class and, through it,
    /// by every concrete species in the motel.
    /// </summary>
    public interface IAnimal
    {
        string Id { get; set; }
        string Name { get; set; }
        int Age { get; set; }
        GenderType Gender { get; set; }

        EaterType GetEaterType();
        FoodSchedule GetFoodSchedule();
        string GetSpecies();
    }
}

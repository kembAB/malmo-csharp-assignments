using System;
using System.Globalization;

namespace AnimalMotel.Animals
{
    /// <summary>
    /// Small factory that creates animals by species name. It is used by
    /// the GUI and by the text file loader in AnimalManager, which must
    /// recreate the right species from a stored species name.
    ///
    /// Text file format, one animal per line, fields separated by
    /// semicolons and the species name first:
    /// Species;Name;Age;Gender;SpeciesSpecificValue
    /// The last field is TailLength for Dog, Breed for Cat, WingSpan for
    /// Dove, BeakLength for Eagle, WingColor for Butterfly and
    /// NumberOfWings for Bee. Numbers use the invariant culture.
    /// Example: Dog;Rex;5;Male;25.5
    /// </summary>
    public static class AnimalFactory
    {
        public static Animal CreateAnimal(string species, string name, int age, GenderType gender)
        {
            switch ((species ?? string.Empty).Trim().ToLowerInvariant())
            {
                case "dog": return new Dog(name, age, gender, 20.0);
                case "cat": return new Cat(name, age, gender, "Mixed");
                case "dove": return new Dove(name, age, gender, 30.0);
                case "eagle": return new Eagle(name, age, gender, 6.0);
                case "butterfly": return new Butterfly(name, age, gender, "Orange");
                case "bee": return new Bee(name, age, gender, 4);
                default:
                    throw new ArgumentException("Unknown species: " + species);
            }
        }

        public static Animal FromTextLine(string line)
        {
            if (string.IsNullOrWhiteSpace(line))
                return null;

            string[] parts = line.Split(';');
            if (parts.Length < 5)
                throw new FormatException("Bad animal line in text file: " + line);

            string species = parts[0].Trim();
            string name = parts[1].Trim();
            int age = int.Parse(parts[2].Trim(), CultureInfo.InvariantCulture);
            GenderType gender = (GenderType)Enum.Parse(typeof(GenderType), parts[3].Trim(), true);
            string specific = parts[4].Trim();

            switch (species.ToLowerInvariant())
            {
                case "dog":
                    return new Dog(name, age, gender,
                        double.Parse(specific, CultureInfo.InvariantCulture));
                case "cat":
                    return new Cat(name, age, gender, specific);
                case "dove":
                    return new Dove(name, age, gender,
                        double.Parse(specific, CultureInfo.InvariantCulture));
                case "eagle":
                    return new Eagle(name, age, gender,
                        double.Parse(specific, CultureInfo.InvariantCulture));
                case "butterfly":
                    return new Butterfly(name, age, gender, specific);
                case "bee":
                    return new Bee(name, age, gender,
                        int.Parse(specific, CultureInfo.InvariantCulture));
                default:
                    throw new FormatException("Unknown species in text file: " + species);
            }
        }

        public static string ToTextLine(Animal animal)
        {
            string specific;
            Dog dog = animal as Dog;
            Cat cat = animal as Cat;
            Dove dove = animal as Dove;
            Eagle eagle = animal as Eagle;
            Butterfly butterfly = animal as Butterfly;
            Bee bee = animal as Bee;

            if (dog != null) specific = dog.TailLength.ToString(CultureInfo.InvariantCulture);
            else if (cat != null) specific = cat.Breed ?? string.Empty;
            else if (dove != null) specific = dove.WingSpan.ToString(CultureInfo.InvariantCulture);
            else if (eagle != null) specific = eagle.BeakLength.ToString(CultureInfo.InvariantCulture);
            else if (butterfly != null) specific = butterfly.WingColor ?? string.Empty;
            else if (bee != null) specific = bee.NumberOfWings.ToString(CultureInfo.InvariantCulture);
            else specific = string.Empty;

            return string.Join(";", new string[]
            {
                animal.GetSpecies(),
                animal.Name ?? string.Empty,
                animal.Age.ToString(CultureInfo.InvariantCulture),
                animal.Gender.ToString(),
                specific
            });
        }
    }
}

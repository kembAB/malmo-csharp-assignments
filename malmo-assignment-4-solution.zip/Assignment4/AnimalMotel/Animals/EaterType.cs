namespace AnimalMotel.Animals
{
    /// <summary>Describes what kind of food an animal species eats.</summary>
    public enum EaterType
    {
        Carnivore,
        Herbivore,
        Omnivore
    }
}

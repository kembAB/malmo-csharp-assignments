using System;

namespace AnimalMotel.Animals
{
    /// <summary>A cat. Specific attribute: breed.</summary>
    [Serializable]
    public class Cat : Mammal
    {
        public Cat()
        {
        }

        public Cat(string name, int age, GenderType gender, string breed)
            : base(name, age, gender)
        {
            Breed = breed;
        }

        public string Breed { get; set; }

        public override EaterType GetEaterType()
        {
            return EaterType.Carnivore;
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFood("Morning: wet cat food, fish flavour.");
            schedule.AddFood("Evening: dry cat food and fresh water.");
            return schedule;
        }

        public override string GetSpecies()
        {
            return "Cat";
        }

        public override string ToString()
        {
            return base.ToString() + string.Format(", Breed: {0}", Breed);
        }
    }
}

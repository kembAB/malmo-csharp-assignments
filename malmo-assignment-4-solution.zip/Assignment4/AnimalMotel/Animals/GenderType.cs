namespace AnimalMotel.Animals
{
    /// <summary>The gender of an animal.</summary>
    public enum GenderType
    {
        Female,
        Male,
        Unknown
    }
}

using System;

namespace AnimalMotel.Animals
{
    /// <summary>Abstract category class for birds.</summary>
    [Serializable]
    public abstract class Bird : Animal
    {
        protected Bird()
        {
        }

        protected Bird(string name, int age, GenderType gender)
            : base(name, age, gender)
        {
        }
    }
}

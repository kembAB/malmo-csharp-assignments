using System;
using System.Collections.Generic;

namespace AnimalMotel.Animals
{
    /// <summary>
    /// Holds the feeding plan of one species as a list of description
    /// strings, one string per feeding occasion during a day.
    /// </summary>
    [Serializable]
    public class FoodSchedule
    {
        private List<string> foodList = new List<string>();

        public int Count
        {
            get { return foodList.Count; }
        }

        public void AddFood(string description)
        {
            if (!string.IsNullOrEmpty(description))
                foodList.Add(description);
        }

        public string[] GetFoodList()
        {
            return foodList.ToArray();
        }

        public override string ToString()
        {
            return string.Join(" | ", foodList.ToArray());
        }
    }
}

using System;
using ControlTower.Events;
using ControlTower.Publisher;
using ControlTower.Subscribers;

namespace Harness
{
    /// <summary>
    /// Console subscriber that mimics the control tower message board.
    /// It plays the same subscriber role as ControlTowerWindow: handler
    /// methods matching the publisher delegate types, attached with +=,
    /// reacting by writing flight number, status and time stamp.
    /// </summary>
    public class ConsoleTower
    {
        public void Subscribe(Airplane airplane)
        {
            airplane.TakeOff += OnTakeOff;
            airplane.ChangeRoute += OnChangeRoute;
            airplane.Land += OnLand;
        }

        private void OnTakeOff(object sender, TakeOffEventArgs e)
        {
            Print(e.FlightNumber, "Took off", e.TimeStamp);
        }

        private void OnChangeRoute(object sender, ChangeRouteEventArgs e)
        {
            Print(e.FlightNumber, "Changed route to " + e.NewRoute, e.TimeStamp);
        }

        private void OnLand(object sender, LandEventArgs e)
        {
            Print(e.FlightNumber, "Landed", e.TimeStamp);
        }

        private void Print(string flightNumber, string status, DateTime timeStamp)
        {
            Console.WriteLine("TOWER | " + flightNumber + " | " + status + " | " +
                              timeStamp.ToString("yyyy-MM-dd HH:mm:ss"));
        }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Assignment 5 - The Control Tower - harness run");
            Console.WriteLine("Publisher: Airplane. Subscribers: ConsoleTower and FlightLogger.");
            Console.WriteLine();

            // Two independent flights, each with its own Airplane publisher.
            Airplane flightSK = new Airplane("SK123");
            Airplane flightLH = new Airplane("LH456");

            // One tower subscriber and one shared logger subscriber.
            ConsoleTower tower = new ConsoleTower();
            FlightLogger logger = new FlightLogger();

            // Subscriber step: attach handlers with +=.
            // The tower subscribes to all three events of both flights.
            // The logger subscribes only to TakeOff and Land.
            tower.Subscribe(flightSK);
            tower.Subscribe(flightLH);
            logger.Subscribe(flightSK);
            logger.Subscribe(flightLH);

            Console.WriteLine("--- Tower message board, live ---");

            // Interleaved flight sequence: the two flights act fully
            // independently of each other.
            flightSK.StartFlight();
            flightLH.StartFlight();
            flightSK.ChangeRouteTo("Copenhagen");
            flightLH.ChangeRouteTo("Frankfurt");
            flightSK.LandFlight();
            flightLH.LandFlight();

            Console.WriteLine();
            Console.WriteLine("--- FlightLogger lines, TakeOff and Land only ---");
            foreach (string line in logger.LogLines)
                Console.WriteLine("LOGGER | " + line);

            Console.WriteLine();
            Console.WriteLine("FlightLogger log file: " + logger.LogFilePath);
            Console.WriteLine("Flights completed: SK123 route = " + flightSK.CurrentRoute +
                              ", landed = " + flightSK.HasLanded +
                              " ; LH456 route = " + flightLH.CurrentRoute +
                              ", landed = " + flightLH.HasLanded);
        }
    }
}

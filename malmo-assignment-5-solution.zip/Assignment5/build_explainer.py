#!/usr/bin/env python3
"""Builds the Assignment 5 explainer PDF.

Hard rule for this document: the written prose contains no parentheses
at all. Clarifications live in the glossary or stand as their own bold
sentences. Verbatim code, XAML and program output are exempt from the
rule. Every prose string is asserted clean before the PDF is built.
"""
import os

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                Preformatted, PageBreak)
from reportlab.lib.enums import TA_LEFT

BASE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.join(BASE, "ControlTower")
HARNESS = os.path.join(BASE, "Harness")
OUT = os.path.join(BASE, "malmo-csharp-assignment-5-explainer.pdf")

# ----------------------------------------------------------------------
# Prose. None of these strings may contain an opening or closing
# parenthesis. The assertion loop below enforces the rule.
# ----------------------------------------------------------------------
PROSE = []

def P(text):
    PROSE.append(text)
    return text

TITLE = P("Assignment 5 — The Control Tower")
SUBTITLE = P("Malmö University — Programming in C# II")
AUTHOR = P("Author: Abel Haile Magicho")
TOPIC = P("Delegates and events — the publisher and subscriber pattern in WPF")

H_WHAT = P("What the assignment asks")
WHAT_INTRO = P("The assignment asks for a WPF application called The Control Tower, built on the publisher and subscriber pattern with delegates and events. The faithful summary of the demands is as follows.")
WHAT_POINTS = [
    P("The control tower sends airplanes to a runway. Each flight gets its own flight window with the flight number in the title bar and the logo of the airline on the window."),
    P("When the logo of the airline is unknown, a default image must appear on the flight window instead."),
    P("When an airplane takes off, changes route or lands, the airplane publishes a notification carrying the flight number and a time stamp. The control tower receives the notifications and writes the flight number, the status and the time stamp to its message board."),
    P("<b>Neither side knows the other.</b> The airplane does not know which objects receive its notifications, and the control tower holds no reference to the flights beyond the event subscriptions."),
    P("<b>No collection of flights may be kept by the control tower.</b>"),
    P("Three EventArgs info classes must be defined, one for each of the events Take Off, Change Route and Land. Each class derives from EventArgs and each is saved in its own separate file."),
    P("Delegates and notifier handler methods of the OnXxx kind must be defined in the publisher class."),
    P("It must be possible to start several instances of the publisher class, and any flight must be able to start, change route and land independent of other flights."),
    P("At least three images representing airlines must be found or made, and the image related to a flight must be displayed on the flight window."),
    P("The flight number typed by the user must be validated. <b>An empty flight number string must be rejected.</b>"),
    P("On the flight window, only the Start button is enabled at first. Once Start has been pushed, Start is disabled and the Change Route control and the Land button are enabled. When the airplane has landed, a notification is published and the flight window is terminated."),
    P("The assignment leaves one design question open on purpose: which object is the publisher and which is the subscriber. The football analogy in the assignment text gives the answer. <b>The moving object publishes, just as the kicked ball publishes the signal of being kicked.</b> The airplane is therefore the publisher and the control tower is a subscriber."),
    P("<b>VG part for grade B:</b> the message board of the control tower must be a WPF ListView."),
    P("<b>VG part for grade A:</b> a second type of subscriber object must also be notified of some of the plane events, and both the control tower and this new object must react. The assignment suggests an object that logs the starting and landing times of all flights."),
]

H_HOW = P("How the code answers, step by step")

HOW_SECTIONS = [
    (P("Step 1 — The EventArgs classes carry the news"),
     [P("The folder Events holds four small classes. The class FlightEventArgs is a shared base class deriving from EventArgs. It carries the two facts every subscriber needs with every event: the flight number as a string and the time stamp as a DateTime."),
      P("The three classes demanded by the assignment derive from the base class, and each one lives in its own separate file. <b>TakeOffEventArgs sits in TakeOffEventArgs.cs, ChangeRouteEventArgs sits in ChangeRouteEventArgs.cs, and LandEventArgs sits in LandEventArgs.cs.</b>"),
      P("ChangeRouteEventArgs adds one extra property named NewRoute, because a route change notification must say which route the airplane changed to. The other two classes need nothing beyond the shared flight number and time stamp."),
      P("<b>The flight number travels inside the EventArgs object.</b> This is what allows the control tower to print the flight number of an airplane it has never stored anywhere.")]),
    (P("Step 2 — The Airplane is the publisher"),
     [P("The class Airplane in the folder Publisher is the publisher. It follows the four publisher steps documented in its own comments."),
      P("<b>Publisher step one: declare one delegate type per event.</b> Airplane declares TakeOffEventHandler, ChangeRouteEventHandler and LandEventHandler. A delegate type fixes the shape of every subscriber handler: an object parameter named sender and a parameter of the matching EventArgs class."),
      P("<b>Publisher step two: declare the events.</b> The events are named TakeOff, ChangeRoute and Land, and each event is built on its own delegate type. Subscribers attach with the plus-equals operator and detach with minus-equals."),
      P("<b>Publisher step three: write the notifier methods.</b> The protected virtual methods OnTakeOff, OnChangeRoute and OnLand raise the events. Each notifier first checks that the event is not null, so publishing stays safe even when nobody is listening."),
      P("<b>Publisher step four: call the notifiers when the state changes.</b> The public method StartFlight sets the taken-off state and calls OnTakeOff with a fresh TakeOffEventArgs. ChangeRouteTo stores the new route and calls OnChangeRoute with a ChangeRouteEventArgs carrying the new route. LandFlight sets the landed state and calls OnLand."),
      P("The airplane holds its flight number, its current route and its taken-off and landed states. <b>It holds no reference to any subscriber.</b> It publishes to whoever happens to be attached, exactly like the kicked ball in the football analogy.")]),
    (P("Step 3 — The delegate flow of one notification"),
     [P("Take one click on the Start button of a flight window and follow the signal. <b>First</b>, the click handler calls StartFlight on the airplane of that flight. <b>Second</b>, StartFlight builds a TakeOffEventArgs holding the flight number and the current time. <b>Third</b>, StartFlight hands the object to the notifier OnTakeOff. <b>Fourth</b>, the notifier invokes the TakeOff event, and the delegate machinery calls every attached handler one by one with the airplane as sender and the EventArgs object as the news. <b>Fifth</b>, each subscriber handler reads the flight number and the time stamp from the EventArgs object and reacts in its own way."),
      P("<b>The delegate is the contract that makes the flow type safe.</b> A handler with the wrong shape cannot be attached, and the publisher never needs to know the class of any subscriber.")]),
    (P("Step 4 — FlightWindow, one window per flight"),
     [P("FlightWindow is created with a flight number. The title bar shows the flight number. The window builds its own Airplane and exposes the airplane through a public property named Airplane, so subscribers can attach to the events of this flight."),
      P("The airline logo is loaded into an Image control. The first two letters of the flight number select the image file from the Images folder: SK selects the Scandinavian logo, LH selects the Lufthansa logo and BA selects the British Airways logo. <b>When the prefix matches no known logo, the default image is loaded instead.</b>"),
      P("At first, the Start button is the only enabled control. The route ComboBox and the Land button start disabled. Clicking Start calls StartFlight, disables Start so a flight can start only once, and enables the ComboBox and the Land button. Choosing a route in the ComboBox calls ChangeRouteTo with the chosen route. Clicking Land calls LandFlight and then closes the window, because the flight is finished."),
      P("The flight window also subscribes to its own airplane. Its three handlers update a status label, so the window shows airborne, route changed and landed states as they happen.")]),
    (P("Step 5 — ControlTowerWindow, the subscriber and the main window"),
     [P("ControlTowerWindow is the main window of the application, and App.xaml names it as the startup window. It is a subscriber. The window holds a text box for the flight number and the button labelled Send next Airplane to Runway."),
      P("Clicking the button first validates the input. <b>An empty flight number string is rejected with a warning MessageBox, and no flight window is created.</b> A valid number creates a FlightWindow. The tower then attaches its own three handler methods to the TakeOff, ChangeRoute and Land events of the airplane of that flight, and shows the window non-modally."),
      P("<b>The tower keeps no collection of flights and stores no airplane reference.</b> The event subscriptions are the only connection. When a notification arrives, the handler reads the flight number, builds a status text and reads the time stamp, all from the EventArgs object, and adds one row to the message board."),
      P("Because the flight windows are shown non-modally and every flight owns its own Airplane, several flights can be open and flying at the same time, fully independent of each other.")]),
    (P("Step 6 — VG part for grade B: the ListView message board"),
     [P("<b>The message board is a WPF ListView with a GridView inside.</b> The GridView defines three columns headed Flight Number, Status and Time. Each notification adds one FlightMessage row object with the three values as properties, and the columns bind to those properties by name.")]),
    (P("Step 7 — VG part for grade A: FlightLogger, the second subscriber"),
     [P("The class FlightLogger in the folder Subscribers is the second subscriber. <b>It subscribes only to TakeOff and Land, and it ignores ChangeRoute on purpose, matching the logging example in the assignment text.</b>"),
      P("Its Subscribe method attaches its two handlers to one airplane. Each handler builds one log line holding the flight number, the event name and the time stamp. The line is stored in the in-memory list of the logger and appended to a file named flights.log, so the history survives after the program closes."),
      P("The control tower creates one single FlightLogger and subscribes it to every flight it launches. The logger raises its own small event named LineLogged for each new line, and the tower shows those lines in a separate list on the tower window. <b>Both subscribers therefore react visibly to the same published events, in two different ways.</b>")]),
    (P("Step 8 — The airline images"),
     [P("The folder Images holds four PNG logo images generated for this solution: SK.png, LH.png, BA.png and default.png. Each image is a coloured rectangle carrying the airline code and the word AIR in bold text. The project file copies the images to the output folder as content files, so the flight window finds them next to the executable at run time. The assignment allows images obtained otherwise than from the Internet, and generated images satisfy the demand of at least three airline images.")]),
    (P("Step 9 — Verification through the harness"),
     [P("A console harness project sits beside the WPF project. The harness does not copy any code. <b>Its project file links the real Airplane.cs, the four real EventArgs files and the real FlightLogger.cs straight from the WPF project, so the harness runs the actual project code.</b>"),
      P("The harness builds two airplanes with the flight numbers SK123 and LH456, attaches a console subscriber that mimics the tower message board, and attaches one shared FlightLogger to both flights. It then flies the two airplanes in interleaved order: both take off, both change route, and both land. The real output of that run is printed verbatim further down in this document and saved as output.txt beside the project."),
      P("<b>An honest note on running the windows.</b> The WPF project compiles on this Linux machine with zero errors, and the build is the compile proof. WPF needs Windows to display its windows, so the windows themselves were not displayed here. The event logic behind the windows was instead run for real through the harness, which exercises the same publisher, the same EventArgs classes and the same FlightLogger that the windows use.")]),
]

H_RUNWIN = P("How to run on Windows")
RUNWIN = [
    P("Open the folder ControlTower in Visual Studio on Windows and open ControlTower.csproj, then start the program with the Start button of Visual Studio."),
    P("The same result comes from a terminal: move into the ControlTower folder and run the command dotnet run. The control tower window opens first. Type a flight number such as SK123 and press Send next Airplane to Runway."),
    P("The harness runs on any platform with the .NET 8 SDK: move into the Harness folder and run the command dotnet run."),
]

H_CODE = P("The full source code")
CODE_INTRO = P("Every source file of the project follows verbatim under its file name. The harness program is included at the end and labelled as harness code.")
H_OUTPUT = P("The real run output")
OUTPUT_INTRO = P("The text below is the verbatim output of the harness run, also saved as output.txt in the Assignment5 folder. The FlightLogger also wrote its four lines to flights.log during the same run.")

H_GLOSSARY = P("Glossary")
GLOSSARY = [
    (P("Publisher"), P("An object that declares events and publishes notifications when something happens. The Airplane is the publisher of this assignment.")),
    (P("Subscriber"), P("An object that attaches handler methods to the events of a publisher and reacts when a notification arrives. The control tower and the FlightLogger are subscribers.")),
    (P("Delegate"), P("A type that fixes the shape of a method: its return type and its parameters. Event delegate types fix the shape every subscriber handler must have.")),
    (P("Event"), P("A member of a publisher built on a delegate type. Subscribers attach handlers to an event, and the publisher raises the event to reach all attached handlers at once.")),
    (P("EventArgs"), P("The base class of the information objects that travel with an event. The derived classes of this assignment add the flight number, the time stamp and, for a route change, the new route.")),
    (P("Notifier"), P("A protected virtual method of the publisher with a name of the form OnXxx. The notifier checks for attached subscribers and then raises its event.")),
    (P("Handler"), P("A method in a subscriber whose shape matches the delegate type of an event. The handler runs when the publisher raises the event.")),
    (P("Non-modal window"), P("A window shown in a way that leaves the other windows of the program usable at the same time. Flight windows are shown non-modally so several flights can be open at once.")),
    (P("ListView"), P("A WPF control that shows rows of data. With a GridView inside, the rows gain named columns, which is how the message board shows Flight Number, Status and Time.")),
    (P("Harness"), P("A small console program built only to run and prove the event logic of the real project files on a machine where the WPF windows cannot be displayed.")),
]

for s in PROSE:
    assert "(" not in s and ")" not in s, "Parenthesis found in prose: " + s
for term, definition in GLOSSARY:
    assert "(" not in term and ")" not in definition

# ----------------------------------------------------------------------
# Styles
# ----------------------------------------------------------------------
styles = {
    "title": ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=22,
                            leading=27, spaceAfter=6),
    "subtitle": ParagraphStyle("subtitle", fontName="Helvetica", fontSize=12,
                               leading=16, spaceAfter=2),
    "h1": ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=16,
                         leading=20, spaceBefore=14, spaceAfter=6,
                         textColor=colors.HexColor("#0B3D66")),
    "h2": ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=13,
                         leading=17, spaceBefore=10, spaceAfter=4,
                         textColor=colors.HexColor("#0B3D66")),
    "body": ParagraphStyle("body", fontName="Helvetica", fontSize=11,
                           leading=15, spaceAfter=5, alignment=TA_LEFT),
    "bullet": ParagraphStyle("bullet", fontName="Helvetica", fontSize=11,
                             leading=15, spaceAfter=4, leftIndent=14,
                             bulletIndent=4),
    "file": ParagraphStyle("file", fontName="Helvetica-Bold", fontSize=11.5,
                           leading=15, spaceBefore=10, spaceAfter=3,
                           textColor=colors.HexColor("#7A1F1F")),
    "code": ParagraphStyle("code", fontName="Courier", fontSize=7.6,
                           leading=9.6, leftIndent=4),
    "gloss": ParagraphStyle("gloss", fontName="Helvetica", fontSize=11,
                            leading=15, spaceAfter=5),
}

def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.drawString(2 * cm, 1.2 * cm, "Assignment 5 — The Control Tower — Abel Haile Magicho")
    canvas.drawRightString(A4[0] - 2 * cm, 1.2 * cm, "Page %d" % doc.page)
    canvas.restoreState()

story = []
story.append(Paragraph(TITLE, styles["title"]))
story.append(Paragraph(SUBTITLE, styles["subtitle"]))
story.append(Paragraph(AUTHOR, styles["subtitle"]))
story.append(Paragraph(TOPIC, styles["subtitle"]))
story.append(Spacer(1, 10))

story.append(Paragraph(H_WHAT, styles["h1"]))
story.append(Paragraph(WHAT_INTRO, styles["body"]))
for point in WHAT_POINTS:
    story.append(Paragraph(point, styles["bullet"], bulletText="•"))

story.append(Paragraph(H_HOW, styles["h1"]))
for heading, paragraphs in HOW_SECTIONS:
    story.append(Paragraph(heading, styles["h2"]))
    for para in paragraphs:
        story.append(Paragraph(para, styles["body"]))

story.append(Paragraph(H_RUNWIN, styles["h1"]))
for para in RUNWIN:
    story.append(Paragraph(para, styles["body"]))

story.append(PageBreak())
story.append(Paragraph(H_CODE, styles["h1"]))
story.append(Paragraph(CODE_INTRO, styles["body"]))

FILES = [
    ("ControlTower.csproj", os.path.join(PROJ, "ControlTower.csproj")),
    ("App.xaml", os.path.join(PROJ, "App.xaml")),
    ("App.xaml.cs", os.path.join(PROJ, "App.xaml.cs")),
    ("Events/FlightEventArgs.cs", os.path.join(PROJ, "Events", "FlightEventArgs.cs")),
    ("Events/TakeOffEventArgs.cs", os.path.join(PROJ, "Events", "TakeOffEventArgs.cs")),
    ("Events/ChangeRouteEventArgs.cs", os.path.join(PROJ, "Events", "ChangeRouteEventArgs.cs")),
    ("Events/LandEventArgs.cs", os.path.join(PROJ, "Events", "LandEventArgs.cs")),
    ("Publisher/Airplane.cs", os.path.join(PROJ, "Publisher", "Airplane.cs")),
    ("Subscribers/FlightLogger.cs", os.path.join(PROJ, "Subscribers", "FlightLogger.cs")),
    ("FlightWindow.xaml", os.path.join(PROJ, "FlightWindow.xaml")),
    ("FlightWindow.xaml.cs", os.path.join(PROJ, "FlightWindow.xaml.cs")),
    ("ControlTowerWindow.xaml", os.path.join(PROJ, "ControlTowerWindow.xaml")),
    ("ControlTowerWindow.xaml.cs", os.path.join(PROJ, "ControlTowerWindow.xaml.cs")),
    ("Harness/Harness.csproj — harness project file", os.path.join(HARNESS, "Harness.csproj")),
    ("Harness/Program.cs — harness code", os.path.join(HARNESS, "Program.cs")),
]
for label, path in FILES:
    with open(path, "r", encoding="utf-8") as fh:
        code = fh.read()
    story.append(Paragraph(label, styles["file"]))
    story.append(Preformatted(code.rstrip("\n"), styles["code"]))

story.append(PageBreak())
story.append(Paragraph(H_OUTPUT, styles["h1"]))
story.append(Paragraph(OUTPUT_INTRO, styles["body"]))
with open(os.path.join(BASE, "output.txt"), "r", encoding="utf-8") as fh:
    output_text = fh.read()
story.append(Preformatted(output_text.rstrip("\n"), styles["code"]))

story.append(Paragraph(H_GLOSSARY, styles["h1"]))
for term, definition in GLOSSARY:
    story.append(Paragraph("<b>" + term + "</b> — " + definition, styles["gloss"]))

doc = SimpleDocTemplate(OUT, pagesize=A4,
                        leftMargin=2 * cm, rightMargin=2 * cm,
                        topMargin=2 * cm, bottomMargin=2 * cm,
                        title="Assignment 5 - The Control Tower",
                        author="Abel Haile Magicho")
doc.build(story, onFirstPage=footer, onLaterPages=footer)

from pypdf import PdfReader
pages = len(PdfReader(OUT).pages)
print("PDF built:", OUT)
print("Pages:", pages)
print("Prose strings checked for parentheses:", len(PROSE))

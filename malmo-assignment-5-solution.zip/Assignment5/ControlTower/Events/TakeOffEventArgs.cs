using System;

namespace ControlTower.Events
{
    /// <summary>
    /// Information carried with the TakeOff event.
    /// Saved in its own file, as required by the assignment.
    /// </summary>
    public class TakeOffEventArgs : FlightEventArgs
    {
        public TakeOffEventArgs(string flightNumber, DateTime timeStamp)
            : base(flightNumber, timeStamp)
        {
        }
    }
}

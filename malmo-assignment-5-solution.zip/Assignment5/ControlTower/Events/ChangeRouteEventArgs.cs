using System;

namespace ControlTower.Events
{
    /// <summary>
    /// Information carried with the ChangeRoute event.
    /// Saved in its own file, as required by the assignment.
    /// In addition to the shared flight number and time stamp, this class
    /// carries the new route the airplane has changed to.
    /// </summary>
    public class ChangeRouteEventArgs : FlightEventArgs
    {
        public string NewRoute { get; private set; }

        public ChangeRouteEventArgs(string flightNumber, DateTime timeStamp, string newRoute)
            : base(flightNumber, timeStamp)
        {
            NewRoute = newRoute;
        }
    }
}

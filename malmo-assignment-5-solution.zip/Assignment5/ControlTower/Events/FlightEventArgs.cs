using System;

namespace ControlTower.Events
{
    /// <summary>
    /// Shared base class for all flight event information.
    /// The publisher fills in the flight number and the time stamp so that
    /// every subscriber learns which flight the event belongs to, even
    /// though the subscriber holds no reference to the airplane itself.
    /// </summary>
    public class FlightEventArgs : EventArgs
    {
        public string FlightNumber { get; private set; }
        public DateTime TimeStamp { get; private set; }

        public FlightEventArgs(string flightNumber, DateTime timeStamp)
        {
            FlightNumber = flightNumber;
            TimeStamp = timeStamp;
        }
    }
}

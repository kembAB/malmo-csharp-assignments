using System;

namespace ControlTower.Events
{
    /// <summary>
    /// Information carried with the Land event.
    /// Saved in its own file, as required by the assignment.
    /// </summary>
    public class LandEventArgs : FlightEventArgs
    {
        public LandEventArgs(string flightNumber, DateTime timeStamp)
            : base(flightNumber, timeStamp)
        {
        }
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using ControlTower.Events;
using ControlTower.Publisher;

namespace ControlTower.Subscribers
{
    /// <summary>
    /// VG part for grade A: a second subscriber.
    ///
    /// FlightLogger is a subscriber of the Airplane publisher, just like
    /// the control tower. It subscribes only to the TakeOff and the Land
    /// events, not to ChangeRoute. Every notification is recorded as one
    /// log line holding the flight number, the event name and the time
    /// stamp. The lines are kept in an in-memory list and are also
    /// appended to a log file named flights.log, so the history of all
    /// starts and landings survives after the program closes.
    ///
    /// The class also raises its own LineLogged event whenever a new
    /// line is recorded, which lets the control tower window show the
    /// logger lines live on screen.
    /// </summary>
    public class FlightLogger
    {
        private readonly List<string> logLines = new List<string>();
        private readonly string logFilePath;

        /// <summary>
        /// Raised each time a new log line has been recorded.
        /// The string argument is the finished log line.
        /// </summary>
        public event Action<string> LineLogged;

        public FlightLogger()
        {
            logFilePath = Path.Combine(AppContext.BaseDirectory, "flights.log");
        }

        /// <summary>
        /// All log lines recorded so far, oldest first.
        /// </summary>
        public List<string> LogLines
        {
            get { return logLines; }
        }

        /// <summary>
        /// Full path of the log file this logger appends to.
        /// </summary>
        public string LogFilePath
        {
            get { return logFilePath; }
        }

        /// <summary>
        /// Subscriber step: attach the logger handler methods to the
        /// TakeOff and Land events of one airplane. The control tower
        /// calls this once for every flight it sends to the runway.
        /// </summary>
        public void Subscribe(Airplane airplane)
        {
            airplane.TakeOff += OnTakeOff;
            airplane.Land += OnLand;
        }

        // Handler for the TakeOff event.
        private void OnTakeOff(object sender, TakeOffEventArgs e)
        {
            Record(e.FlightNumber, "TakeOff", e.TimeStamp);
        }

        // Handler for the Land event.
        private void OnLand(object sender, LandEventArgs e)
        {
            Record(e.FlightNumber, "Land", e.TimeStamp);
        }

        // Builds one log line, stores it in the list, appends it to the
        // flights.log file and notifies any listener through LineLogged.
        private void Record(string flightNumber, string eventName, DateTime timeStamp)
        {
            string line = flightNumber + " | " + eventName + " | " +
                          timeStamp.ToString("yyyy-MM-dd HH:mm:ss");
            logLines.Add(line);
            File.AppendAllText(logFilePath, line + Environment.NewLine);

            if (LineLogged != null)
                LineLogged(line);
        }
    }
}

using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using ControlTower.Events;
using ControlTower.Publisher;

namespace ControlTower
{
    /// <summary>
    /// One window per flight. The window owns its own Airplane publisher
    /// and exposes it through the Airplane property, so subscribers such
    /// as the control tower and the flight logger can attach their
    /// handlers to the events of this flight.
    ///
    /// The window is also a subscriber of its own airplane: it listens to
    /// all three events in order to keep its status label up to date.
    /// Every flight window is fully independent of the others, so several
    /// flights can be in the air at the same time.
    /// </summary>
    public partial class FlightWindow : Window
    {
        /// <summary>
        /// The airplane publisher belonging to this flight.
        /// </summary>
        public Airplane Airplane { get; private set; }

        public FlightWindow(string flightNumber)
        {
            InitializeComponent();

            Airplane = new Airplane(flightNumber);

            // The title bar shows the flight number.
            Title = "Flight " + flightNumber;

            // The window subscribes to its own airplane to update the
            // status label whenever something happens to the flight.
            Airplane.TakeOff += OnOwnTakeOff;
            Airplane.ChangeRoute += OnOwnChangeRoute;
            Airplane.Land += OnOwnLand;

            LoadAirlineLogo(flightNumber);
        }

        // Picks the logo from the first two letters of the flight number,
        // for example SK for SK123. When no logo matches the prefix, the
        // default image is shown instead, as the assignment requires.
        private void LoadAirlineLogo(string flightNumber)
        {
            string prefix = flightNumber.Length >= 2
                ? flightNumber.Substring(0, 2).ToUpper()
                : string.Empty;

            string imagesFolder = Path.Combine(AppContext.BaseDirectory, "Images");
            string logoPath = Path.Combine(imagesFolder, prefix + ".png");

            if (!File.Exists(logoPath))
                logoPath = Path.Combine(imagesFolder, "default.png");

            if (File.Exists(logoPath))
            {
                BitmapImage logo = new BitmapImage();
                logo.BeginInit();
                logo.UriSource = new Uri(logoPath, UriKind.Absolute);
                logo.EndInit();
                AirlineLogoImage.Source = logo;
            }
        }

        // Start is the only control enabled when the window opens.
        // Clicking it starts the flight, disables Start so a flight can
        // start only once, and enables the route picker and Land.
        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            Airplane.StartFlight();
            StartButton.IsEnabled = false;
            RouteComboBox.IsEnabled = true;
            LandButton.IsEnabled = true;
        }

        // Choosing a route publishes a ChangeRoute event.
        private void RouteComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem selected = RouteComboBox.SelectedItem as ComboBoxItem;
            if (selected != null)
                Airplane.ChangeRouteTo(selected.Content.ToString());
        }

        // Landing publishes the Land event and then closes the window,
        // because the flight is finished.
        private void LandButton_Click(object sender, RoutedEventArgs e)
        {
            Airplane.LandFlight();
            Close();
        }

        // Own subscriptions: keep the status label in step with the flight.
        private void OnOwnTakeOff(object sender, TakeOffEventArgs e)
        {
            StatusLabel.Content = "Airborne since " + e.TimeStamp.ToString("HH:mm:ss");
        }

        private void OnOwnChangeRoute(object sender, ChangeRouteEventArgs e)
        {
            StatusLabel.Content = "Route changed to " + e.NewRoute;
        }

        private void OnOwnLand(object sender, LandEventArgs e)
        {
            StatusLabel.Content = "Landed at " + e.TimeStamp.ToString("HH:mm:ss");
        }
    }
}

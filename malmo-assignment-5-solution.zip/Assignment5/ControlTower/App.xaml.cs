using System.Windows;

namespace ControlTower
{
    /// <summary>
    /// Application entry point. App.xaml sets ControlTowerWindow as the
    /// startup window, so the control tower is what the user sees first.
    /// </summary>
    public partial class App : Application
    {
    }
}

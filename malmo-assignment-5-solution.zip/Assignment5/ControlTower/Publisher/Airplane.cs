using System;
using ControlTower.Events;

namespace ControlTower.Publisher
{
    /// <summary>
    /// The Airplane is the PUBLISHER in the publisher/subscriber pattern.
    ///
    /// Think of the ball in a football game: when the ball is kicked, the
    /// ball itself gives out the signal without knowing which players,
    /// referees or goalkeepers are waiting for it. In the same way, the
    /// airplane publishes a signal when it takes off, changes route or
    /// lands, without knowing which objects receive the notification.
    ///
    /// Publisher steps carried out by this class:
    ///   Step 1 - Declare one delegate type for each event.
    ///   Step 2 - Declare the events, built on those delegate types.
    ///   Step 3 - Write one protected virtual notifier method per event,
    ///            named OnXxx, which raises the event in a null-safe way.
    ///   Step 4 - Call the notifier from the public action methods when
    ///            the state of the airplane changes.
    /// Subscribers then only have to attach their own handler methods to
    /// the events with the += operator.
    /// </summary>
    public class Airplane
    {
        // ---------------------------------------------------------------
        // Step 1: Delegate types, one per event.
        // A delegate type fixes the signature every subscriber handler
        // must have: an object sender and the matching EventArgs class.
        // ---------------------------------------------------------------
        public delegate void TakeOffEventHandler(object sender, TakeOffEventArgs e);
        public delegate void ChangeRouteEventHandler(object sender, ChangeRouteEventArgs e);
        public delegate void LandEventHandler(object sender, LandEventArgs e);

        // ---------------------------------------------------------------
        // Step 2: The events themselves.
        // Subscribers attach and detach handlers with += and -=.
        // ---------------------------------------------------------------
        public event TakeOffEventHandler TakeOff;
        public event ChangeRouteEventHandler ChangeRoute;
        public event LandEventHandler Land;

        // Internal state of this flight.
        public string FlightNumber { get; private set; }
        public string CurrentRoute { get; private set; }
        public bool HasTakenOff { get; private set; }
        public bool HasLanded { get; private set; }

        public Airplane(string flightNumber)
        {
            FlightNumber = flightNumber;
            CurrentRoute = "Not assigned yet";
            HasTakenOff = false;
            HasLanded = false;
        }

        // ---------------------------------------------------------------
        // Step 4a: Start the flight and notify all subscribers.
        // ---------------------------------------------------------------
        public void StartFlight()
        {
            HasTakenOff = true;
            OnTakeOff(new TakeOffEventArgs(FlightNumber, DateTime.Now));
        }

        // ---------------------------------------------------------------
        // Step 4b: Change route and notify all subscribers.
        // ---------------------------------------------------------------
        public void ChangeRouteTo(string newRoute)
        {
            CurrentRoute = newRoute;
            OnChangeRoute(new ChangeRouteEventArgs(FlightNumber, DateTime.Now, newRoute));
        }

        // ---------------------------------------------------------------
        // Step 4c: Land the flight and notify all subscribers.
        // ---------------------------------------------------------------
        public void LandFlight()
        {
            HasLanded = true;
            OnLand(new LandEventArgs(FlightNumber, DateTime.Now));
        }

        // ---------------------------------------------------------------
        // Step 3: Notifier methods.
        // Each notifier checks that at least one subscriber is attached
        // before raising the event, so publishing is always null-safe.
        // The methods are protected and virtual so a derived airplane
        // class could extend the notification behaviour.
        // ---------------------------------------------------------------
        protected virtual void OnTakeOff(TakeOffEventArgs e)
        {
            if (TakeOff != null)
                TakeOff(this, e);
        }

        protected virtual void OnChangeRoute(ChangeRouteEventArgs e)
        {
            if (ChangeRoute != null)
                ChangeRoute(this, e);
        }

        protected virtual void OnLand(LandEventArgs e)
        {
            if (Land != null)
                Land(this, e);
        }
    }
}

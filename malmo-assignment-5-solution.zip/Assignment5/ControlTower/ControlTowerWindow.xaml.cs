using System.Windows;
using ControlTower.Events;
using ControlTower.Subscribers;

namespace ControlTower
{
    /// <summary>
    /// One row on the message board: flight number, status text and time.
    /// </summary>
    public class FlightMessage
    {
        public string FlightNumber { get; set; }
        public string Status { get; set; }
        public string Time { get; set; }
    }

    /// <summary>
    /// The control tower window is a SUBSCRIBER of the Airplane publisher.
    ///
    /// Subscriber steps carried out by this class:
    ///   Step 1 - Write handler methods whose signatures match the
    ///            delegate types declared by the publisher.
    ///   Step 2 - Attach the handlers to the events of each new airplane
    ///            with the += operator when the flight is launched.
    ///   Step 3 - React inside the handlers when a notification arrives.
    ///
    /// The tower keeps no collection of flights and holds no reference to
    /// any airplane beyond these event subscriptions, exactly as the
    /// assignment requires. All flight information arrives inside the
    /// EventArgs objects, because the tower has no other knowledge of
    /// the airplane that fired the event.
    /// </summary>
    public partial class ControlTowerWindow : Window
    {
        // VG part for grade A: one shared flight logger. The tower
        // subscribes this single logger to every flight it launches, so
        // both the tower and the logger react to the same events.
        private readonly FlightLogger flightLogger;

        public ControlTowerWindow()
        {
            InitializeComponent();

            flightLogger = new FlightLogger();
            flightLogger.LineLogged += OnLoggerLineLogged;
        }

        // Validates the flight number, creates the flight window,
        // subscribes the tower handlers and the flight logger to the new
        // airplane, and shows the flight window non-modally so several
        // flights can be open at the same time.
        private void SendToRunwayButton_Click(object sender, RoutedEventArgs e)
        {
            string flightNumber = FlightNumberTextBox.Text.Trim();

            // Validation required by the assignment: the flight number
            // must not be an empty string.
            if (flightNumber.Length == 0)
            {
                MessageBox.Show("Please enter a flight number before sending an airplane to the runway.",
                                "Missing flight number",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
                return;
            }

            FlightWindow flightWindow = new FlightWindow(flightNumber);

            // Subscriber step 2: attach the tower handlers to the events
            // of this flight. These subscriptions are the only connection
            // the tower keeps to the flight.
            flightWindow.Airplane.TakeOff += OnAirplaneTakeOff;
            flightWindow.Airplane.ChangeRoute += OnAirplaneChangeRoute;
            flightWindow.Airplane.Land += OnAirplaneLand;

            // VG part for grade A: attach the second subscriber as well.
            flightLogger.Subscribe(flightWindow.Airplane);

            // Show non-modally: the tower stays usable and more flights
            // can be sent to the runway while this one is open.
            flightWindow.Show();

            FlightNumberTextBox.Clear();
            FlightNumberTextBox.Focus();
        }

        // Subscriber step 3: the handler methods. Each one writes the
        // flight number, a status text and the time stamp from the
        // EventArgs object to the message board.
        private void OnAirplaneTakeOff(object sender, TakeOffEventArgs e)
        {
            AddMessage(e.FlightNumber, "Took off", e);
        }

        private void OnAirplaneChangeRoute(object sender, ChangeRouteEventArgs e)
        {
            AddMessage(e.FlightNumber, "Changed route to " + e.NewRoute, e);
        }

        private void OnAirplaneLand(object sender, LandEventArgs e)
        {
            AddMessage(e.FlightNumber, "Landed", e);
        }

        private void AddMessage(string flightNumber, string status, FlightEventArgs e)
        {
            FlightMessage message = new FlightMessage();
            message.FlightNumber = flightNumber;
            message.Status = status;
            message.Time = e.TimeStamp.ToString("yyyy-MM-dd HH:mm:ss");
            MessageBoardListView.Items.Add(message);
        }

        // Shows each new flight logger line in the logger list on the
        // tower window, so the second subscriber is visibly reacting to
        // the same take-off and landing events.
        private void OnLoggerLineLogged(string line)
        {
            LoggerListBox.Items.Add(line);
        }
    }
}

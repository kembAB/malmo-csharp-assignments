#!/usr/bin/env python3
"""Builds the explainer PDF for Assignment 6 - Invoice Maker.

Hard rule for this document: no parentheses anywhere in the prose.
All prose lives in string variables and is asserted clean before the
PDF is built. Verbatim code, XAML, file content and program output are
exempt from the rule and are read from disk unchanged.
"""

import os
from xml.sax.saxutils import escape

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                Preformatted, Table, TableStyle, PageBreak)

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "malmo-csharp-assignment-6-explainer.pdf")

# ----------------------------------------------------------------------
# Prose. Every string below is checked for parentheses before building.
# ----------------------------------------------------------------------

TITLE = "Assignment 6 — Invoice Maker"
SUBTITLE = "Programming in C# II — Malmö University"
AUTHOR = "Abel Haile Magicho"

H_WHAT = "What the assignment asks"
P_WHAT_1 = ("The assignment is the sixth assignment in the course Programming in C# II "
            "at Malmö University. The task is to design and build a WPF application that "
            "works as a standard invoice template. The student designs the layout freely "
            "and is expected to use solid object-oriented design with code comments and a "
            "well organised project.")
P_WHAT_2 = "<b>All invoice data is loaded by importing a plain text file with one value per line.</b>"
P_WHAT_3 = ("The window draws the complete invoice on screen: the receiver block, the invoice "
            "number and dates, the item lines and the sender block in the footer.")
P_WHAT_4 = ("<b>The application calculates and shows the tax included for each item and the "
            "total tax included.</b> It also calculates and shows the grand total amount to pay.")
P_WHAT_5 = ("<b>The user can enter a discount amount and the amount to pay updates at once.</b> "
            "The user decides which data can be changed after the import, but <b>the two dates "
            "must be editable</b>.")
P_WHAT_6 = ("<b>The user can load an image file as the company logo</b> shown at the top of "
            "the invoice. The demo data must be fictitious but realistic, with real-looking "
            "names and addresses instead of placeholder words.")
P_WHAT_7 = ("A pass grade needs a WPF application, the text file import exactly as specified, "
            "good object-oriented code, comments and project organisation.")
P_WHAT_8 = ("<b>VG part for a higher grade:</b> add a print feature so the application prints "
            "the invoice through the standard print dialog and the available printers. The "
            "assignment lists three printing methods and this solution uses the first one: "
            "<b>printing the invoice in a simple way using only text</b>. The assignment also "
            "allows animations or graphics in 2D or 3D instead of printing, but printing was "
            "chosen because an invoice program needs it in real life. The print code is marked "
            "clearly with a VG comment in MainWindow.xaml.cs.")

H_FORMAT = "The demo file format line by line"
P_FORMAT_1 = ("The file holds one value per line in a fixed order. The table below lists every "
              "line of InvoiceDemo1.txt with its meaning and its demo value.")
P_FORMAT_2 = ("<b>Only the number of items can change between files.</b> Every other value is "
              "always present, so the reader always knows exactly which line means what. Each "
              "extra item adds four lines and the sender block simply moves further down.")

FORMAT_LABELS = [
    "Invoice number",
    "Invoice date",
    "Due date",
    "Receiver company",
    "Receiver contact person",
    "Receiver street",
    "Receiver zip code",
    "Receiver city",
    "Receiver country",
    "Number of items",
    "Item 1 description",
    "Item 1 quantity",
    "Item 1 unit price",
    "Item 1 tax percent",
    "Item 2 description",
    "Item 2 quantity",
    "Item 2 unit price",
    "Item 2 tax percent",
    "Sender company",
    "Sender street",
    "Sender zip code",
    "Sender city",
    "Sender country",
    "Sender phone",
    "Sender home page URL",
]

H_HOW = "How the code answers step by step"
P_HOW_1 = ("<b>Step 1 — the model classes in the Models folder.</b> InvoiceItem holds one "
           "invoice line with a description, a quantity, a unit price and a tax rate in "
           "percent. InvoiceReceiver holds the customer company, the contact person and the "
           "address. InvoiceSender holds the sending company, its address, its phone number "
           "and its home page. Invoice holds the invoice number, the two dates as DateTime "
           "values, the receiver, the sender, a list of items and a discount.")
P_HOW_2 = ("<b>The tax rule stated plainly: the unit price already includes tax.</b> "
           "<b>The tax part of a line is therefore the line total times the tax percent "
           "divided by the sum 100 plus the tax percent.</b> A line total of 125.00 with a "
           "tax rate of 25 percent contains 25.00 of tax and 100.00 of net price. Dividing "
           "by 100 alone would be wrong because the price is tax-inclusive and not tax-free. "
           "The computed property TaxIncludedAmount on InvoiceItem carries this rule and "
           "LineTotal carries quantity times unit price.")
P_HOW_3 = ("Invoice computes TotalAmount as the sum of all line totals, TotalTaxIncluded as "
           "the sum of the tax included in every line and AmountToPay as the total minus the "
           "discount. <b>AmountToPay never falls below zero</b>, so a discount larger than "
           "the total simply gives zero to pay.")
P_HOW_4 = ("<b>Step 2 — the reader in the Services folder.</b> The static class "
           "InvoiceFileReader reads the whole file and walks through it line by line in the "
           "fixed order from the format table. Dates and numbers are parsed with the "
           "invariant culture, so the dot decimal separator in the file works on every "
           "computer. The item count line decides how many four-line item blocks are read, "
           "which is what makes the item count variable. <b>Every value is validated while "
           "reading.</b> A number or date that fails to parse, or a file that ends too "
           "early, throws a FormatException whose message names the faulty line.")
P_HOW_5 = ("<b>Step 3 — the window.</b> The Open Invoice File button shows an OpenFileDialog "
           "and hands the chosen path to the reader. The window then fills the receiver "
           "block, the invoice number, the items DataGrid and the sender footer. The "
           "DataGrid has columns for description, quantity, unit price, tax percent, line "
           "total and tax included, bound straight to the item objects. The totals area "
           "shows total tax included, grand total, an editable discount box and the amount "
           "to pay in bold. <b>Typing in the discount box recalculates the amount to pay "
           "at once.</b> The two dates sit in DatePicker controls and picking a new date "
           "writes it back into the invoice, as the assignment demands. The Load Logo button "
           "shows an OpenFileDialog filtered to image files and loads the chosen image into "
           "the Image control at the top. <b>Every import error is caught and shown in a "
           "MessageBox with the exception message</b>, so a broken file explains itself "
           "instead of crashing the program.")
P_HOW_6 = ("<b>Step 4 — the VG print feature.</b> The Print button first checks that an "
           "invoice is loaded. It then shows the standard PrintDialog. On confirmation it "
           "builds a FlowDocument holding the invoice as formatted text — receiver block, "
           "one aligned text line per item, the totals and the sender block — and prints "
           "that document. This is the simple text printing alternative the assignment lists "
           "for the higher grade.")

H_VERIFY = "Verification note"
P_VERIFY = ("<b>Honest verification note:</b> the WPF project compiles on this Linux machine "
            "with zero errors and zero warnings, but WPF needs Windows to display a window, "
            "so the running of the invoice logic was verified through a console harness "
            "instead. <b>The harness links the real model and reader source files from the "
            "WPF project</b>, so the exact code the window uses is the code that produced "
            "the output printed in this document. The harness run gave a grand total of "
            "3145.95 and a total tax included of 541.40 for the demo file, matching hand "
            "calculation, and a second test file with three items proved that the item "
            "count is variable.")

H_RUN = "How to run on Windows"
RUN_STEPS = [
    "Copy the Assignment6 folder to a Windows computer.",
    "Open InvoiceMaker.csproj from the InvoiceMaker folder in Visual Studio 2022 with the .NET desktop development workload installed.",
    "Press F5 to build and run the application.",
    "Click Open Invoice File and choose InvoiceDemo1.txt from the Assignment6 folder.",
    "Type a discount in the Discount box and watch Amount To Pay change.",
    "Click Load Logo and pick any image file to place it at the top of the invoice.",
    "Click Print, choose a printer in the print dialog and confirm to print the invoice.",
    "The project also builds from the command line with dotnet build when the .NET 8 SDK is installed.",
]

H_DEMO = "Demo file content — InvoiceDemo1.txt verbatim"
H_OUTPUT = "Real program output verbatim"
H_CODE = "Full source code verbatim"
CODE_INTRO = ("Every source file of the project follows under its own file name, exactly as "
              "written. The harness Program.cs is included last and labelled as test code.")

GLOSSARY_TITLE = "Glossary"
GLOSSARY = [
    ["WPF", "Windows Presentation Foundation. The Microsoft framework for building Windows desktop windows with XAML and C#."],
    ["XAML", "The XML-based markup language used to lay out the window, its grid rows, buttons, text blocks and data grid."],
    ["DataGrid", "The table control that shows one row per invoice item and one column per value."],
    ["DatePicker", "The calendar control that shows a date and lets the user pick a new one."],
    ["OpenFileDialog", "The standard Windows dialog that lets the user pick a file to open."],
    ["PrintDialog", "The standard Windows dialog that lets the user pick a printer and start printing."],
    ["FlowDocument", "A document made of flowing text blocks that WPF can paginate and send to a printer."],
    ["Invariant culture", "A fixed parsing setting where a dot always means a decimal separator and dates follow one fixed pattern on every computer."],
    ["FormatException", "The error type thrown when text cannot be parsed into the expected number or date. The reader throws it with a message that names the faulty line."],
    ["Tax-inclusive price", "A price that already contains its tax. The tax part is the price times the tax percent divided by the sum 100 plus the tax percent."],
    ["Discount", "An amount subtracted from the grand total before payment. The amount to pay never falls below zero."],
    ["Harness", "A small console program used only for testing. It runs the real invoice code without showing a window."],
    ["Logo", "An image file the user loads into the top of the invoice window."],
]

PROSE_STRINGS = [
    TITLE, SUBTITLE, AUTHOR, H_WHAT, P_WHAT_1, P_WHAT_2, P_WHAT_3, P_WHAT_4, P_WHAT_5,
    P_WHAT_6, P_WHAT_7, P_WHAT_8, H_FORMAT, P_FORMAT_1, P_FORMAT_2, H_HOW, P_HOW_1,
    P_HOW_2, P_HOW_3, P_HOW_4, P_HOW_5, P_HOW_6, H_VERIFY, P_VERIFY, H_RUN, H_DEMO,
    H_OUTPUT, H_CODE, CODE_INTRO, GLOSSARY_TITLE,
] + FORMAT_LABELS + RUN_STEPS + [row[0] for row in GLOSSARY] + [row[1] for row in GLOSSARY]

for text in PROSE_STRINGS:
    assert "(" not in text and ")" not in text, "Parenthesis found in prose: " + text

# ----------------------------------------------------------------------
# Styles
# ----------------------------------------------------------------------

styles = {
    "title": ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=22, leading=27,
                            spaceAfter=4),
    "subtitle": ParagraphStyle("subtitle", fontName="Helvetica", fontSize=12, leading=16,
                               spaceAfter=2),
    "author": ParagraphStyle("author", fontName="Helvetica-Bold", fontSize=12, leading=16,
                             spaceAfter=14),
    "h1": ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=15, leading=19,
                         spaceBefore=14, spaceAfter=6),
    "h2": ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=11.5, leading=15,
                         spaceBefore=12, spaceAfter=4),
    "body": ParagraphStyle("body", fontName="Helvetica", fontSize=10.5, leading=15,
                           spaceAfter=6),
    "code": ParagraphStyle("code", fontName="Courier", fontSize=6.5, leading=8.4),
    "cell": ParagraphStyle("cell", fontName="Helvetica", fontSize=9.5, leading=13),
    "cellb": ParagraphStyle("cellb", fontName="Helvetica-Bold", fontSize=9.5, leading=13),
}


def code_block(path):
    with open(path, "r", encoding="utf-8") as handle:
        text = handle.read()
    return Preformatted(escape(text.rstrip("\n")), styles["code"])


def read_text(path):
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.drawString(15 * mm, 10 * mm, "Assignment 6 — Invoice Maker — Abel Haile Magicho")
    canvas.drawRightString(A4[0] - 15 * mm, 10 * mm, "Page %d" % doc.page)
    canvas.restoreState()


story = []
story.append(Paragraph(TITLE, styles["title"]))
story.append(Paragraph(SUBTITLE, styles["subtitle"]))
story.append(Paragraph(AUTHOR, styles["author"]))

story.append(Paragraph(H_WHAT, styles["h1"]))
for para in (P_WHAT_1, P_WHAT_2, P_WHAT_3, P_WHAT_4, P_WHAT_5, P_WHAT_6, P_WHAT_7, P_WHAT_8):
    story.append(Paragraph(para, styles["body"]))

story.append(Paragraph(H_FORMAT, styles["h1"]))
story.append(Paragraph(P_FORMAT_1, styles["body"]))
demo_lines = read_text(os.path.join(BASE, "InvoiceDemo1.txt")).splitlines()
assert len(demo_lines) == len(FORMAT_LABELS) == 25
table_data = [[Paragraph("Line", styles["cellb"]),
               Paragraph("Meaning", styles["cellb"]),
               Paragraph("Demo value", styles["cellb"])]]
for i, (label, value) in enumerate(zip(FORMAT_LABELS, demo_lines), start=1):
    table_data.append([Paragraph(str(i), styles["cell"]),
                       Paragraph(escape(label), styles["cell"]),
                       Paragraph(escape(value), styles["cell"])])
table = Table(table_data, colWidths=[32 * mm, 62 * mm, 76 * mm])
table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("TOPPADDING", (0, 0), (-1, -1), 2),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
]))
story.append(table)
story.append(Spacer(1, 4))
story.append(Paragraph(P_FORMAT_2, styles["body"]))

story.append(Paragraph(H_HOW, styles["h1"]))
for para in (P_HOW_1, P_HOW_2, P_HOW_3, P_HOW_4, P_HOW_5, P_HOW_6):
    story.append(Paragraph(para, styles["body"]))

story.append(Paragraph(H_VERIFY, styles["h1"]))
story.append(Paragraph(P_VERIFY, styles["body"]))

story.append(Paragraph(H_RUN, styles["h1"]))
for step_no, step in enumerate(RUN_STEPS, start=1):
    story.append(Paragraph("<b>Step %d.</b> %s" % (step_no, step), styles["body"]))

story.append(PageBreak())
story.append(Paragraph(H_DEMO, styles["h1"]))
story.append(code_block(os.path.join(BASE, "InvoiceDemo1.txt")))

story.append(Paragraph(H_OUTPUT, styles["h1"]))
story.append(code_block(os.path.join(BASE, "output.txt")))

story.append(PageBreak())
story.append(Paragraph(H_CODE, styles["h1"]))
story.append(Paragraph(CODE_INTRO, styles["body"]))

CODE_FILES = [
    ("InvoiceMaker / InvoiceMaker.csproj",
     os.path.join(BASE, "InvoiceMaker", "InvoiceMaker.csproj")),
    ("InvoiceMaker / App.xaml",
     os.path.join(BASE, "InvoiceMaker", "App.xaml")),
    ("InvoiceMaker / App.xaml.cs",
     os.path.join(BASE, "InvoiceMaker", "App.xaml.cs")),
    ("InvoiceMaker / MainWindow.xaml",
     os.path.join(BASE, "InvoiceMaker", "MainWindow.xaml")),
    ("InvoiceMaker / MainWindow.xaml.cs",
     os.path.join(BASE, "InvoiceMaker", "MainWindow.xaml.cs")),
    ("InvoiceMaker / Models / InvoiceItem.cs",
     os.path.join(BASE, "InvoiceMaker", "Models", "InvoiceItem.cs")),
    ("InvoiceMaker / Models / InvoiceReceiver.cs",
     os.path.join(BASE, "InvoiceMaker", "Models", "InvoiceReceiver.cs")),
    ("InvoiceMaker / Models / InvoiceSender.cs",
     os.path.join(BASE, "InvoiceMaker", "Models", "InvoiceSender.cs")),
    ("InvoiceMaker / Models / Invoice.cs",
     os.path.join(BASE, "InvoiceMaker", "Models", "Invoice.cs")),
    ("InvoiceMaker / Services / InvoiceFileReader.cs",
     os.path.join(BASE, "InvoiceMaker", "Services", "InvoiceFileReader.cs")),
    ("Harness / Harness.csproj — console test harness project",
     os.path.join(BASE, "Harness", "Harness.csproj")),
    ("Harness / Program.cs — console test harness, not part of the WPF application",
     os.path.join(BASE, "Harness", "Program.cs")),
]
for heading, path in CODE_FILES:
    assert "(" not in heading and ")" not in heading
    story.append(Paragraph(escape(heading), styles["h2"]))
    story.append(code_block(path))

story.append(PageBreak())
story.append(Paragraph(GLOSSARY_TITLE, styles["h1"]))
gloss_data = [[Paragraph("Term", styles["cellb"]), Paragraph("Meaning", styles["cellb"])]]
for term, meaning in GLOSSARY:
    gloss_data.append([Paragraph(escape(term), styles["cellb"]),
                       Paragraph(meaning, styles["cell"])])
gloss_table = Table(gloss_data, colWidths=[38 * mm, 132 * mm])
gloss_table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("TOPPADDING", (0, 0), (-1, -1), 3),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
]))
story.append(gloss_table)

doc = SimpleDocTemplate(OUT, pagesize=A4,
                        leftMargin=15 * mm, rightMargin=15 * mm,
                        topMargin=15 * mm, bottomMargin=16 * mm,
                        title="Assignment 6 - Invoice Maker",
                        author="Abel Haile Magicho")
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print("Built:", OUT)

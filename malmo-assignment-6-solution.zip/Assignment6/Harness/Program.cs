// Program.cs — console harness for Assignment 6.
// WPF needs Windows to display, so this harness runs the real model and
// reader code from the InvoiceMaker project against the demo files and
// prints every value the window would show.
//
// Usage: Harness <path to InvoiceDemo1.txt> <path to InvoiceDemo2.txt>

using System;
using System.Globalization;
using InvoiceMaker.Models;
using InvoiceMaker.Services;

namespace Harness
{
    internal static class Program
    {
        private static string Money(decimal value)
        {
            return value.ToString("F2", CultureInfo.InvariantCulture);
        }

        private static void Main(string[] args)
        {
            string demoPath = args.Length > 0 ? args[0] : "InvoiceDemo1.txt";
            string secondPath = args.Length > 1 ? args[1] : "InvoiceDemo2.txt";

            Console.WriteLine("=== Assignment 6 - Invoice Maker - Harness ===");
            Console.WriteLine("Reading file: " + demoPath);
            Console.WriteLine();

            Invoice invoice = InvoiceFileReader.ReadInvoice(demoPath);

            Console.WriteLine("Invoice Number: " + invoice.InvoiceNumber);
            Console.WriteLine("Invoice Date: " +
                invoice.InvoiceDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
            Console.WriteLine("Due Date: " +
                invoice.DueDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
            Console.WriteLine();

            Console.WriteLine("Receiver:");
            Console.WriteLine("  Company: " + invoice.Receiver.CompanyName);
            Console.WriteLine("  Person: " + invoice.Receiver.PersonName);
            Console.WriteLine("  Street: " + invoice.Receiver.Street);
            Console.WriteLine("  Zip Code: " + invoice.Receiver.ZipCode);
            Console.WriteLine("  City: " + invoice.Receiver.City);
            Console.WriteLine("  Country: " + invoice.Receiver.Country);
            Console.WriteLine();

            Console.WriteLine("Items (" + invoice.Items.Count + "):");
            int number = 1;
            foreach (InvoiceItem item in invoice.Items)
            {
                Console.WriteLine("  Item " + number + ": " + item.Description);
                Console.WriteLine("    Quantity: " + item.Quantity);
                Console.WriteLine("    Unit Price: " + Money(item.UnitPrice));
                Console.WriteLine("    Tax Percent: " + Money(item.TaxRatePercent));
                Console.WriteLine("    Line Total: " + Money(item.LineTotal));
                Console.WriteLine("    Tax Included: " + Money(item.TaxIncludedAmount));
                number++;
            }
            Console.WriteLine();

            Console.WriteLine("TotalAmount (Grand Total): " + Money(invoice.TotalAmount));
            Console.WriteLine("TotalTaxIncluded: " + Money(invoice.TotalTaxIncluded));

            invoice.Discount = 100m;
            Console.WriteLine("Discount set to: " + Money(invoice.Discount));
            Console.WriteLine("AmountToPay with discount 100: " + Money(invoice.AmountToPay));
            Console.WriteLine();

            Console.WriteLine("Sender:");
            Console.WriteLine("  Company: " + invoice.Sender.CompanyName);
            Console.WriteLine("  Street: " + invoice.Sender.Street);
            Console.WriteLine("  Zip Code: " + invoice.Sender.ZipCode);
            Console.WriteLine("  City: " + invoice.Sender.City);
            Console.WriteLine("  Country: " + invoice.Sender.Country);
            Console.WriteLine("  Phone: " + invoice.Sender.PhoneNumber);
            Console.WriteLine("  Home Page: " + invoice.Sender.HomePage);
            Console.WriteLine();

            Console.WriteLine("=== Second test file with three items ===");
            Console.WriteLine("Reading file: " + secondPath);
            Invoice second = InvoiceFileReader.ReadInvoice(secondPath);
            Console.WriteLine("Invoice Number: " + second.InvoiceNumber);
            Console.WriteLine("Item count: " + second.Items.Count);
            foreach (InvoiceItem item in second.Items)
            {
                Console.WriteLine("  " + item.Description +
                    " - Qty " + item.Quantity +
                    " x " + Money(item.UnitPrice) +
                    " = Line Total " + Money(item.LineTotal) +
                    ", Tax Included " + Money(item.TaxIncludedAmount));
            }
            Console.WriteLine("Second file Grand Total: " + Money(second.TotalAmount));
            Console.WriteLine("Second file Total Tax Included: " + Money(second.TotalTaxIncluded));
        }
    }
}

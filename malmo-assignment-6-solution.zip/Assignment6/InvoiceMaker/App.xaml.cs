// App.xaml.cs
// Application entry point. App.xaml starts MainWindow.

using System.Windows;

namespace InvoiceMaker
{
    /// <summary>
    /// Interaction logic for App.xaml.
    /// </summary>
    public partial class App : Application
    {
    }
}

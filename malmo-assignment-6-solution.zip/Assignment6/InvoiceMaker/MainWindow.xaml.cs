// MainWindow.xaml.cs
// Code behind the invoice window.
// VG part: the Print button prints the invoice through PrintDialog
// using a FlowDocument with the invoice written as formatted text.

using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using InvoiceMaker.Models;
using InvoiceMaker.Services;

namespace InvoiceMaker
{
    /// <summary>
    /// Main window: imports an invoice text file and draws the invoice.
    /// </summary>
    public partial class MainWindow : Window
    {
        private Invoice currentInvoice;

        public MainWindow()
        {
            InitializeComponent();
        }

        // ------------------------------------------------------------------
        // Open Invoice File: import the text file and fill the window.
        // ------------------------------------------------------------------
        private void OpenFileButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Open Invoice File";
            dialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    currentInvoice = InvoiceFileReader.ReadInvoice(dialog.FileName);
                    ShowInvoice();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Could not read the invoice file",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        // Fills every control in the window from the loaded invoice.
        private void ShowInvoice()
        {
            InvoiceNumberText.Text = currentInvoice.InvoiceNumber;
            InvoiceDatePicker.SelectedDate = currentInvoice.InvoiceDate;
            DueDatePicker.SelectedDate = currentInvoice.DueDate;

            ReceiverCompanyText.Text = currentInvoice.Receiver.CompanyName;
            ReceiverPersonText.Text = currentInvoice.Receiver.PersonName;
            ReceiverStreetText.Text = currentInvoice.Receiver.Street;
            ReceiverCityText.Text = currentInvoice.Receiver.ZipCode + " " +
                                     currentInvoice.Receiver.City;
            ReceiverCountryText.Text = currentInvoice.Receiver.Country;

            ItemsGrid.ItemsSource = null;
            ItemsGrid.ItemsSource = currentInvoice.Items;

            SenderCompanyText.Text = currentInvoice.Sender.CompanyName;
            SenderAddressText.Text = currentInvoice.Sender.Street + ", " +
                currentInvoice.Sender.ZipCode + " " + currentInvoice.Sender.City +
                ", " + currentInvoice.Sender.Country;
            SenderContactText.Text = "Phone: " + currentInvoice.Sender.PhoneNumber +
                "   " + currentInvoice.Sender.HomePage;

            DiscountTextBox.Text = "0";
            UpdateTotals();
        }

        // ------------------------------------------------------------------
        // Totals and discount.
        // ------------------------------------------------------------------
        private void DiscountTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateTotals();
        }

        // Recalculates the totals area from the current invoice and the
        // discount typed by the user.
        private void UpdateTotals()
        {
            if (currentInvoice == null)
            {
                return;
            }

            decimal discount;
            if (!decimal.TryParse(DiscountTextBox.Text, NumberStyles.Number,
                    CultureInfo.InvariantCulture, out discount))
            {
                // Also accept the decimal separator of the current culture.
                if (!decimal.TryParse(DiscountTextBox.Text, out discount))
                {
                    discount = 0m;
                }
            }

            currentInvoice.Discount = discount;

            TotalTaxText.Text = currentInvoice.TotalTaxIncluded.ToString("F2");
            GrandTotalText.Text = currentInvoice.TotalAmount.ToString("F2");
            AmountToPayText.Text = currentInvoice.AmountToPay.ToString("F2");
        }

        // ------------------------------------------------------------------
        // Editable dates: the DatePicker controls write back to the invoice.
        // ------------------------------------------------------------------
        private void InvoiceDatePicker_SelectedDateChanged(object sender,
            SelectionChangedEventArgs e)
        {
            if (currentInvoice != null && InvoiceDatePicker.SelectedDate.HasValue)
            {
                currentInvoice.InvoiceDate = InvoiceDatePicker.SelectedDate.Value;
            }
        }

        private void DueDatePicker_SelectedDateChanged(object sender,
            SelectionChangedEventArgs e)
        {
            if (currentInvoice != null && DueDatePicker.SelectedDate.HasValue)
            {
                currentInvoice.DueDate = DueDatePicker.SelectedDate.Value;
            }
        }

        // ------------------------------------------------------------------
        // Load Logo: the user picks an image file shown at the top.
        // ------------------------------------------------------------------
        private void LoadLogoButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Load Logo";
            dialog.Filter = "Image files (*.png;*.jpg;*.jpeg;*.bmp;*.gif)|" +
                            "*.png;*.jpg;*.jpeg;*.bmp;*.gif|All files (*.*)|*.*";

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    BitmapImage image = new BitmapImage();
                    image.BeginInit();
                    image.UriSource = new Uri(dialog.FileName);
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.EndInit();
                    LogoImage.Source = image;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Could not load the logo image",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        // ------------------------------------------------------------------
        // VG PART — Print.
        // Prints the invoice through the standard PrintDialog. The invoice
        // is built as a FlowDocument with formatted text: receiver block,
        // one text line per item, the totals and the sender block. This is
        // the simple text printing alternative listed in the assignment.
        // ------------------------------------------------------------------
        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentInvoice == null)
            {
                MessageBox.Show("Open an invoice file first.", "Print",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog() == true)
            {
                FlowDocument document = BuildPrintDocument();
                document.PageHeight = printDialog.PrintableAreaHeight;
                document.PageWidth = printDialog.PrintableAreaWidth;
                IDocumentPaginatorSource paginator = document;
                printDialog.PrintDocument(paginator.DocumentPaginator,
                    "Invoice " + currentInvoice.InvoiceNumber);
            }
        }

        // Builds the printable text version of the current invoice.
        private FlowDocument BuildPrintDocument()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("INVOICE");
            sb.AppendLine("Invoice Number: " + currentInvoice.InvoiceNumber);
            sb.AppendLine("Invoice Date: " +
                currentInvoice.InvoiceDate.ToString("yyyy-MM-dd"));
            sb.AppendLine("Due Date: " +
                currentInvoice.DueDate.ToString("yyyy-MM-dd"));
            sb.AppendLine();
            sb.AppendLine("Bill To:");
            sb.AppendLine(currentInvoice.Receiver.CompanyName);
            sb.AppendLine(currentInvoice.Receiver.PersonName);
            sb.AppendLine(currentInvoice.Receiver.Street);
            sb.AppendLine(currentInvoice.Receiver.ZipCode + " " +
                          currentInvoice.Receiver.City);
            sb.AppendLine(currentInvoice.Receiver.Country);
            sb.AppendLine();
            sb.AppendLine("Description                 Qty   Unit Price   Tax %   Line Total   Tax Included");
            foreach (InvoiceItem item in currentInvoice.Items)
            {
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                    "{0,-26} {1,5} {2,12:F2} {3,7:F2} {4,12:F2} {5,12:F2}",
                    item.Description, item.Quantity, item.UnitPrice,
                    item.TaxRatePercent, item.LineTotal, item.TaxIncludedAmount));
            }
            sb.AppendLine();
            sb.AppendLine("Total Tax Included: " +
                currentInvoice.TotalTaxIncluded.ToString("F2"));
            sb.AppendLine("Grand Total: " +
                currentInvoice.TotalAmount.ToString("F2"));
            sb.AppendLine("Discount: " +
                currentInvoice.Discount.ToString("F2"));
            sb.AppendLine("Amount To Pay: " +
                currentInvoice.AmountToPay.ToString("F2"));
            sb.AppendLine();
            sb.AppendLine(currentInvoice.Sender.CompanyName);
            sb.AppendLine(currentInvoice.Sender.Street + ", " +
                currentInvoice.Sender.ZipCode + " " + currentInvoice.Sender.City +
                ", " + currentInvoice.Sender.Country);
            sb.AppendLine("Phone: " + currentInvoice.Sender.PhoneNumber +
                "   " + currentInvoice.Sender.HomePage);

            FlowDocument document = new FlowDocument();
            Paragraph paragraph = new Paragraph(new Run(sb.ToString()));
            paragraph.FontFamily = new System.Windows.Media.FontFamily("Consolas");
            paragraph.FontSize = 12;
            document.Blocks.Add(paragraph);
            return document;
        }
    }
}

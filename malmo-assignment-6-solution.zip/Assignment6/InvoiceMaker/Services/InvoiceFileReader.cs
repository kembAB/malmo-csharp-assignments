// InvoiceFileReader.cs
// Reads an invoice from a plain text file with one value per line.
//
// File format, in this exact order:
//   invoice number
//   invoice date
//   due date
//   receiver company
//   receiver contact person
//   receiver street
//   receiver zip code
//   receiver city
//   receiver country
//   number of items
//   then, for each item: description, quantity, unit price, tax percent
//   then: sender company, sender street, sender zip code, sender city,
//         sender country, sender phone, sender home page URL
//
// All dates and numbers are parsed with the invariant culture so the dot
// decimal separator used in the file works on every computer.
// Every read step is validated: a bad number or a file that ends too
// early raises a FormatException that names the line, so the GUI can
// show the message directly to the user.

using System;
using System.Globalization;
using System.IO;
using InvoiceMaker.Models;

namespace InvoiceMaker.Services
{
    /// <summary>
    /// Static reader that builds an Invoice object from a text file.
    /// </summary>
    public static class InvoiceFileReader
    {
        /// <summary>
        /// Reads the file at the given path and returns the invoice it describes.
        /// Throws FormatException with a line description when the file is invalid.
        /// </summary>
        public static Invoice ReadInvoice(string filePath)
        {
            string[] lines = File.ReadAllLines(filePath);
            int index = 0;

            // Local helper: returns the next line or throws when the file ends early.
            string NextLine(string what)
            {
                if (index >= lines.Length)
                {
                    throw new FormatException(
                        "The file ended early. Expected " + what +
                        " on line " + (index + 1) + ".");
                }
                string value = lines[index];
                index++;
                return value.Trim();
            }

            // Local helper: parses an integer line with validation.
            int ParseInt(string text, string what)
            {
                int result;
                if (!int.TryParse(text, NumberStyles.Integer,
                        CultureInfo.InvariantCulture, out result))
                {
                    throw new FormatException(
                        "Invalid integer for " + what + " on line " + index +
                        ": '" + text + "'.");
                }
                return result;
            }

            // Local helper: parses a decimal line with validation.
            decimal ParseDecimal(string text, string what)
            {
                decimal result;
                if (!decimal.TryParse(text, NumberStyles.Number,
                        CultureInfo.InvariantCulture, out result))
                {
                    throw new FormatException(
                        "Invalid number for " + what + " on line " + index +
                        ": '" + text + "'.");
                }
                return result;
            }

            // Local helper: parses a date line with validation.
            DateTime ParseDate(string text, string what)
            {
                DateTime result;
                if (!DateTime.TryParse(text, CultureInfo.InvariantCulture,
                        DateTimeStyles.None, out result))
                {
                    throw new FormatException(
                        "Invalid date for " + what + " on line " + index +
                        ": '" + text + "'.");
                }
                return result;
            }

            Invoice invoice = new Invoice();

            // Header.
            invoice.InvoiceNumber = NextLine("invoice number");
            invoice.InvoiceDate = ParseDate(NextLine("invoice date"), "invoice date");
            invoice.DueDate = ParseDate(NextLine("due date"), "due date");

            // Receiver block.
            invoice.Receiver.CompanyName = NextLine("receiver company");
            invoice.Receiver.PersonName = NextLine("receiver contact person");
            invoice.Receiver.Street = NextLine("receiver street");
            invoice.Receiver.ZipCode = NextLine("receiver zip code");
            invoice.Receiver.City = NextLine("receiver city");
            invoice.Receiver.Country = NextLine("receiver country");

            // Items. The count line decides how many item blocks follow.
            int itemCount = ParseInt(NextLine("number of items"), "number of items");
            if (itemCount < 0)
            {
                throw new FormatException(
                    "Number of items on line " + index + " must not be negative.");
            }

            for (int i = 1; i <= itemCount; i++)
            {
                InvoiceItem item = new InvoiceItem();
                item.Description = NextLine("description for item " + i);
                item.Quantity = ParseInt(
                    NextLine("quantity for item " + i), "quantity for item " + i);
                item.UnitPrice = ParseDecimal(
                    NextLine("unit price for item " + i), "unit price for item " + i);
                item.TaxRatePercent = ParseDecimal(
                    NextLine("tax percent for item " + i), "tax percent for item " + i);
                invoice.Items.Add(item);
            }

            // Sender block, printed in the footer of the invoice.
            invoice.Sender.CompanyName = NextLine("sender company");
            invoice.Sender.Street = NextLine("sender street");
            invoice.Sender.ZipCode = NextLine("sender zip code");
            invoice.Sender.City = NextLine("sender city");
            invoice.Sender.Country = NextLine("sender country");
            invoice.Sender.PhoneNumber = NextLine("sender phone");
            invoice.Sender.HomePage = NextLine("sender home page URL");

            return invoice;
        }
    }
}

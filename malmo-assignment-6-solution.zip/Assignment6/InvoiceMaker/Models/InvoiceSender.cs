// InvoiceSender.cs
// The company that sends the invoice. Shown in the footer of the invoice.

namespace InvoiceMaker.Models
{
    /// <summary>
    /// Represents the company that issues the invoice.
    /// </summary>
    public class InvoiceSender
    {
        public string CompanyName { get; set; }
        public string Street { get; set; }
        public string ZipCode { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string PhoneNumber { get; set; }
        public string HomePage { get; set; }
    }
}

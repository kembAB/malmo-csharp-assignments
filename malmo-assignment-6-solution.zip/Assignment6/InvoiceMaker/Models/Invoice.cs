// Invoice.cs
// A complete invoice: header data, receiver, sender, item lines and totals.

using System;
using System.Collections.Generic;

namespace InvoiceMaker.Models
{
    /// <summary>
    /// Represents one complete invoice read from a text file.
    /// </summary>
    public class Invoice
    {
        public string InvoiceNumber { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime DueDate { get; set; }

        public InvoiceReceiver Receiver { get; set; }
        public InvoiceSender Sender { get; set; }

        public List<InvoiceItem> Items { get; set; }

        /// <summary>
        /// Discount granted on the whole invoice. Set from the GUI.
        /// </summary>
        public decimal Discount { get; set; }

        public Invoice()
        {
            Receiver = new InvoiceReceiver();
            Sender = new InvoiceSender();
            Items = new List<InvoiceItem>();
            Discount = 0m;
        }

        /// <summary>
        /// Grand total: the sum of all line totals, before discount.
        /// </summary>
        public decimal TotalAmount
        {
            get
            {
                decimal sum = 0m;
                foreach (InvoiceItem item in Items)
                {
                    sum += item.LineTotal;
                }
                return sum;
            }
        }

        /// <summary>
        /// Total tax included in the invoice: the sum of the tax
        /// included in every item line.
        /// </summary>
        public decimal TotalTaxIncluded
        {
            get
            {
                decimal sum = 0m;
                foreach (InvoiceItem item in Items)
                {
                    sum += item.TaxIncludedAmount;
                }
                return sum;
            }
        }

        /// <summary>
        /// Amount the customer must pay: total minus discount.
        /// The result is never below zero.
        /// </summary>
        public decimal AmountToPay
        {
            get
            {
                decimal amount = TotalAmount - Discount;
                return amount < 0m ? 0m : amount;
            }
        }
    }
}

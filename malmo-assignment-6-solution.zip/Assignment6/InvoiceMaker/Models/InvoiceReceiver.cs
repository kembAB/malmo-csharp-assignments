// InvoiceReceiver.cs
// The customer that receives the invoice.

namespace InvoiceMaker.Models
{
    /// <summary>
    /// Represents the company and contact person the invoice is sent to.
    /// </summary>
    public class InvoiceReceiver
    {
        public string CompanyName { get; set; }
        public string PersonName { get; set; }
        public string Street { get; set; }
        public string ZipCode { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
    }
}

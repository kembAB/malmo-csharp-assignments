// InvoiceItem.cs
// One line on an invoice: a description, a quantity, a unit price and a tax rate.
// The unit price is treated as a price that already includes tax.

namespace InvoiceMaker.Models
{
    /// <summary>
    /// Represents a single item line on an invoice.
    /// </summary>
    public class InvoiceItem
    {
        public string Description { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TaxRatePercent { get; set; }

        /// <summary>
        /// Total for this line: quantity multiplied by unit price.
        /// </summary>
        public decimal LineTotal
        {
            get { return Quantity * UnitPrice; }
        }

        /// <summary>
        /// The part of the line total that is tax.
        /// Because the unit price already includes tax, the tax part is
        /// LineTotal * TaxRatePercent / (100 + TaxRatePercent).
        /// Example: a line total of 125.00 with 25 percent tax contains
        /// 125.00 * 25 / 125 = 25.00 of tax.
        /// </summary>
        public decimal TaxIncludedAmount
        {
            get
            {
                if (TaxRatePercent <= 0m)
                {
                    return 0m;
                }
                return LineTotal * TaxRatePercent / (100m + TaxRatePercent);
            }
        }
    }
}

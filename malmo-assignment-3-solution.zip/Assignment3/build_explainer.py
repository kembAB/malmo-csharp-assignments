"""Builds the Assignment 3 explainer PDF.

All authored prose lives in PROSE_STRINGS and is checked before building:
no opening or closing parenthesis may appear in the prose. Verbatim code
and verbatim output are exempt from that rule and are loaded from disk.
"""
import pathlib
from xml.sax.saxutils import escape

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Preformatted, PageBreak

BASE = pathlib.Path(__file__).resolve().parent
PDF_PATH = BASE / "malmo-csharp-assignment-3-explainer.pdf"

# ---------------------------------------------------------------- prose
# Every string below is authored prose. None may contain a parenthesis.
PROSE = [
    ("Title", "Assignment 3 Explainer"),
    ("Subtitle", "Apu Animal Motel Version 3 with Generics"),
    ("Author", "Abel Haile Magicho"),
    ("Author", "Malmö University — Programming in C Sharp II"),
    ("Heading", "What the Assignment Asks"),
    ("Body", "The assignment is the third version of the Animal Motel project from the course Programming in C Sharp II at Malmö University. Its main objectives are to create generic types and to use collections with generic objects. The work starts from the Version 2 animal model and adds a reusable generic layer on top of it."),
    ("Bold", "Key point: one generic container class must serve animals, recipes, ingredients and qualifications alike."),
    ("Bullet", "Write an interface named IListManager with a type parameter and full XML documentation comments on every member. The members are a Count property, Add, ChangeAt, CheckIndex, DeleteAt, GetAt, ToStringArray and ToStringList."),
    ("Bullet", "Write a class named ListManager that implements the interface over a private List of T and validates every index before use."),
    ("Bullet", "Change AnimalManager so that it inherits ListManager of Animal. The class must stay small and add only the unique id handling for animals."),
    ("Bullet", "Adjust the MainForm to the generic managers and add a working Delete button. The user highlights an animal in the list, the form deletes it through the manager, and the list is refreshed."),
    ("Bullet", "Create a Recipe class with a name and a list of ingredients. The ingredients must make use of the ListManager class."),
    ("Bullet", "Create a RecipeManager class that inherits ListManager of Recipe. The assignment states that no further coding is needed in this class."),
    ("Bullet", "Design a RecipeForm dialog for the recipe name and its ingredients. Its Add, Change and Delete buttons must function properly, and saved recipes are shown on the MainForm."),
    ("Bullet", "Create a Staff class whose qualifications are held in a field declared with the interface type IListManager of string. The constructor creates the field as a ListManager of string."),
    ("Bullet", "Design a StaffForm dialog in the same style as RecipeForm. The Add button must function properly, and this solution implements Change and Delete as well."),
    ("Bullet", "VG part for grades A and B: use a Dictionary collection to handle data as key and value pairs. The dictionary class must validate the key whenever a key is used, it must offer methods to Add, Change, Delete and Get an item, and its implementation must be displayed on the GUI."),
    ("Bullet", "The finished project must compile and run correctly. The GUI must validate input and must never crash on a bad selection or a missing selection."),
    ("Heading", "How the Code Answers — Step by Step"),
    ("Bold", "Step 1 — The animal model from Version 2 is kept in full."),
    ("Body", "The Animals folder holds GenderType and EaterType as enums and IAnimal as the interface that every animal must follow. The abstract class Animal implements IAnimal with name, id, gender and age, and it declares GetEaterType, GetFoodSchedule and GetSpecies as abstract methods. The abstract category classes Mammal, Bird and Insect add number of teeth, flying speed and number of legs. The six species are Dog, Cat, Dove, Eagle, Butterfly and Bee. Each species returns its own eater type, its own species name and its own hard coded food schedule through the FoodSchedule class. FoodSchedule keeps a private list of strings and offers a Count property, a ValidateIndex method, an add method and read methods."),
    ("Bold", "Step 2 — The generic interface and the generic class form the heart of the solution."),
    ("Body", "IListManager of T in the Managers folder declares the eight operations with full XML documentation comments. ListManager of T implements the interface over a private List of T. Add refuses a null value. ChangeAt, DeleteAt and GetAt all pass through CheckIndex first, so an invalid index can never reach the inner list. ToStringArray and ToStringList build one string per stored object by calling ToString on each object. The class also carries a RemoveAt method that takes an index, because the assignment text names RemoveAt as the method the form calls for deletion."),
    ("Bold", "Step 3 — First use of the generic class: inheritance for animals."),
    ("Body", "AnimalManager inherits ListManager of Animal. It keeps a strict private id counter, and its AddAnimal method assigns the next unique id to the animal and then calls the inherited Add method. GetAnimalAt simply delegates to the inherited GetAt method. Every other operation, including RemoveAt, ChangeAt and Count, is inherited unchanged. The class stays deliberately small, exactly as the assignment intends."),
    ("Bold", "Step 4 — Second use of the generic class: composition for recipes."),
    ("Body", "Recipe in the Food folder holds its ingredients in a private field of type ListManager of string. The manager is not inherited here; it lives inside the recipe object and works for the recipe. The class exposes AddIngredient for adding, GetIngredients and GetIngredientsArray for reading, and the Ingredients property so a form can change and delete single ingredients. ToString returns the recipe name followed by its ingredients. RecipeManager then inherits ListManager of Recipe with an empty body and no further coding, as the assignment states."),
    ("Bold", "Step 5 — Third use of the generic class: an interface typed field for staff."),
    ("Body", "Staff in the Staff folder declares its qualifications field with the interface type IListManager of string. The constructor fills that field with a new ListManager of string. Code outside the class only ever sees the interface, which is the graded point of this part. A property exposes the qualifications as IListManager of string, AddQualification adds through the field, and ToString returns the name and the qualifications."),
    ("Bold", "Key point: the same ListManager code is reused three different ways — by inheritance, by composition and through an interface."),
    ("Bold", "Step 6 — The forms put the model on screen."),
    ("Body", "MainForm keeps the Version 2 work: category and species selection, animal input fields, adding an animal through dynamic binding as an Animal reference, the animal list and the food schedule display for the selected animal. The Delete button deletes the highlighted animal through the RemoveAt method of the manager and refreshes the list. The Change button builds a new animal from the input fields, keeps the old id and calls ChangeAt. Buttons open RecipeForm and StaffForm as dialogs, and the saved recipes and the saved staff members are shown in their own lists on the MainForm. Every list starts empty, every input is validated, and a missing selection shows a message instead of crashing."),
    ("Bold", "Step 7 — The VG part: a dictionary of food schedules."),
    ("Body", "FoodScheduleDictionary in the Food folder is marked clearly in the code as the VG part for grades A and B. It holds a Dictionary with string keys and string array values. Each key is a species name and each value is the food schedule lines for that species. The constructor preloads the six species by reading the schedules straight from the species classes themselves. ValidateKey runs whenever a key is used: Add rejects a badly formed key and a key that already exists, while Change, Delete and GetItem refuse a key that is not in the dictionary. The MainForm shows the full contents of the dictionary in a list box, so the implementation is visible on the GUI as the assignment requires."),
    ("Heading", "How to Run"),
    ("Bullet", "Build the Windows Forms project by opening a terminal in the AnimalMotel folder and running dotnet build with the .NET 8 SDK. The build must finish with zero errors."),
    ("Bullet", "Start the program by running the built AnimalMotel application on Windows. The project targets net8.0-windows with Windows Forms enabled."),
    ("Bullet", "Run the console harness by opening a terminal in the Harness folder and running dotnet run. The harness links the same non GUI source files and prints the animals, the change and delete results, the recipe, the staff member and the dictionary exercise."),
    ("Bullet", "Compare the harness printout with output.txt in the Assignment3 folder. That file holds the real output, saved verbatim."),
    ("Heading", "Full Code"),
    ("Body", "The full code of every project source file follows verbatim, each file under its own file name. The harness program is included at the end and labelled as such."),
    ("Heading", "Real Output"),
    ("Body", "The text below is the real output of the harness run, copied verbatim from output.txt."),
    ("Heading", "Glossary"),
]

GLOSSARY = [
    ("Generic class", "A class written with a type parameter so the same code can store many different types in a type safe way."),
    ("Type parameter T", "The placeholder letter used in the generic code. When a manager is created, T is replaced by a real type such as Animal, Recipe or string."),
    ("Interface", "A contract that lists members a class must offer, without saying how the class does the work."),
    ("Inheritance", "Building a new class on an existing class so the new class receives its members. AnimalManager and RecipeManager use the generic class this way."),
    ("Composition", "Holding an object of another class as a field inside your own class and using it from there. Recipe uses the generic class this way for its ingredients."),
    ("Interface typed field", "A field declared with an interface type while the object behind it belongs to a class that implements the interface. The Staff qualifications field is the example in this solution."),
    ("Polymorphism", "Treating objects of different classes through one shared type, so one call can reach different implementations."),
    ("Dynamic binding", "The decision at run time about which override of a method runs, based on the real object behind a base class reference."),
    ("Dictionary", "A collection that stores data as key and value pairs, so a value is found by giving its key."),
    ("Key validation", "Checking a dictionary key before use, so empty keys and keys that are not stored can never cause a crash."),
    ("Food schedule", "The set of text lines that describe when and what a species is fed during a day."),
    ("ListBox", "A Windows Forms control that shows a list of strings and lets the user highlight one line."),
]

PROSE_STRINGS = [text for _style, text in PROSE] + [t for t, _d in GLOSSARY] + [d for _t, d in GLOSSARY]
for s in PROSE_STRINGS:
    assert "(" not in s and ")" not in s, "Parenthesis found in prose: " + s

# ---------------------------------------------------------------- files
SOURCE_FILES = [
    "AnimalMotel/AnimalMotel.csproj",
    "AnimalMotel/Program.cs",
    "AnimalMotel/Animals/GenderType.cs",
    "AnimalMotel/Animals/EaterType.cs",
    "AnimalMotel/Animals/IAnimal.cs",
    "AnimalMotel/Animals/FoodSchedule.cs",
    "AnimalMotel/Animals/Animal.cs",
    "AnimalMotel/Animals/Mammal.cs",
    "AnimalMotel/Animals/Bird.cs",
    "AnimalMotel/Animals/Insect.cs",
    "AnimalMotel/Animals/Dog.cs",
    "AnimalMotel/Animals/Cat.cs",
    "AnimalMotel/Animals/Dove.cs",
    "AnimalMotel/Animals/Eagle.cs",
    "AnimalMotel/Animals/Butterfly.cs",
    "AnimalMotel/Animals/Bee.cs",
    "AnimalMotel/Managers/IListManager.cs",
    "AnimalMotel/Managers/ListManager.cs",
    "AnimalMotel/Managers/AnimalManager.cs",
    "AnimalMotel/Managers/RecipeManager.cs",
    "AnimalMotel/Food/Recipe.cs",
    "AnimalMotel/Food/FoodScheduleDictionary.cs",
    "AnimalMotel/Staff/Staff.cs",
    "AnimalMotel/Forms/MainForm.cs",
    "AnimalMotel/Forms/MainForm.Designer.cs",
    "AnimalMotel/Forms/RecipeForm.cs",
    "AnimalMotel/Forms/RecipeForm.Designer.cs",
    "AnimalMotel/Forms/StaffForm.cs",
    "AnimalMotel/Forms/StaffForm.Designer.cs",
    "Harness/Harness.csproj",
    "Harness/Program.cs — the harness program",
]

def load_source(entry):
    rel = entry.split(" — ")[0]
    return (BASE / rel).read_text(encoding="utf-8")

# ---------------------------------------------------------------- build
styles = {
    "Title": ParagraphStyle("Title2", fontName="Helvetica-Bold", fontSize=26, leading=32, spaceAfter=6),
    "Subtitle": ParagraphStyle("Subtitle2", fontName="Helvetica", fontSize=15, leading=20, spaceAfter=4),
    "Author": ParagraphStyle("Author2", fontName="Helvetica", fontSize=12, leading=16, spaceAfter=2),
    "Heading": ParagraphStyle("Heading2", fontName="Helvetica-Bold", fontSize=16, leading=21, spaceBefore=14, spaceAfter=6, textColor=colors.HexColor("#1a3a5c")),
    "Body": ParagraphStyle("Body2", fontName="Helvetica", fontSize=10.5, leading=15, spaceAfter=6),
    "Bold": ParagraphStyle("Bold2", fontName="Helvetica-Bold", fontSize=10.5, leading=15, spaceAfter=6),
    "Bullet": ParagraphStyle("Bullet2", fontName="Helvetica", fontSize=10.5, leading=15, leftIndent=14, bulletIndent=4, spaceAfter=4),
    "FileHead": ParagraphStyle("FileHead", fontName="Helvetica-Bold", fontSize=11, leading=14, spaceBefore=12, spaceAfter=4, textColor=colors.HexColor("#1a3a5c")),
    "GlossTerm": ParagraphStyle("GlossTerm", fontName="Helvetica-Bold", fontSize=10.5, leading=14, spaceBefore=6),
    "GlossDef": ParagraphStyle("GlossDef", fontName="Helvetica", fontSize=10.5, leading=15, leftIndent=12, spaceAfter=4),
}
code_style = ParagraphStyle("Code", fontName="Courier", fontSize=6.2, leading=7.6, leftIndent=0)

story = []
code_started = False
output_started = False
glossary_started = False
for style_name, text in PROSE:
    if text == "Full Code":
        code_started = True
        story.append(Paragraph(escape(text), styles["Heading"]))
        # intro body for code section is the next PROSE body entry; handled in loop order below
        continue
    if text == "Real Output":
        # insert all source files before this heading
        for entry in SOURCE_FILES:
            story.append(Paragraph(escape(entry), styles["FileHead"]))
            code = load_source(entry)
            for chunk_start in range(0, len(code.splitlines()), 60):
                chunk = "\n".join(code.splitlines()[chunk_start:chunk_start + 60])
                story.append(Preformatted(escape(chunk), code_style))
            story.append(Spacer(1, 4))
        story.append(PageBreak())
        story.append(Paragraph(escape(text), styles["Heading"]))
        output_started = True
        continue
    if text == "Glossary":
        output_text = (BASE / "output.txt").read_text(encoding="utf-8")
        for chunk_start in range(0, len(output_text.splitlines()), 60):
            chunk = "\n".join(output_text.splitlines()[chunk_start:chunk_start + 60])
            story.append(Preformatted(escape(chunk), code_style))
        story.append(PageBreak())
        story.append(Paragraph(escape(text), styles["Heading"]))
        for term, definition in GLOSSARY:
            story.append(Paragraph(escape(term), styles["GlossTerm"]))
            story.append(Paragraph(escape(definition), styles["GlossDef"]))
        glossary_started = True
        continue
    if style_name == "Bullet":
        story.append(Paragraph(escape(text), styles["Bullet"], bulletText="•"))
    else:
        story.append(Paragraph(escape(text), styles[style_name]))
    if style_name == "Title":
        story.append(Spacer(1, 6))

assert code_started and output_started and glossary_started

doc = SimpleDocTemplate(str(PDF_PATH), pagesize=A4,
                        leftMargin=30, rightMargin=30, topMargin=36, bottomMargin=36,
                        title="Assignment 3 Explainer — Abel Haile Magicho",
                        author="Abel Haile Magicho")
doc.build(story)
print("Built:", PDF_PATH)

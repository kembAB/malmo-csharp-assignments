using System.Collections.Generic;

namespace AnimalMotel.Managers
{
    /// <summary>
    /// Defines the operations that every list manager must offer, whatever
    /// type of object the list holds.
    /// </summary>
    /// <typeparam name="T">The type of object stored in the list.</typeparam>
    public interface IListManager<T>
    {
        /// <summary>
        /// Gets the number of objects currently stored in the list.
        /// </summary>
        /// <value>The number of objects in the list.</value>
        int Count { get; }

        /// <summary>
        /// Adds an object to the end of the list.
        /// </summary>
        /// <param name="aType">The object to add.</param>
        /// <returns>True when the object was added, false otherwise.</returns>
        bool Add(T aType);

        /// <summary>
        /// Replaces the object at a given index with a new object.
        /// </summary>
        /// <param name="aType">The new object.</param>
        /// <param name="anIndex">The index of the object to replace.</param>
        /// <returns>True when the change was made, false otherwise.</returns>
        bool ChangeAt(T aType, int anIndex);

        /// <summary>
        /// Checks whether an index is inside the list.
        /// </summary>
        /// <param name="index">The index to check.</param>
        /// <returns>True when the index is valid, false otherwise.</returns>
        bool CheckIndex(int index);

        /// <summary>
        /// Deletes the object at a given index from the list.
        /// </summary>
        /// <param name="anIndex">The index of the object to delete.</param>
        /// <returns>True when the object was deleted, false otherwise.</returns>
        bool DeleteAt(int anIndex);

        /// <summary>
        /// Reads the object at a given index.
        /// </summary>
        /// <param name="anIndex">The index of the object to read.</param>
        /// <returns>The object at the index, or the default value for the type when the index is invalid.</returns>
        T GetAt(int anIndex);

        /// <summary>
        /// Builds an array of strings with one string for every object in
        /// the list, using the ToString method of each object.
        /// </summary>
        /// <returns>An array of strings describing all objects in the list.</returns>
        string[] ToStringArray();

        /// <summary>
        /// Builds a list of strings with one string for every object in
        /// the list, using the ToString method of each object.
        /// </summary>
        /// <returns>A list of strings describing all objects in the list.</returns>
        List<string> ToStringList();
    }
}

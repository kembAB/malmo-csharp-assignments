using System.Collections.Generic;

namespace AnimalMotel.Managers
{
    /// <summary>
    /// A generic container class. It keeps a private list of objects of the
    /// type T and offers the common list operations once, so the same code
    /// serves animals, recipes, ingredients, qualifications and any other type.
    /// </summary>
    /// <typeparam name="T">The type of object stored in the list.</typeparam>
    public class ListManager<T> : IListManager<T>
    {
        private List<T> list;

        public ListManager()
        {
            list = new List<T>();
        }

        public int Count
        {
            get { return list.Count; }
        }

        public bool Add(T aType)
        {
            if (aType == null)
                return false;
            list.Add(aType);
            return true;
        }

        public bool ChangeAt(T aType, int anIndex)
        {
            if (aType == null || !CheckIndex(anIndex))
                return false;
            list[anIndex] = aType;
            return true;
        }

        public bool CheckIndex(int index)
        {
            return index >= 0 && index < list.Count;
        }

        public bool DeleteAt(int anIndex)
        {
            if (!CheckIndex(anIndex))
                return false;
            list.RemoveAt(anIndex);
            return true;
        }

        /// <summary>
        /// Deletes the object at the given index. This is the name the
        /// assignment text uses for the call made from the form when the
        /// user clicks the Delete button, so it is kept as its own method.
        /// It works exactly like DeleteAt.
        /// </summary>
        public bool RemoveAt(int anIndex)
        {
            return DeleteAt(anIndex);
        }

        public T GetAt(int anIndex)
        {
            if (!CheckIndex(anIndex))
                return default(T);
            return list[anIndex];
        }

        public string[] ToStringArray()
        {
            string[] result = new string[list.Count];
            for (int i = 0; i < list.Count; i++)
                result[i] = list[i].ToString();
            return result;
        }

        public List<string> ToStringList()
        {
            List<string> result = new List<string>();
            foreach (T item in list)
                result.Add(item.ToString());
            return result;
        }
    }
}

using AnimalMotel.Animals;

namespace AnimalMotel.Managers
{
    /// <summary>
    /// Manager for animals. It inherits every list operation from
    /// ListManager of Animal and adds only the unique id handling, exactly
    /// as the assignment intends. The class therefore stays small.
    /// </summary>
    public class AnimalManager : ListManager<Animal>
    {
        private int idCounter;

        public AnimalManager()
        {
            idCounter = 1;
        }

        /// <summary>
        /// Gives the animal the next unique id and then adds it through
        /// the inherited Add method.
        /// </summary>
        public bool AddAnimal(Animal animal)
        {
            if (animal == null)
                return false;
            animal.Id = idCounter.ToString();
            idCounter++;
            return Add(animal);
        }

        /// <summary>Reads the animal at the given index.</summary>
        public Animal GetAnimalAt(int index)
        {
            return GetAt(index);
        }
    }
}

using AnimalMotel.Food;

namespace AnimalMotel.Managers
{
    /// <summary>
    /// Manager for recipes. The assignment states that no further coding is
    /// needed in this class: all operations come from ListManager of Recipe.
    /// </summary>
    public class RecipeManager : ListManager<Recipe>
    {
    }
}

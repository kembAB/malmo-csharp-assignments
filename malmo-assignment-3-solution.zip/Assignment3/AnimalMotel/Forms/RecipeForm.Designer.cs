namespace AnimalMotel.Forms
{
    partial class RecipeForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblRecipeName = new System.Windows.Forms.Label();
            this.txtRecipeName = new System.Windows.Forms.TextBox();
            this.lblIngredient = new System.Windows.Forms.Label();
            this.txtIngredient = new System.Windows.Forms.TextBox();
            this.btnAddIngredient = new System.Windows.Forms.Button();
            this.btnChangeIngredient = new System.Windows.Forms.Button();
            this.btnDeleteIngredient = new System.Windows.Forms.Button();
            this.lstIngredients = new System.Windows.Forms.ListBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // lblRecipeName
            this.lblRecipeName.AutoSize = true;
            this.lblRecipeName.Location = new System.Drawing.Point(12, 15);
            this.lblRecipeName.Name = "lblRecipeName";
            this.lblRecipeName.Text = "Recipe name";
            // txtRecipeName
            this.txtRecipeName.Location = new System.Drawing.Point(120, 12);
            this.txtRecipeName.Name = "txtRecipeName";
            this.txtRecipeName.Size = new System.Drawing.Size(330, 23);
            // lblIngredient
            this.lblIngredient.AutoSize = true;
            this.lblIngredient.Location = new System.Drawing.Point(12, 55);
            this.lblIngredient.Name = "lblIngredient";
            this.lblIngredient.Text = "Ingredient";
            // txtIngredient
            this.txtIngredient.Location = new System.Drawing.Point(120, 52);
            this.txtIngredient.Name = "txtIngredient";
            this.txtIngredient.Size = new System.Drawing.Size(330, 23);
            // btnAddIngredient
            this.btnAddIngredient.Location = new System.Drawing.Point(120, 85);
            this.btnAddIngredient.Name = "btnAddIngredient";
            this.btnAddIngredient.Size = new System.Drawing.Size(100, 28);
            this.btnAddIngredient.Text = "Add";
            this.btnAddIngredient.Click += new System.EventHandler(this.btnAddIngredient_Click);
            // btnChangeIngredient
            this.btnChangeIngredient.Location = new System.Drawing.Point(235, 85);
            this.btnChangeIngredient.Name = "btnChangeIngredient";
            this.btnChangeIngredient.Size = new System.Drawing.Size(100, 28);
            this.btnChangeIngredient.Text = "Change";
            this.btnChangeIngredient.Click += new System.EventHandler(this.btnChangeIngredient_Click);
            // btnDeleteIngredient
            this.btnDeleteIngredient.Location = new System.Drawing.Point(350, 85);
            this.btnDeleteIngredient.Name = "btnDeleteIngredient";
            this.btnDeleteIngredient.Size = new System.Drawing.Size(100, 28);
            this.btnDeleteIngredient.Text = "Delete";
            this.btnDeleteIngredient.Click += new System.EventHandler(this.btnDeleteIngredient_Click);
            // lstIngredients
            this.lstIngredients.FormattingEnabled = true;
            this.lstIngredients.Location = new System.Drawing.Point(15, 125);
            this.lstIngredients.Name = "lstIngredients";
            this.lstIngredients.Size = new System.Drawing.Size(435, 180);
            this.lstIngredients.SelectedIndexChanged += new System.EventHandler(this.lstIngredients_SelectedIndexChanged);
            // btnOk
            this.btnOk.Location = new System.Drawing.Point(235, 320);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(100, 30);
            this.btnOk.Text = "OK";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // btnCancel
            this.btnCancel.Location = new System.Drawing.Point(350, 320);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // RecipeForm
            this.ClientSize = new System.Drawing.Size(464, 364);
            this.Controls.Add(this.lblRecipeName);
            this.Controls.Add(this.txtRecipeName);
            this.Controls.Add(this.lblIngredient);
            this.Controls.Add(this.txtIngredient);
            this.Controls.Add(this.btnAddIngredient);
            this.Controls.Add(this.btnChangeIngredient);
            this.Controls.Add(this.btnDeleteIngredient);
            this.Controls.Add(this.lstIngredients);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.btnCancel);
            this.Name = "RecipeForm";
            this.Text = "Recipe";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblRecipeName;
        private System.Windows.Forms.TextBox txtRecipeName;
        private System.Windows.Forms.Label lblIngredient;
        private System.Windows.Forms.TextBox txtIngredient;
        private System.Windows.Forms.Button btnAddIngredient;
        private System.Windows.Forms.Button btnChangeIngredient;
        private System.Windows.Forms.Button btnDeleteIngredient;
        private System.Windows.Forms.ListBox lstIngredients;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
    }
}

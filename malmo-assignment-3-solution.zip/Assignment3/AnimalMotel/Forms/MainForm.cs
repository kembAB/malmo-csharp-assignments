using System;
using System.Globalization;
using System.Windows.Forms;
using AnimalMotel.Animals;
using AnimalMotel.Food;
using AnimalMotel.Managers;
using AnimalMotel.StaffMembers;

namespace AnimalMotel.Forms
{
    /// <summary>
    /// The main window. It keeps the Version 2 work with categories,
    /// species, animal input, the animal list and the food schedule display,
    /// now running on the generic managers. It also hosts the recipe and
    /// staff dialogs, the saved recipes and staff lists, and the VG
    /// dictionary display.
    /// </summary>
    public partial class MainForm : Form
    {
        private AnimalManager animalManager;
        private RecipeManager recipeManager;
        private ListManager<Staff> staffManager;
        // VG PART FOR GRADES A AND B: the dictionary object shown on the GUI.
        private FoodScheduleDictionary foodScheduleDictionary;

        public MainForm()
        {
            InitializeComponent();
            animalManager = new AnimalManager();
            recipeManager = new RecipeManager();
            staffManager = new ListManager<Staff>();
            foodScheduleDictionary = new FoodScheduleDictionary();
            InitializeGui();
        }

        private void InitializeGui()
        {
            lstCategory.Items.Clear();
            lstCategory.Items.AddRange(new string[] { "Mammal", "Bird", "Insect" });
            cmbGender.Items.Clear();
            cmbGender.Items.AddRange(Enum.GetNames(typeof(GenderType)));
            cmbGender.SelectedIndex = 0;
            RefreshDictionaryList();
        }

        private void lstCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstSpecies.Items.Clear();
            string category = lstCategory.SelectedItem as string;
            if (category == "Mammal")
                lstSpecies.Items.AddRange(new string[] { "Dog", "Cat" });
            else if (category == "Bird")
                lstSpecies.Items.AddRange(new string[] { "Dove", "Eagle" });
            else if (category == "Insect")
                lstSpecies.Items.AddRange(new string[] { "Butterfly", "Bee" });
        }

        private void lstSpecies_SelectedIndexChanged(object sender, EventArgs e)
        {
            string species = lstSpecies.SelectedItem as string;
            if (species == "Dog") lblSpecial.Text = "Tail length in cm";
            else if (species == "Cat") lblSpecial.Text = "Breed";
            else if (species == "Dove") lblSpecial.Text = "Wing span in cm";
            else if (species == "Eagle") lblSpecial.Text = "Beak length in cm";
            else if (species == "Butterfly") lblSpecial.Text = "Wing colour";
            else if (species == "Bee") lblSpecial.Text = "Number of wings";
            else lblSpecial.Text = "Special data";
        }

        /// <summary>
        /// Builds an animal of the selected species from the input fields.
        /// The returned object is typed as Animal, so the manager works by
        /// dynamic binding to the real species. A badly filled form gives
        /// null after a message has been shown.
        /// </summary>
        private Animal CreateAnimalFromInput()
        {
            string species = lstSpecies.SelectedItem as string;
            if (species == null)
            {
                MessageBox.Show("Select a category and a species first.");
                return null;
            }
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Write a name for the animal first.");
                return null;
            }
            int age;
            if (!int.TryParse(txtAge.Text.Trim(), out age) || age < 0)
            {
                MessageBox.Show("Age must be a whole number that is zero or more.");
                return null;
            }
            GenderType gender = GenderType.Unknown;
            if (cmbGender.SelectedItem != null)
                Enum.TryParse(cmbGender.SelectedItem.ToString(), out gender);

            string name = txtName.Text.Trim();
            string special = txtSpecial.Text.Trim();
            double number;
            int wholeNumber;

            switch (species)
            {
                case "Dog":
                    if (!double.TryParse(special, NumberStyles.Number, CultureInfo.InvariantCulture, out number))
                    { MessageBox.Show("Tail length must be a number."); return null; }
                    return new Dog(name, gender, age, number);
                case "Cat":
                    if (special.Length == 0)
                    { MessageBox.Show("Write the breed of the cat."); return null; }
                    return new Cat(name, gender, age, special);
                case "Dove":
                    if (!double.TryParse(special, NumberStyles.Number, CultureInfo.InvariantCulture, out number))
                    { MessageBox.Show("Wing span must be a number."); return null; }
                    return new Dove(name, gender, age, number);
                case "Eagle":
                    if (!double.TryParse(special, NumberStyles.Number, CultureInfo.InvariantCulture, out number))
                    { MessageBox.Show("Beak length must be a number."); return null; }
                    return new Eagle(name, gender, age, number);
                case "Butterfly":
                    if (special.Length == 0)
                    { MessageBox.Show("Write the wing colour of the butterfly."); return null; }
                    return new Butterfly(name, gender, age, special);
                case "Bee":
                    if (!int.TryParse(special, out wholeNumber) || wholeNumber < 0)
                    { MessageBox.Show("Number of wings must be a whole number."); return null; }
                    return new Bee(name, gender, age, wholeNumber);
                default:
                    return null;
            }
        }

        private void RefreshAnimalList()
        {
            lstAnimals.Items.Clear();
            lstAnimals.Items.AddRange(animalManager.ToStringArray());
            lstFoodSchedule.Items.Clear();
        }

        private void btnAddAnimal_Click(object sender, EventArgs e)
        {
            Animal animal = CreateAnimalFromInput();
            if (animal == null)
                return;
            animalManager.AddAnimal(animal);
            RefreshAnimalList();
        }

        private void btnChangeAnimal_Click(object sender, EventArgs e)
        {
            int index = lstAnimals.SelectedIndex;
            if (!animalManager.CheckIndex(index))
            {
                MessageBox.Show("Select an animal in the list first.");
                return;
            }
            Animal changed = CreateAnimalFromInput();
            if (changed == null)
                return;
            // The changed animal keeps the id of the animal it replaces.
            changed.Id = animalManager.GetAnimalAt(index).Id;
            animalManager.ChangeAt(changed, index);
            RefreshAnimalList();
        }

        private void btnDeleteAnimal_Click(object sender, EventArgs e)
        {
            int index = lstAnimals.SelectedIndex;
            if (!animalManager.CheckIndex(index))
            {
                MessageBox.Show("Select an animal in the list first.");
                return;
            }
            // The assignment asks the form to delete through RemoveAt.
            animalManager.RemoveAt(index);
            RefreshAnimalList();
        }

        private void lstAnimals_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstFoodSchedule.Items.Clear();
            int index = lstAnimals.SelectedIndex;
            if (!animalManager.CheckIndex(index))
                return;
            Animal animal = animalManager.GetAnimalAt(index);
            if (animal == null)
                return;
            txtName.Text = animal.Name;
            txtAge.Text = animal.Age.ToString();
            cmbGender.SelectedItem = animal.Gender.ToString();
            lstFoodSchedule.Items.AddRange(animal.GetFoodSchedule().ToStringArray());
        }

        private void btnOpenRecipe_Click(object sender, EventArgs e)
        {
            using (RecipeForm form = new RecipeForm())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    recipeManager.Add(form.Recipe);
                    lstRecipes.Items.Clear();
                    lstRecipes.Items.AddRange(recipeManager.ToStringArray());
                }
            }
        }

        private void btnOpenStaff_Click(object sender, EventArgs e)
        {
            using (StaffForm form = new StaffForm())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    staffManager.Add(form.StaffMember);
                    lstStaff.Items.Clear();
                    lstStaff.Items.AddRange(staffManager.ToStringArray());
                }
            }
        }

        // VG PART FOR GRADES A AND B: the contents of the FoodScheduleDictionary
        // are displayed in a list box on the MainForm, as the assignment requires.
        private void RefreshDictionaryList()
        {
            lstDictionary.Items.Clear();
            lstDictionary.Items.AddRange(foodScheduleDictionary.ToStringList().ToArray());
        }
    }
}

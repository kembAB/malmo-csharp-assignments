namespace AnimalMotel.Forms
{
    partial class StaffForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblStaffName = new System.Windows.Forms.Label();
            this.txtStaffName = new System.Windows.Forms.TextBox();
            this.lblQualification = new System.Windows.Forms.Label();
            this.txtQualification = new System.Windows.Forms.TextBox();
            this.btnAddQualification = new System.Windows.Forms.Button();
            this.btnChangeQualification = new System.Windows.Forms.Button();
            this.btnDeleteQualification = new System.Windows.Forms.Button();
            this.lstQualifications = new System.Windows.Forms.ListBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // lblStaffName
            this.lblStaffName.AutoSize = true;
            this.lblStaffName.Location = new System.Drawing.Point(12, 15);
            this.lblStaffName.Name = "lblStaffName";
            this.lblStaffName.Text = "Staff name";
            // txtStaffName
            this.txtStaffName.Location = new System.Drawing.Point(120, 12);
            this.txtStaffName.Name = "txtStaffName";
            this.txtStaffName.Size = new System.Drawing.Size(330, 23);
            // lblQualification
            this.lblQualification.AutoSize = true;
            this.lblQualification.Location = new System.Drawing.Point(12, 55);
            this.lblQualification.Name = "lblQualification";
            this.lblQualification.Text = "Qualification";
            // txtQualification
            this.txtQualification.Location = new System.Drawing.Point(120, 52);
            this.txtQualification.Name = "txtQualification";
            this.txtQualification.Size = new System.Drawing.Size(330, 23);
            // btnAddQualification
            this.btnAddQualification.Location = new System.Drawing.Point(120, 85);
            this.btnAddQualification.Name = "btnAddQualification";
            this.btnAddQualification.Size = new System.Drawing.Size(100, 28);
            this.btnAddQualification.Text = "Add";
            this.btnAddQualification.Click += new System.EventHandler(this.btnAddQualification_Click);
            // btnChangeQualification
            this.btnChangeQualification.Location = new System.Drawing.Point(235, 85);
            this.btnChangeQualification.Name = "btnChangeQualification";
            this.btnChangeQualification.Size = new System.Drawing.Size(100, 28);
            this.btnChangeQualification.Text = "Change";
            this.btnChangeQualification.Click += new System.EventHandler(this.btnChangeQualification_Click);
            // btnDeleteQualification
            this.btnDeleteQualification.Location = new System.Drawing.Point(350, 85);
            this.btnDeleteQualification.Name = "btnDeleteQualification";
            this.btnDeleteQualification.Size = new System.Drawing.Size(100, 28);
            this.btnDeleteQualification.Text = "Delete";
            this.btnDeleteQualification.Click += new System.EventHandler(this.btnDeleteQualification_Click);
            // lstQualifications
            this.lstQualifications.FormattingEnabled = true;
            this.lstQualifications.Location = new System.Drawing.Point(15, 125);
            this.lstQualifications.Name = "lstQualifications";
            this.lstQualifications.Size = new System.Drawing.Size(435, 180);
            this.lstQualifications.SelectedIndexChanged += new System.EventHandler(this.lstQualifications_SelectedIndexChanged);
            // btnOk
            this.btnOk.Location = new System.Drawing.Point(235, 320);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(100, 30);
            this.btnOk.Text = "OK";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // btnCancel
            this.btnCancel.Location = new System.Drawing.Point(350, 320);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // StaffForm
            this.ClientSize = new System.Drawing.Size(464, 364);
            this.Controls.Add(this.lblStaffName);
            this.Controls.Add(this.txtStaffName);
            this.Controls.Add(this.lblQualification);
            this.Controls.Add(this.txtQualification);
            this.Controls.Add(this.btnAddQualification);
            this.Controls.Add(this.btnChangeQualification);
            this.Controls.Add(this.btnDeleteQualification);
            this.Controls.Add(this.lstQualifications);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.btnCancel);
            this.Name = "StaffForm";
            this.Text = "Staff";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblStaffName;
        private System.Windows.Forms.TextBox txtStaffName;
        private System.Windows.Forms.Label lblQualification;
        private System.Windows.Forms.TextBox txtQualification;
        private System.Windows.Forms.Button btnAddQualification;
        private System.Windows.Forms.Button btnChangeQualification;
        private System.Windows.Forms.Button btnDeleteQualification;
        private System.Windows.Forms.ListBox lstQualifications;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
    }
}

using System;
using System.Windows.Forms;
using AnimalMotel.StaffMembers;

namespace AnimalMotel.Forms
{
    /// <summary>
    /// Dialog for building one Staff object. It works in the same way as
    /// RecipeForm: a name at the top and a list that is filled with Add and
    /// maintained with Change and Delete. The Add button works fully, as
    /// the assignment requires, and Change and Delete are implemented too.
    /// </summary>
    public partial class StaffForm : Form
    {
        private Staff staffMember;

        public StaffForm()
        {
            InitializeComponent();
            staffMember = new Staff();
        }

        /// <summary>The staff member built in this dialog.</summary>
        public Staff StaffMember
        {
            get { return staffMember; }
        }

        private void RefreshQualificationList()
        {
            lstQualifications.Items.Clear();
            lstQualifications.Items.AddRange(staffMember.Qualifications.ToStringArray());
        }

        private void btnAddQualification_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtQualification.Text))
            {
                MessageBox.Show("Write a qualification first.");
                return;
            }
            staffMember.AddQualification(txtQualification.Text);
            txtQualification.Clear();
            RefreshQualificationList();
        }

        private void btnChangeQualification_Click(object sender, EventArgs e)
        {
            int index = lstQualifications.SelectedIndex;
            if (!staffMember.Qualifications.CheckIndex(index))
            {
                MessageBox.Show("Select a qualification in the list first.");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtQualification.Text))
            {
                MessageBox.Show("Write the new qualification text first.");
                return;
            }
            staffMember.Qualifications.ChangeAt(txtQualification.Text.Trim(), index);
            txtQualification.Clear();
            RefreshQualificationList();
        }

        private void btnDeleteQualification_Click(object sender, EventArgs e)
        {
            int index = lstQualifications.SelectedIndex;
            if (!staffMember.Qualifications.CheckIndex(index))
            {
                MessageBox.Show("Select a qualification in the list first.");
                return;
            }
            // IListManager of string has no RemoveAt, so DeleteAt is used here.
            staffMember.Qualifications.DeleteAt(index);
            RefreshQualificationList();
        }

        private void lstQualifications_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = lstQualifications.SelectedIndex;
            if (staffMember.Qualifications.CheckIndex(index))
                txtQualification.Text = staffMember.Qualifications.GetAt(index);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtStaffName.Text))
            {
                MessageBox.Show("Write a name for the staff member first.");
                DialogResult = DialogResult.None;
                return;
            }
            staffMember.Name = txtStaffName.Text.Trim();
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}

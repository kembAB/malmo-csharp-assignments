using System;
using System.Windows.Forms;
using AnimalMotel.Food;

namespace AnimalMotel.Forms
{
    /// <summary>
    /// Dialog for building one Recipe. The user writes the recipe name,
    /// then adds, changes and deletes ingredients in the list before
    /// closing with OK. The built recipe is exposed through the Recipe property.
    /// </summary>
    public partial class RecipeForm : Form
    {
        private Recipe recipe;

        public RecipeForm()
        {
            InitializeComponent();
            recipe = new Recipe();
        }

        /// <summary>The recipe built in this dialog.</summary>
        public Recipe Recipe
        {
            get { return recipe; }
        }

        private void RefreshIngredientList()
        {
            lstIngredients.Items.Clear();
            lstIngredients.Items.AddRange(recipe.GetIngredientsArray());
        }

        private void btnAddIngredient_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtIngredient.Text))
            {
                MessageBox.Show("Write an ingredient first.");
                return;
            }
            recipe.AddIngredient(txtIngredient.Text);
            txtIngredient.Clear();
            RefreshIngredientList();
        }

        private void btnChangeIngredient_Click(object sender, EventArgs e)
        {
            int index = lstIngredients.SelectedIndex;
            if (!recipe.Ingredients.CheckIndex(index))
            {
                MessageBox.Show("Select an ingredient in the list first.");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtIngredient.Text))
            {
                MessageBox.Show("Write the new ingredient text first.");
                return;
            }
            recipe.Ingredients.ChangeAt(txtIngredient.Text.Trim(), index);
            txtIngredient.Clear();
            RefreshIngredientList();
        }

        private void btnDeleteIngredient_Click(object sender, EventArgs e)
        {
            int index = lstIngredients.SelectedIndex;
            if (!recipe.Ingredients.CheckIndex(index))
            {
                MessageBox.Show("Select an ingredient in the list first.");
                return;
            }
            recipe.Ingredients.RemoveAt(index);
            RefreshIngredientList();
        }

        private void lstIngredients_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = lstIngredients.SelectedIndex;
            if (recipe.Ingredients.CheckIndex(index))
                txtIngredient.Text = recipe.Ingredients.GetAt(index);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtRecipeName.Text))
            {
                MessageBox.Show("Write a name for the recipe first.");
                DialogResult = DialogResult.None;
                return;
            }
            recipe.Name = txtRecipeName.Text.Trim();
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}

namespace AnimalMotel.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblCategory = new System.Windows.Forms.Label();
            this.lstCategory = new System.Windows.Forms.ListBox();
            this.lblSpecies = new System.Windows.Forms.Label();
            this.lstSpecies = new System.Windows.Forms.ListBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblGender = new System.Windows.Forms.Label();
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.lblAge = new System.Windows.Forms.Label();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.lblSpecial = new System.Windows.Forms.Label();
            this.txtSpecial = new System.Windows.Forms.TextBox();
            this.btnAddAnimal = new System.Windows.Forms.Button();
            this.btnChangeAnimal = new System.Windows.Forms.Button();
            this.btnDeleteAnimal = new System.Windows.Forms.Button();
            this.lblAnimals = new System.Windows.Forms.Label();
            this.lstAnimals = new System.Windows.Forms.ListBox();
            this.lblFoodSchedule = new System.Windows.Forms.Label();
            this.lstFoodSchedule = new System.Windows.Forms.ListBox();
            this.btnOpenRecipe = new System.Windows.Forms.Button();
            this.btnOpenStaff = new System.Windows.Forms.Button();
            this.lblRecipes = new System.Windows.Forms.Label();
            this.lstRecipes = new System.Windows.Forms.ListBox();
            this.lblStaff = new System.Windows.Forms.Label();
            this.lstStaff = new System.Windows.Forms.ListBox();
            this.lblDictionary = new System.Windows.Forms.Label();
            this.lstDictionary = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // lblCategory
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(12, 12);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Text = "Category";
            // lstCategory
            this.lstCategory.FormattingEnabled = true;
            this.lstCategory.Location = new System.Drawing.Point(12, 32);
            this.lstCategory.Name = "lstCategory";
            this.lstCategory.Size = new System.Drawing.Size(150, 84);
            this.lstCategory.SelectedIndexChanged += new System.EventHandler(this.lstCategory_SelectedIndexChanged);
            // lblSpecies
            this.lblSpecies.AutoSize = true;
            this.lblSpecies.Location = new System.Drawing.Point(178, 12);
            this.lblSpecies.Name = "lblSpecies";
            this.lblSpecies.Text = "Species";
            // lstSpecies
            this.lstSpecies.FormattingEnabled = true;
            this.lstSpecies.Location = new System.Drawing.Point(178, 32);
            this.lstSpecies.Name = "lstSpecies";
            this.lstSpecies.Size = new System.Drawing.Size(150, 84);
            this.lstSpecies.SelectedIndexChanged += new System.EventHandler(this.lstSpecies_SelectedIndexChanged);
            // lblName
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(12, 132);
            this.lblName.Name = "lblName";
            this.lblName.Text = "Name";
            // txtName
            this.txtName.Location = new System.Drawing.Point(110, 129);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(218, 23);
            // lblGender
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(12, 165);
            this.lblGender.Name = "lblGender";
            this.lblGender.Text = "Gender";
            // cmbGender
            this.cmbGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.Location = new System.Drawing.Point(110, 162);
            this.cmbGender.Name = "cmbGender";
            this.cmbGender.Size = new System.Drawing.Size(218, 23);
            // lblAge
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(12, 198);
            this.lblAge.Name = "lblAge";
            this.lblAge.Text = "Age";
            // txtAge
            this.txtAge.Location = new System.Drawing.Point(110, 195);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(218, 23);
            // lblSpecial
            this.lblSpecial.AutoSize = true;
            this.lblSpecial.Location = new System.Drawing.Point(12, 231);
            this.lblSpecial.Name = "lblSpecial";
            this.lblSpecial.Text = "Special data";
            // txtSpecial
            this.txtSpecial.Location = new System.Drawing.Point(110, 228);
            this.txtSpecial.Name = "txtSpecial";
            this.txtSpecial.Size = new System.Drawing.Size(218, 23);
            // btnAddAnimal
            this.btnAddAnimal.Location = new System.Drawing.Point(12, 268);
            this.btnAddAnimal.Name = "btnAddAnimal";
            this.btnAddAnimal.Size = new System.Drawing.Size(100, 30);
            this.btnAddAnimal.Text = "Add";
            this.btnAddAnimal.Click += new System.EventHandler(this.btnAddAnimal_Click);
            // btnChangeAnimal
            this.btnChangeAnimal.Location = new System.Drawing.Point(124, 268);
            this.btnChangeAnimal.Name = "btnChangeAnimal";
            this.btnChangeAnimal.Size = new System.Drawing.Size(100, 30);
            this.btnChangeAnimal.Text = "Change";
            this.btnChangeAnimal.Click += new System.EventHandler(this.btnChangeAnimal_Click);
            // btnDeleteAnimal
            this.btnDeleteAnimal.Location = new System.Drawing.Point(236, 268);
            this.btnDeleteAnimal.Name = "btnDeleteAnimal";
            this.btnDeleteAnimal.Size = new System.Drawing.Size(100, 30);
            this.btnDeleteAnimal.Text = "Delete";
            this.btnDeleteAnimal.Click += new System.EventHandler(this.btnDeleteAnimal_Click);
            // lblAnimals
            this.lblAnimals.AutoSize = true;
            this.lblAnimals.Location = new System.Drawing.Point(356, 12);
            this.lblAnimals.Name = "lblAnimals";
            this.lblAnimals.Text = "Animals in the motel";
            // lstAnimals
            this.lstAnimals.FormattingEnabled = true;
            this.lstAnimals.Location = new System.Drawing.Point(356, 32);
            this.lstAnimals.Name = "lstAnimals";
            this.lstAnimals.Size = new System.Drawing.Size(620, 150);
            this.lstAnimals.SelectedIndexChanged += new System.EventHandler(this.lstAnimals_SelectedIndexChanged);
            // lblFoodSchedule
            this.lblFoodSchedule.AutoSize = true;
            this.lblFoodSchedule.Location = new System.Drawing.Point(356, 195);
            this.lblFoodSchedule.Name = "lblFoodSchedule";
            this.lblFoodSchedule.Text = "Food schedule for the selected animal";
            // lstFoodSchedule
            this.lstFoodSchedule.FormattingEnabled = true;
            this.lstFoodSchedule.Location = new System.Drawing.Point(356, 215);
            this.lstFoodSchedule.Name = "lstFoodSchedule";
            this.lstFoodSchedule.Size = new System.Drawing.Size(620, 84);
            // btnOpenRecipe
            this.btnOpenRecipe.Location = new System.Drawing.Point(12, 320);
            this.btnOpenRecipe.Name = "btnOpenRecipe";
            this.btnOpenRecipe.Size = new System.Drawing.Size(150, 30);
            this.btnOpenRecipe.Text = "New recipe";
            this.btnOpenRecipe.Click += new System.EventHandler(this.btnOpenRecipe_Click);
            // btnOpenStaff
            this.btnOpenStaff.Location = new System.Drawing.Point(178, 320);
            this.btnOpenStaff.Name = "btnOpenStaff";
            this.btnOpenStaff.Size = new System.Drawing.Size(150, 30);
            this.btnOpenStaff.Text = "Add staff";
            this.btnOpenStaff.Click += new System.EventHandler(this.btnOpenStaff_Click);
            // lblRecipes
            this.lblRecipes.AutoSize = true;
            this.lblRecipes.Location = new System.Drawing.Point(12, 365);
            this.lblRecipes.Name = "lblRecipes";
            this.lblRecipes.Text = "Saved recipes";
            // lstRecipes
            this.lstRecipes.FormattingEnabled = true;
            this.lstRecipes.Location = new System.Drawing.Point(12, 385);
            this.lstRecipes.Name = "lstRecipes";
            this.lstRecipes.Size = new System.Drawing.Size(470, 95);
            // lblStaff
            this.lblStaff.AutoSize = true;
            this.lblStaff.Location = new System.Drawing.Point(500, 365);
            this.lblStaff.Name = "lblStaff";
            this.lblStaff.Text = "Saved staff members";
            // lstStaff
            this.lstStaff.FormattingEnabled = true;
            this.lstStaff.Location = new System.Drawing.Point(500, 385);
            this.lstStaff.Name = "lstStaff";
            this.lstStaff.Size = new System.Drawing.Size(476, 95);
            // lblDictionary
            this.lblDictionary.AutoSize = true;
            this.lblDictionary.Location = new System.Drawing.Point(12, 495);
            this.lblDictionary.Name = "lblDictionary";
            this.lblDictionary.Text = "Food schedule dictionary - VG part";
            // lstDictionary
            this.lstDictionary.FormattingEnabled = true;
            this.lstDictionary.Location = new System.Drawing.Point(12, 515);
            this.lstDictionary.Name = "lstDictionary";
            this.lstDictionary.Size = new System.Drawing.Size(964, 120);
            // MainForm
            this.ClientSize = new System.Drawing.Size(990, 650);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.lstCategory);
            this.Controls.Add(this.lblSpecies);
            this.Controls.Add(this.lstSpecies);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblGender);
            this.Controls.Add(this.cmbGender);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.lblSpecial);
            this.Controls.Add(this.txtSpecial);
            this.Controls.Add(this.btnAddAnimal);
            this.Controls.Add(this.btnChangeAnimal);
            this.Controls.Add(this.btnDeleteAnimal);
            this.Controls.Add(this.lblAnimals);
            this.Controls.Add(this.lstAnimals);
            this.Controls.Add(this.lblFoodSchedule);
            this.Controls.Add(this.lstFoodSchedule);
            this.Controls.Add(this.btnOpenRecipe);
            this.Controls.Add(this.btnOpenStaff);
            this.Controls.Add(this.lblRecipes);
            this.Controls.Add(this.lstRecipes);
            this.Controls.Add(this.lblStaff);
            this.Controls.Add(this.lstStaff);
            this.Controls.Add(this.lblDictionary);
            this.Controls.Add(this.lstDictionary);
            this.Name = "MainForm";
            this.Text = "Apu Animal Motel - Version 3";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.ListBox lstCategory;
        private System.Windows.Forms.Label lblSpecies;
        private System.Windows.Forms.ListBox lstSpecies;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.ComboBox cmbGender;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label lblSpecial;
        private System.Windows.Forms.TextBox txtSpecial;
        private System.Windows.Forms.Button btnAddAnimal;
        private System.Windows.Forms.Button btnChangeAnimal;
        private System.Windows.Forms.Button btnDeleteAnimal;
        private System.Windows.Forms.Label lblAnimals;
        private System.Windows.Forms.ListBox lstAnimals;
        private System.Windows.Forms.Label lblFoodSchedule;
        private System.Windows.Forms.ListBox lstFoodSchedule;
        private System.Windows.Forms.Button btnOpenRecipe;
        private System.Windows.Forms.Button btnOpenStaff;
        private System.Windows.Forms.Label lblRecipes;
        private System.Windows.Forms.ListBox lstRecipes;
        private System.Windows.Forms.Label lblStaff;
        private System.Windows.Forms.ListBox lstStaff;
        private System.Windows.Forms.Label lblDictionary;
        private System.Windows.Forms.ListBox lstDictionary;
    }
}

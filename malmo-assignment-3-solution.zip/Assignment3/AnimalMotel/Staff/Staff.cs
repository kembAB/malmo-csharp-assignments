using AnimalMotel.Managers;

// The namespace is called StaffMembers so the class name Staff
// does not collide with its own namespace name in other files.
namespace AnimalMotel.StaffMembers
{
    /// <summary>
    /// A member of staff. The qualifications are strings held through the
    /// interface type IListManager of string. The field is declared with
    /// the interface type and filled with a ListManager of string in the
    /// constructor, which is the graded point of this part.
    /// </summary>
    public class Staff
    {
        private string name;
        private IListManager<string> qualifications;

        public Staff() : this(string.Empty)
        {
        }

        public Staff(string name)
        {
            this.name = name;
            qualifications = new ListManager<string>();
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>The qualifications, exposed through the interface type.</summary>
        public IListManager<string> Qualifications
        {
            get { return qualifications; }
        }

        /// <summary>Adds one qualification through the interface typed field.</summary>
        public bool AddQualification(string qualification)
        {
            if (string.IsNullOrWhiteSpace(qualification))
                return false;
            return qualifications.Add(qualification.Trim());
        }

        public override string ToString()
        {
            if (qualifications.Count == 0)
                return Name + ": no qualifications yet";
            return Name + ": " + string.Join(", ", qualifications.ToStringArray());
        }
    }
}

using System.Collections.Generic;
using AnimalMotel.Animals;

namespace AnimalMotel.Food
{
    // VG PART FOR GRADES A AND B
    // This class is the VG part of the assignment. It replaces the list
    // idea of the FoodSchedule class with a Dictionary where the key is a
    // species name and the value is the array of food schedule lines for
    // that species. The key is validated whenever a key is used.
    /// <summary>
    /// VG part. Holds food schedules in a Dictionary with string keys and
    /// string array values, mapping a species name to its schedule lines.
    /// </summary>
    public class FoodScheduleDictionary
    {
        private Dictionary<string, string[]> dictionary;

        public FoodScheduleDictionary()
        {
            dictionary = new Dictionary<string, string[]>();
            Preload();
        }

        /// <summary>Fills the dictionary with the six species schedules, read from the species classes themselves.</summary>
        private void Preload()
        {
            Animal[] animals = new Animal[]
            {
                new Dog("Sample", GenderType.Unknown, 0, 0),
                new Cat("Sample", GenderType.Unknown, 0, string.Empty),
                new Dove("Sample", GenderType.Unknown, 0, 0),
                new Eagle("Sample", GenderType.Unknown, 0, 0),
                new Butterfly("Sample", GenderType.Unknown, 0, string.Empty),
                new Bee("Sample", GenderType.Unknown, 0, 4)
            };
            foreach (Animal animal in animals)
                dictionary[animal.GetSpecies()] = animal.GetFoodSchedule().ToStringArray();
        }

        public int Count
        {
            get { return dictionary.Count; }
        }

        /// <summary>
        /// Validates a key. A valid key is a non empty text that already
        /// exists in the dictionary.
        /// </summary>
        public bool ValidateKey(string key)
        {
            if (string.IsNullOrWhiteSpace(key))
                return false;
            return dictionary.ContainsKey(key.Trim());
        }

        /// <summary>Checks only the form of a key, for use before an Add.</summary>
        private bool IsWellFormedKey(string key)
        {
            return !string.IsNullOrWhiteSpace(key);
        }

        /// <summary>Adds a new species schedule. An existing or badly formed key is rejected.</summary>
        public bool Add(string key, string[] value)
        {
            if (!IsWellFormedKey(key) || value == null || value.Length == 0)
                return false;
            if (ValidateKey(key))
                return false;
            dictionary.Add(key.Trim(), value);
            return true;
        }

        /// <summary>Changes the schedule stored under an existing key. The key is validated first.</summary>
        public bool Change(string key, string[] value)
        {
            if (!ValidateKey(key) || value == null || value.Length == 0)
                return false;
            dictionary[key.Trim()] = value;
            return true;
        }

        /// <summary>Deletes the item with the given key. The key is validated first.</summary>
        public bool Delete(string key)
        {
            if (!ValidateKey(key))
                return false;
            return dictionary.Remove(key.Trim());
        }

        /// <summary>Gets the schedule stored under the given key. The key is validated first and an invalid key gives null.</summary>
        public string[] GetItem(string key)
        {
            if (!ValidateKey(key))
                return null;
            return dictionary[key.Trim()];
        }

        /// <summary>Gets all keys currently in the dictionary.</summary>
        public string[] GetKeys()
        {
            List<string> keys = new List<string>(dictionary.Keys);
            return keys.ToArray();
        }

        /// <summary>Builds display lines with the species name followed by its schedule lines.</summary>
        public List<string> ToStringList()
        {
            List<string> lines = new List<string>();
            foreach (KeyValuePair<string, string[]> pair in dictionary)
                lines.Add(pair.Key + ": " + string.Join(" | ", pair.Value));
            return lines;
        }
    }
}

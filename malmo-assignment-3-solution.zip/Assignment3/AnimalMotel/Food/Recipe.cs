using System.Collections.Generic;
using AnimalMotel.Managers;

namespace AnimalMotel.Food
{
    /// <summary>
    /// A recipe for homemade animal food. The ingredients are strings held
    /// by a ListManager of string, so the generic class is reused by
    /// composition inside this class.
    /// </summary>
    public class Recipe
    {
        private string name;
        private ListManager<string> ingredients;

        public Recipe() : this(string.Empty)
        {
        }

        public Recipe(string name)
        {
            this.name = name;
            ingredients = new ListManager<string>();
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>The ingredients, managed by a ListManager of string.</summary>
        public ListManager<string> Ingredients
        {
            get { return ingredients; }
        }

        /// <summary>Adds one ingredient to the recipe.</summary>
        public bool AddIngredient(string ingredient)
        {
            if (string.IsNullOrWhiteSpace(ingredient))
                return false;
            return ingredients.Add(ingredient.Trim());
        }

        /// <summary>Reads all ingredients as a list of strings.</summary>
        public List<string> GetIngredients()
        {
            return ingredients.ToStringList();
        }

        /// <summary>Reads all ingredients as an array of strings.</summary>
        public string[] GetIngredientsArray()
        {
            return ingredients.ToStringArray();
        }

        public override string ToString()
        {
            if (ingredients.Count == 0)
                return Name + ": no ingredients yet";
            return Name + ": " + string.Join(", ", ingredients.ToStringArray());
        }
    }
}

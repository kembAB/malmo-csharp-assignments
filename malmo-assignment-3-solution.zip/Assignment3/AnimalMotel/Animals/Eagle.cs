namespace AnimalMotel.Animals
{
    /// <summary>An eagle. Carnivore. Its special data is the beak length.</summary>
    public class Eagle : Bird
    {
        private double beakLength;

        public Eagle() { }

        public Eagle(string name, GenderType gender, int age, double beakLength)
            : base(name, gender, age, 80.0)
        {
            this.beakLength = beakLength;
        }

        public double BeakLength
        {
            get { return beakLength; }
            set { beakLength = value; }
        }

        public override EaterType GetEaterType()
        {
            return EaterType.Carnivore;
        }

        public override string GetSpecies()
        {
            return "Eagle";
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFoodDescription("Morning: one portion of raw meat.");
            schedule.AddFoodDescription("Midday: fresh water only.");
            schedule.AddFoodDescription("Evening: one whole fish or a portion of raw meat.");
            return schedule;
        }
    }
}

namespace AnimalMotel.Animals
{
    /// <summary>Category class for insects.</summary>
    public abstract class Insect : Animal
    {
        private int numberOfLegs;

        protected Insect() { }

        protected Insect(string name, GenderType gender, int age, int numberOfLegs)
            : base(name, gender, age)
        {
            this.numberOfLegs = numberOfLegs;
        }

        public int NumberOfLegs
        {
            get { return numberOfLegs; }
            set { numberOfLegs = value; }
        }
    }
}

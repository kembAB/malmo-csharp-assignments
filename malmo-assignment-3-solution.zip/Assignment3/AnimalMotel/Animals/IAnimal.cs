namespace AnimalMotel.Animals
{
    /// <summary>
    /// Rules that every animal in the motel must follow. The interface is
    /// implemented by the abstract class Animal and thereby by every species.
    /// </summary>
    public interface IAnimal
    {
        string Name { get; set; }
        string Id { get; set; }
        GenderType Gender { get; set; }
        EaterType GetEaterType();
        FoodSchedule GetFoodSchedule();
        string GetSpecies();
    }
}

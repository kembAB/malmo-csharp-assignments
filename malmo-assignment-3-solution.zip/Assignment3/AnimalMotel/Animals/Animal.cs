namespace AnimalMotel.Animals
{
    /// <summary>
    /// Base class for all animals. It implements IAnimal with the data that
    /// all animals share and leaves the species specific information to the
    /// subclasses through the abstract methods.
    /// </summary>
    public abstract class Animal : IAnimal
    {
        private string name;
        private string id;
        private GenderType gender;
        private int age;

        protected Animal() : this(string.Empty, GenderType.Unknown, 0)
        {
        }

        protected Animal(string name, GenderType gender, int age)
        {
            this.name = name;
            this.gender = gender;
            this.age = age;
            id = string.Empty;
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        public GenderType Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value < 0 ? 0 : value; }
        }

        public abstract EaterType GetEaterType();

        public abstract FoodSchedule GetFoodSchedule();

        public abstract string GetSpecies();

        public override string ToString()
        {
            return string.Format("{0,-6} {1,-16} {2,-12} {3,-8} Age {4,-3} {5}",
                Id, Name, GetSpecies(), Gender, Age, GetEaterType());
        }
    }
}

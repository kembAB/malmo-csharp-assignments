namespace AnimalMotel.Animals
{
    /// <summary>A butterfly. Herbivore. Its special data is the wing colour.</summary>
    public class Butterfly : Insect
    {
        private string wingColor;

        public Butterfly() { wingColor = string.Empty; }

        public Butterfly(string name, GenderType gender, int age, string wingColor)
            : base(name, gender, age, 6)
        {
            this.wingColor = wingColor;
        }

        public string WingColor
        {
            get { return wingColor; }
            set { wingColor = value; }
        }

        public override EaterType GetEaterType()
        {
            return EaterType.Herbivore;
        }

        public override string GetSpecies()
        {
            return "Butterfly";
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFoodDescription("Morning: nectar from fresh flowers.");
            schedule.AddFoodDescription("Midday: sugar water on a sponge.");
            schedule.AddFoodDescription("Evening: nectar and a slice of ripe fruit.");
            return schedule;
        }
    }
}

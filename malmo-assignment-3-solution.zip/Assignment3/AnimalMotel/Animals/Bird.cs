namespace AnimalMotel.Animals
{
    /// <summary>Category class for birds.</summary>
    public abstract class Bird : Animal
    {
        private double flyingSpeed;

        protected Bird() { }

        protected Bird(string name, GenderType gender, int age, double flyingSpeed)
            : base(name, gender, age)
        {
            this.flyingSpeed = flyingSpeed;
        }

        public double FlyingSpeed
        {
            get { return flyingSpeed; }
            set { flyingSpeed = value; }
        }
    }
}

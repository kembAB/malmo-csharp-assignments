namespace AnimalMotel.Animals
{
    /// <summary>A cat. Carnivore. Its special data is the breed.</summary>
    public class Cat : Mammal
    {
        private string breed;

        public Cat() { breed = string.Empty; }

        public Cat(string name, GenderType gender, int age, string breed)
            : base(name, gender, age, 30)
        {
            this.breed = breed;
        }

        public string Breed
        {
            get { return breed; }
            set { breed = value; }
        }

        public override EaterType GetEaterType()
        {
            return EaterType.Carnivore;
        }

        public override string GetSpecies()
        {
            return "Cat";
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFoodDescription("Morning: half a tin of wet cat food.");
            schedule.AddFoodDescription("Midday: fresh water and a few dry kibbles.");
            schedule.AddFoodDescription("Evening: half a tin of wet cat food with cooked fish.");
            return schedule;
        }
    }
}

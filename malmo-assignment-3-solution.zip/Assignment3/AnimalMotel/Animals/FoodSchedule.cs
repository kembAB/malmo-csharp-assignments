using System.Collections.Generic;

namespace AnimalMotel.Animals
{
    /// <summary>
    /// A feeding schedule. Each element of the private list is one line of
    /// text describing part of the schedule for one day.
    /// </summary>
    public class FoodSchedule
    {
        private List<string> foodDescriptionList;

        public FoodSchedule()
        {
            foodDescriptionList = new List<string>();
        }

        /// <summary>The number of lines in the schedule.</summary>
        public int Count
        {
            get { return foodDescriptionList.Count; }
        }

        /// <summary>
        /// Returns true when the index is inside the list, otherwise false.
        /// </summary>
        public bool ValidateIndex(int index)
        {
            return index >= 0 && index < foodDescriptionList.Count;
        }

        /// <summary>Adds one line of text to the schedule.</summary>
        public bool AddFoodDescription(string description)
        {
            if (string.IsNullOrWhiteSpace(description))
                return false;
            foodDescriptionList.Add(description.Trim());
            return true;
        }

        /// <summary>
        /// Reads the line at the given index. An invalid index gives an
        /// empty string instead of an exception.
        /// </summary>
        public string GetFoodDescriptionAt(int index)
        {
            if (!ValidateIndex(index))
                return string.Empty;
            return foodDescriptionList[index];
        }

        /// <summary>Returns all lines as an array of strings.</summary>
        public string[] ToStringArray()
        {
            return foodDescriptionList.ToArray();
        }

        /// <summary>Returns a copy of all lines as a list of strings.</summary>
        public List<string> ToStringList()
        {
            return new List<string>(foodDescriptionList);
        }

        public override string ToString()
        {
            return string.Join(" | ", foodDescriptionList.ToArray());
        }
    }
}

namespace AnimalMotel.Animals
{
    /// <summary>
    /// The kind of food an animal eats.
    /// </summary>
    public enum EaterType
    {
        Carnivore,
        Herbivore,
        Omnivore
    }
}

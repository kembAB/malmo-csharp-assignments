namespace AnimalMotel.Animals
{
    /// <summary>A bee. Herbivore. Its special data is the number of wings.</summary>
    public class Bee : Insect
    {
        private int numberOfWings;

        public Bee() { numberOfWings = 4; }

        public Bee(string name, GenderType gender, int age, int numberOfWings)
            : base(name, gender, age, 6)
        {
            this.numberOfWings = numberOfWings;
        }

        public int NumberOfWings
        {
            get { return numberOfWings; }
            set { numberOfWings = value; }
        }

        public override EaterType GetEaterType()
        {
            return EaterType.Herbivore;
        }

        public override string GetSpecies()
        {
            return "Bee";
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFoodDescription("Morning: nectar and pollen from fresh flowers.");
            schedule.AddFoodDescription("Midday: sugar water near the hive.");
            schedule.AddFoodDescription("Evening: honey stored in the hive.");
            return schedule;
        }
    }
}

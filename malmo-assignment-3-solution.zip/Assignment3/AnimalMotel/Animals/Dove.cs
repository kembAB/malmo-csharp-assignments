namespace AnimalMotel.Animals
{
    /// <summary>A dove. Herbivore. Its special data is the wing span.</summary>
    public class Dove : Bird
    {
        private double wingSpan;

        public Dove() { }

        public Dove(string name, GenderType gender, int age, double wingSpan)
            : base(name, gender, age, 40.0)
        {
            this.wingSpan = wingSpan;
        }

        public double WingSpan
        {
            get { return wingSpan; }
            set { wingSpan = value; }
        }

        public override EaterType GetEaterType()
        {
            return EaterType.Herbivore;
        }

        public override string GetSpecies()
        {
            return "Dove";
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFoodDescription("Morning: a handful of mixed seeds.");
            schedule.AddFoodDescription("Midday: chopped greens and fresh water.");
            schedule.AddFoodDescription("Evening: a small handful of seeds and grit.");
            return schedule;
        }
    }
}

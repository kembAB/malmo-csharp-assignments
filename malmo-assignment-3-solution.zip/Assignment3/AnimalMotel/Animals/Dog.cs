namespace AnimalMotel.Animals
{
    /// <summary>A dog. Omnivore. Its special data is the tail length.</summary>
    public class Dog : Mammal
    {
        private double tailLength;

        public Dog() { }

        public Dog(string name, GenderType gender, int age, double tailLength)
            : base(name, gender, age, 42)
        {
            this.tailLength = tailLength;
        }

        public double TailLength
        {
            get { return tailLength; }
            set { tailLength = value; }
        }

        public override EaterType GetEaterType()
        {
            return EaterType.Omnivore;
        }

        public override string GetSpecies()
        {
            return "Dog";
        }

        public override FoodSchedule GetFoodSchedule()
        {
            FoodSchedule schedule = new FoodSchedule();
            schedule.AddFoodDescription("Morning: one bowl of dry dog food with fresh water.");
            schedule.AddFoodDescription("Midday: a small portion of cooked meat and vegetables.");
            schedule.AddFoodDescription("Evening: one bowl of dry dog food and a dog biscuit.");
            return schedule;
        }
    }
}

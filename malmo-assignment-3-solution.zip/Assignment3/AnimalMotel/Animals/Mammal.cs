namespace AnimalMotel.Animals
{
    /// <summary>Category class for mammals.</summary>
    public abstract class Mammal : Animal
    {
        private int numberOfTeeth;

        protected Mammal() { }

        protected Mammal(string name, GenderType gender, int age, int numberOfTeeth)
            : base(name, gender, age)
        {
            this.numberOfTeeth = numberOfTeeth;
        }

        public int NumberOfTeeth
        {
            get { return numberOfTeeth; }
            set { numberOfTeeth = value; }
        }
    }
}

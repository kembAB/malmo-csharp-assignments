namespace AnimalMotel.Animals
{
    /// <summary>
    /// The gender of an animal.
    /// </summary>
    public enum GenderType
    {
        Male,
        Female,
        Unknown
    }
}

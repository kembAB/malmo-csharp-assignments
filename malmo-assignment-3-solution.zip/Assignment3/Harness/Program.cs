using System;
using AnimalMotel.Animals;
using AnimalMotel.Food;
using AnimalMotel.Managers;
using AnimalMotel.StaffMembers;

namespace Harness
{
    internal class Program
    {
        private static void Main()
        {
            Console.WriteLine("Assignment 3 - Animal Motel Version 3 - Harness");
            Console.WriteLine("================================================");
            Console.WriteLine();

            // AnimalManager: add three animals through the generic manager
            AnimalManager animalManager = new AnimalManager();
            animalManager.AddAnimal(new Dog("Rex", GenderType.Male, 5, 25.5));
            animalManager.AddAnimal(new Cat("Misty", GenderType.Female, 3, "Siamese"));
            animalManager.AddAnimal(new Butterfly("Lady J.", GenderType.Female, 1, "Orange"));

            Console.WriteLine("Animals after adding three animals, count = " + animalManager.Count);
            foreach (string line in animalManager.ToStringArray())
                Console.WriteLine(line);
            Console.WriteLine();

            Console.WriteLine("Food schedule for the first animal, " + animalManager.GetAnimalAt(0).Name + ":");
            foreach (string line in animalManager.GetAnimalAt(0).GetFoodSchedule().ToStringArray())
                Console.WriteLine(line);
            Console.WriteLine();

            // ChangeAt and DeleteAt
            Animal changed = new Dog("Rex II", GenderType.Male, 6, 26.0);
            changed.Id = animalManager.GetAnimalAt(0).Id;
            bool changedOk = animalManager.ChangeAt(changed, 0);
            Console.WriteLine("ChangeAt index 0 succeeded: " + changedOk);
            bool deletedOk = animalManager.DeleteAt(2);
            Console.WriteLine("DeleteAt index 2 succeeded: " + deletedOk);
            Console.WriteLine("Animals after ChangeAt and DeleteAt, count = " + animalManager.Count);
            foreach (string line in animalManager.ToStringList())
                Console.WriteLine(line);
            Console.WriteLine();

            // Recipe built through RecipeManager, ingredients via ListManager of string
            RecipeManager recipeManager = new RecipeManager();
            Recipe recipe = new Recipe("Homemade Dog Stew");
            recipe.AddIngredient("beef");
            recipe.AddIngredient("rice");
            recipe.AddIngredient("carrots");
            recipe.AddIngredient("water");
            recipeManager.Add(recipe);
            Console.WriteLine("Recipes in RecipeManager, count = " + recipeManager.Count);
            Console.WriteLine(recipeManager.GetAt(0).ToString());
            Console.WriteLine();

            // Staff, qualifications through the interface typed field
            Staff staff = new Staff("Apu Nahasapeemapetilon");
            staff.AddQualification("Animal care certificate");
            staff.AddQualification("First aid for animals");
            staff.AddQualification("Ten years at the motel");
            // The same qualifications read back through the interface type
            AnimalMotel.Managers.IListManager<string> qualifications = staff.Qualifications;
            Console.WriteLine("Staff qualifications read through IListManager<string>, count = " + qualifications.Count);
            Console.WriteLine(staff.ToString());
            Console.WriteLine();

            // VG part: FoodScheduleDictionary
            FoodScheduleDictionary dictionary = new FoodScheduleDictionary();
            Console.WriteLine("VG Dictionary: FoodScheduleDictionary, count = " + dictionary.Count);
            foreach (string line in dictionary.ToStringList())
                Console.WriteLine(line);
            Console.WriteLine();

            bool addOk = dictionary.Add("Fox", new string[]
            {
                "Morning: one portion of raw meat.",
                "Evening: one portion of raw meat and fresh water."
            });
            Console.WriteLine("Add new key Fox succeeded: " + addOk + ", count = " + dictionary.Count);
            string[] foxSchedule = dictionary.GetItem("Fox");
            Console.WriteLine("GetItem Fox: " + string.Join(" | ", foxSchedule));

            bool changeDictOk = dictionary.Change("Fox", new string[]
            {
                "Morning: cooked chicken and rice.",
                "Evening: cooked chicken and fresh water."
            });
            Console.WriteLine("Change key Fox succeeded: " + changeDictOk);
            Console.WriteLine("GetItem Fox after change: " + string.Join(" | ", dictionary.GetItem("Fox")));

            string[] invalid = dictionary.GetItem("Dragon");
            Console.WriteLine("GetItem with invalid key Dragon returned null: " + (invalid == null));
            bool changeInvalidOk = dictionary.Change("Dragon", new string[] { "Fire" });
            Console.WriteLine("Change with invalid key Dragon succeeded: " + changeInvalidOk);

            bool deleteOk = dictionary.Delete("Fox");
            Console.WriteLine("Delete key Fox succeeded: " + deleteOk + ", count = " + dictionary.Count);
            bool deleteInvalidOk = dictionary.Delete("Fox");
            Console.WriteLine("Delete key Fox again succeeded: " + deleteInvalidOk);
        }
    }
}

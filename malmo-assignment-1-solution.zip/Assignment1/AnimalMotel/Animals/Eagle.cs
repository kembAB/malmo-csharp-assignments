namespace AnimalMotel.Animals
{
    /// <summary>
    /// Species class for an eagle.
    /// An eagle is a bird, so this class inherits from Bird and adds
    /// the beak length as the attribute that is specific for an eagle.
    /// </summary>
    public class Eagle : Bird
    {
        /// <summary>Gets or sets the beak length of the eagle in centimetres.</summary>
        public double BeakLength { get; set; }

        /// <summary>
        /// Initializes a new instance of the Eagle class with default values.
        /// </summary>
        public Eagle()
            : this(string.Empty, 0, GenderType.Unknown, 0.0, 0.0)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Eagle class.
        /// </summary>
        /// <param name="name">The name of the eagle.</param>
        /// <param name="age">The age of the eagle in years.</param>
        /// <param name="gender">The gender of the eagle.</param>
        /// <param name="flyingSpeed">The flying speed of the eagle.</param>
        /// <param name="beakLength">The beak length of the eagle in centimetres.</param>
        public Eagle(string name, int age, GenderType gender, double flyingSpeed, double beakLength)
            : base(name, age, gender, flyingSpeed)
        {
            BeakLength = beakLength;
        }

        /// <summary>
        /// Returns the bird information extended with the species name
        /// and the beak length that is specific for an eagle.
        /// </summary>
        /// <returns>A full information string for the eagle.</returns>
        public override string ToString()
        {
            return base.ToString() + ", Species: Eagle, Beak length: " +
                   BeakLength.ToString("0.##") + " cm";
        }
    }
}

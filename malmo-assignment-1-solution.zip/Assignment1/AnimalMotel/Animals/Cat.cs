namespace AnimalMotel.Animals
{
    /// <summary>
    /// Species class for a cat.
    /// A cat is a mammal, so this class inherits from Mammal and adds
    /// the breed as the attribute that is specific for a cat.
    /// </summary>
    public class Cat : Mammal
    {
        /// <summary>Gets or sets the breed of the cat.</summary>
        public string Breed { get; set; }

        /// <summary>
        /// Initializes a new instance of the Cat class with default values.
        /// </summary>
        public Cat()
            : this(string.Empty, 0, GenderType.Unknown, 0, string.Empty)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Cat class.
        /// </summary>
        /// <param name="name">The name of the cat.</param>
        /// <param name="age">The age of the cat in years.</param>
        /// <param name="gender">The gender of the cat.</param>
        /// <param name="numberOfTeeth">The number of teeth of the cat.</param>
        /// <param name="breed">The breed of the cat.</param>
        public Cat(string name, int age, GenderType gender, int numberOfTeeth, string breed)
            : base(name, age, gender, numberOfTeeth)
        {
            Breed = breed;
        }

        /// <summary>
        /// Returns the mammal information extended with the species name
        /// and the breed that is specific for a cat.
        /// </summary>
        /// <returns>A full information string for the cat.</returns>
        public override string ToString()
        {
            return base.ToString() + ", Species: Cat, Breed: " + Breed;
        }
    }
}

namespace AnimalMotel.Animals
{
    /// <summary>
    /// Base class for every animal that can stay at Apu's Animal Motel.
    /// All data that is general for all animals is declared here, so the
    /// category classes and the species classes only add their own data.
    /// This class is abstract because a plain animal is never created;
    /// only a concrete species object is created in the program.
    /// </summary>
    public abstract class Animal
    {
        /// <summary>
        /// Gets the unique identity of the animal.
        /// The identity is set only by AnimalManager when the animal is
        /// added to the registry, so the setter is internal to this assembly.
        /// </summary>
        public string Id { get; internal set; }

        /// <summary>Gets or sets the name of the animal.</summary>
        public string Name { get; set; }

        /// <summary>Gets or sets the age of the animal in years.</summary>
        public int Age { get; set; }

        /// <summary>Gets or sets the gender of the animal.</summary>
        public GenderType Gender { get; set; }

        /// <summary>
        /// Initializes a new instance of the Animal class with default values.
        /// The identity starts empty and is assigned later by the manager.
        /// </summary>
        protected Animal()
            : this(string.Empty, 0, GenderType.Unknown)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Animal class with the general data.
        /// </summary>
        /// <param name="name">The name of the animal.</param>
        /// <param name="age">The age of the animal in years.</param>
        /// <param name="gender">The gender of the animal.</param>
        protected Animal(string name, int age, GenderType gender)
        {
            Id = string.Empty;
            Name = name;
            Age = age;
            Gender = gender;
        }

        /// <summary>
        /// Returns a text string with the general information about the animal.
        /// Species classes override this method and extend the string with
        /// category data and species data through dynamic binding.
        /// </summary>
        /// <returns>A full information string for the animal.</returns>
        public override string ToString()
        {
            return "Id: " + Id + ", Name: " + Name + ", Age: " + Age +
                   ", Gender: " + Gender;
        }
    }
}

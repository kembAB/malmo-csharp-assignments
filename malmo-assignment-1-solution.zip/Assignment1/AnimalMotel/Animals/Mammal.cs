namespace AnimalMotel.Animals
{
    /// <summary>
    /// Category class for mammals.
    /// A mammal is an animal, so this class inherits from Animal and adds
    /// the data that is common for all mammals in this assignment.
    /// This class is abstract because only a concrete mammal species
    /// such as a dog or a cat is created in the program.
    /// </summary>
    public abstract class Mammal : Animal
    {
        /// <summary>Gets or sets the number of teeth of the mammal.</summary>
        public int NumberOfTeeth { get; set; }

        /// <summary>
        /// Initializes a new instance of the Mammal class with default values.
        /// </summary>
        protected Mammal()
            : this(string.Empty, 0, GenderType.Unknown, 0)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Mammal class.
        /// </summary>
        /// <param name="name">The name of the mammal.</param>
        /// <param name="age">The age of the mammal in years.</param>
        /// <param name="gender">The gender of the mammal.</param>
        /// <param name="numberOfTeeth">The number of teeth of the mammal.</param>
        protected Mammal(string name, int age, GenderType gender, int numberOfTeeth)
            : base(name, age, gender)
        {
            NumberOfTeeth = numberOfTeeth;
        }

        /// <summary>
        /// Returns the general animal information extended with the mammal data.
        /// </summary>
        /// <returns>An information string including the number of teeth.</returns>
        public override string ToString()
        {
            return base.ToString() + ", Category: Mammal, Number of teeth: " + NumberOfTeeth;
        }
    }
}

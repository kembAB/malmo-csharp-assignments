namespace AnimalMotel.Animals
{
    /// <summary>
    /// Category class for birds.
    /// A bird is an animal, so this class inherits from Animal and adds
    /// the data that is common for all birds in this assignment.
    /// This class is abstract because only a concrete bird species
    /// such as a dove or an eagle is created in the program.
    /// </summary>
    public abstract class Bird : Animal
    {
        /// <summary>Gets or sets the flying speed of the bird in kilometres per hour.</summary>
        public double FlyingSpeed { get; set; }

        /// <summary>
        /// Initializes a new instance of the Bird class with default values.
        /// </summary>
        protected Bird()
            : this(string.Empty, 0, GenderType.Unknown, 0.0)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Bird class.
        /// </summary>
        /// <param name="name">The name of the bird.</param>
        /// <param name="age">The age of the bird in years.</param>
        /// <param name="gender">The gender of the bird.</param>
        /// <param name="flyingSpeed">The flying speed of the bird.</param>
        protected Bird(string name, int age, GenderType gender, double flyingSpeed)
            : base(name, age, gender)
        {
            FlyingSpeed = flyingSpeed;
        }

        /// <summary>
        /// Returns the general animal information extended with the bird data.
        /// </summary>
        /// <returns>An information string including the flying speed.</returns>
        public override string ToString()
        {
            return base.ToString() + ", Category: Bird, Flying speed: " +
                   FlyingSpeed.ToString("0.##") + " km/h";
        }
    }
}

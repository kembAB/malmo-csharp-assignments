namespace AnimalMotel.Animals
{
    /// <summary>
    /// Describes the gender of an animal registered at the motel.
    /// The value Unknown is used when the gender has not been determined.
    /// </summary>
    public enum GenderType
    {
        /// <summary>The animal is male.</summary>
        Male,

        /// <summary>The animal is female.</summary>
        Female,

        /// <summary>The gender of the animal is not known.</summary>
        Unknown
    }
}

namespace AnimalMotel.Animals
{
    /// <summary>
    /// Species class for a dove.
    /// A dove is a bird, so this class inherits from Bird and adds
    /// the wing span as the attribute that is specific for a dove.
    /// </summary>
    public class Dove : Bird
    {
        /// <summary>Gets or sets the wing span of the dove in centimetres.</summary>
        public double WingSpan { get; set; }

        /// <summary>
        /// Initializes a new instance of the Dove class with default values.
        /// </summary>
        public Dove()
            : this(string.Empty, 0, GenderType.Unknown, 0.0, 0.0)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Dove class.
        /// </summary>
        /// <param name="name">The name of the dove.</param>
        /// <param name="age">The age of the dove in years.</param>
        /// <param name="gender">The gender of the dove.</param>
        /// <param name="flyingSpeed">The flying speed of the dove.</param>
        /// <param name="wingSpan">The wing span of the dove in centimetres.</param>
        public Dove(string name, int age, GenderType gender, double flyingSpeed, double wingSpan)
            : base(name, age, gender, flyingSpeed)
        {
            WingSpan = wingSpan;
        }

        /// <summary>
        /// Returns the bird information extended with the species name
        /// and the wing span that is specific for a dove.
        /// </summary>
        /// <returns>A full information string for the dove.</returns>
        public override string ToString()
        {
            return base.ToString() + ", Species: Dove, Wing span: " +
                   WingSpan.ToString("0.##") + " cm";
        }
    }
}

namespace AnimalMotel.Animals
{
    /// <summary>
    /// Species class for a dog.
    /// A dog is a mammal, so this class inherits from Mammal and adds
    /// the tail length as the attribute that is specific for a dog.
    /// The information string for a dog is the example used in the
    /// assignment text: name, gender and age come from Animal, the
    /// number of teeth comes from Mammal and the tail length is
    /// defined here in the Dog class.
    /// </summary>
    public class Dog : Mammal
    {
        /// <summary>Gets or sets the tail length of the dog in centimetres.</summary>
        public double TailLength { get; set; }

        /// <summary>
        /// Initializes a new instance of the Dog class with default values.
        /// </summary>
        public Dog()
            : this(string.Empty, 0, GenderType.Unknown, 0, 0.0)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Dog class.
        /// </summary>
        /// <param name="name">The name of the dog.</param>
        /// <param name="age">The age of the dog in years.</param>
        /// <param name="gender">The gender of the dog.</param>
        /// <param name="numberOfTeeth">The number of teeth of the dog.</param>
        /// <param name="tailLength">The tail length of the dog in centimetres.</param>
        public Dog(string name, int age, GenderType gender, int numberOfTeeth, double tailLength)
            : base(name, age, gender, numberOfTeeth)
        {
            TailLength = tailLength;
        }

        /// <summary>
        /// Returns the mammal information extended with the species name
        /// and the tail length that is specific for a dog.
        /// </summary>
        /// <returns>A full information string for the dog.</returns>
        public override string ToString()
        {
            return base.ToString() + ", Species: Dog, Tail length: " +
                   TailLength.ToString("0.##") + " cm";
        }
    }
}

using System;
using System.Windows.Forms;
using AnimalMotel.Forms;

namespace AnimalMotel
{
    /// <summary>
    /// Entry point class for the Animal Motel application.
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// Starts the application and shows the main form.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}

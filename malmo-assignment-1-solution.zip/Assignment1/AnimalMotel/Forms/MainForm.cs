using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using AnimalMotel.Animals;
using AnimalMotel.Managers;

namespace AnimalMotel.Forms
{
    /// <summary>
    /// Main form of Apu's Animal Motel.
    /// This is the only class in the program that handles input and output.
    /// All registry work is delegated to the AnimalManager instance held
    /// by this form, and no other logic is placed in this class beyond
    /// reading the controls, validating the input and updating the display.
    /// </summary>
    public partial class MainForm : Form
    {
        // Registry for all animals added through this form.
        private readonly AnimalManager animalManager;

        /// <summary>
        /// Initializes a new instance of the MainForm class.
        /// Creates the manager and prepares the controls so the form
        /// starts free of design time texts and with sensible selections.
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
            animalManager = new AnimalManager();
            InitializeControls();
        }

        /// <summary>
        /// Fills the selection lists, selects the first entries and clears
        /// every input field so the form starts clean for the user.
        /// </summary>
        private void InitializeControls()
        {
            lstCategory.Items.Clear();
            lstCategory.Items.Add("Mammal");
            lstCategory.Items.Add("Bird");

            cmbGender.Items.Clear();
            cmbGender.Items.Add(GenderType.Male.ToString());
            cmbGender.Items.Add(GenderType.Female.ToString());
            cmbGender.Items.Add(GenderType.Unknown.ToString());
            cmbGender.SelectedIndex = 2;

            txtName.Text = string.Empty;
            txtAge.Text = string.Empty;
            txtCategoryAttribute.Text = string.Empty;
            txtSpeciesAttribute.Text = string.Empty;
            lstAnimals.Items.Clear();

            lstCategory.SelectedIndex = 0;
        }

        /// <summary>
        /// Handles a change of the selected category.
        /// The species list is rebuilt so it always follows the category:
        /// Dog and Cat for Mammal, Dove and Eagle for Bird.
        /// </summary>
        private void lstCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstSpecies.Items.Clear();

            if (GetSelectedCategory() == "Mammal")
            {
                lstSpecies.Items.Add("Dog");
                lstSpecies.Items.Add("Cat");
            }
            else if (GetSelectedCategory() == "Bird")
            {
                lstSpecies.Items.Add("Dove");
                lstSpecies.Items.Add("Eagle");
            }

            if (lstSpecies.Items.Count > 0)
            {
                lstSpecies.SelectedIndex = 0;
            }
        }

        /// <summary>
        /// Handles a change of the selected species.
        /// The two attribute labels change their text so they always name
        /// the category attribute and the species attribute that belong
        /// to the selected species.
        /// </summary>
        private void lstSpecies_SelectedIndexChanged(object sender, EventArgs e)
        {
            string species = GetSelectedSpecies();

            if (species == "Dog")
            {
                lblCategoryAttribute.Text = "Number of teeth:";
                lblSpeciesAttribute.Text = "Tail length in cm:";
            }
            else if (species == "Cat")
            {
                lblCategoryAttribute.Text = "Number of teeth:";
                lblSpeciesAttribute.Text = "Breed:";
            }
            else if (species == "Dove")
            {
                lblCategoryAttribute.Text = "Flying speed in km/h:";
                lblSpeciesAttribute.Text = "Wing span in cm:";
            }
            else if (species == "Eagle")
            {
                lblCategoryAttribute.Text = "Flying speed in km/h:";
                lblSpeciesAttribute.Text = "Beak length in cm:";
            }
        }

        /// <summary>
        /// Handles the Add button.
        /// Validates all input, creates the selected species object through
        /// dynamic binding, adds the object to the manager and refreshes
        /// the list of registered animals.
        /// </summary>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Animal animal = CreateAnimalFromInput();

            if (animal == null)
            {
                // Validation has already informed the user what is wrong.
                return;
            }

            animalManager.AddAnimal(animal);
            UpdateAnimalList();
            ClearInputFields();
        }

        /// <summary>
        /// Reads and validates every input field and creates the object.
        /// Dynamic binding: the reference is declared as the base class
        /// Animal and the concrete species object is assigned to it, so
        /// the manager and the list work with the Animal type while the
        /// real object keeps its species behaviour.
        /// </summary>
        /// <returns>The created animal, or null when any input is invalid.</returns>
        private Animal CreateAnimalFromInput()
        {
            string species = GetSelectedSpecies();

            if (string.IsNullOrEmpty(species))
            {
                ShowValidationMessage("Please select a category and a species first.");
                return null;
            }

            string name = txtName.Text.Trim();

            if (string.IsNullOrWhiteSpace(name))
            {
                ShowValidationMessage("Please enter a name for the animal.");
                txtName.Focus();
                return null;
            }

            int age;

            if (!int.TryParse(txtAge.Text.Trim(), out age) || age < 0)
            {
                ShowValidationMessage("Please enter the age as a whole number that is zero or higher.");
                txtAge.Focus();
                return null;
            }

            GenderType gender = GetSelectedGender();

            // The species decides how the two attribute fields are read.
            if (species == "Dog")
            {
                int numberOfTeeth;
                double tailLength;

                if (!TryReadWholeNumber(txtCategoryAttribute, "number of teeth", out numberOfTeeth))
                {
                    return null;
                }

                if (!TryReadDecimalNumber(txtSpeciesAttribute, "tail length", out tailLength))
                {
                    return null;
                }

                Animal dog = new Dog(name, age, gender, numberOfTeeth, tailLength);
                return dog;
            }

            if (species == "Cat")
            {
                int numberOfTeeth;
                string breed = txtSpeciesAttribute.Text.Trim();

                if (!TryReadWholeNumber(txtCategoryAttribute, "number of teeth", out numberOfTeeth))
                {
                    return null;
                }

                if (string.IsNullOrWhiteSpace(breed))
                {
                    ShowValidationMessage("Please enter the breed of the cat.");
                    txtSpeciesAttribute.Focus();
                    return null;
                }

                Animal cat = new Cat(name, age, gender, numberOfTeeth, breed);
                return cat;
            }

            if (species == "Dove")
            {
                double flyingSpeed;
                double wingSpan;

                if (!TryReadDecimalNumber(txtCategoryAttribute, "flying speed", out flyingSpeed))
                {
                    return null;
                }

                if (!TryReadDecimalNumber(txtSpeciesAttribute, "wing span", out wingSpan))
                {
                    return null;
                }

                Animal dove = new Dove(name, age, gender, flyingSpeed, wingSpan);
                return dove;
            }

            if (species == "Eagle")
            {
                double flyingSpeed;
                double beakLength;

                if (!TryReadDecimalNumber(txtCategoryAttribute, "flying speed", out flyingSpeed))
                {
                    return null;
                }

                if (!TryReadDecimalNumber(txtSpeciesAttribute, "beak length", out beakLength))
                {
                    return null;
                }

                Animal eagle = new Eagle(name, age, gender, flyingSpeed, beakLength);
                return eagle;
            }

            ShowValidationMessage("The selected species is not supported.");
            return null;
        }

        /// <summary>
        /// VG part for grade B: handles the List all animals check box.
        /// When the box is checked, every registered animal is listed and
        /// the category controls together with the input controls are
        /// disabled and grayed. When the box is unchecked, the controls
        /// are enabled again and normal input resumes.
        /// </summary>
        private void chkListAllAnimals_CheckedChanged(object sender, EventArgs e)
        {
            bool listAll = chkListAllAnimals.Checked;

            // Gray out the selection and input controls while listing all.
            grpCategory.Enabled = !listAll;
            grpAnimalData.Enabled = !listAll;
            btnAdd.Enabled = !listAll;

            if (listAll)
            {
                UpdateAnimalList();
            }
            else
            {
                UpdateAnimalList();
            }
        }

        /// <summary>
        /// VG part for grade A: handles the Load image button.
        /// Lets the user browse to an image file with an OpenFileDialog
        /// and loads the chosen image for the selected animal into the
        /// picture box. The image is shown only and is never saved.
        /// </summary>
        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            if (lstAnimals.SelectedIndex < 0)
            {
                ShowValidationMessage("Please select an animal in the list before loading an image.");
                return;
            }

            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Select an image for the animal";
                dialog.Filter = "Image files|*.jpg;*.jpeg;*.png;*.bmp;*.gif|All files|*.*";

                if (dialog.ShowDialog() != DialogResult.OK)
                {
                    return;
                }

                try
                {
                    // Load through a stream so the file itself is not locked.
                    byte[] imageBytes = File.ReadAllBytes(dialog.FileName);

                    using (MemoryStream stream = new MemoryStream(imageBytes))
                    {
                        Image loadedImage = Image.FromStream(stream);
                        Image previousImage = picAnimal.Image;
                        picAnimal.Image = new Bitmap(loadedImage);

                        if (previousImage != null)
                        {
                            previousImage.Dispose();
                        }
                    }
                }
                catch (Exception)
                {
                    ShowValidationMessage("The selected file could not be loaded as an image.");
                }
            }
        }

        /// <summary>
        /// Refreshes the list of registered animals from the manager.
        /// The display strings come from the string array method of the
        /// manager, so every row is the ToString value of one animal.
        /// </summary>
        private void UpdateAnimalList()
        {
            lstAnimals.Items.Clear();

            string[] infoArray = animalManager.GetAnimalInfoArray();

            foreach (string info in infoArray)
            {
                lstAnimals.Items.Add(info);
            }
        }

        /// <summary>
        /// Clears the input fields after a successful registration while
        /// keeping the current category, species and gender selections.
        /// </summary>
        private void ClearInputFields()
        {
            txtName.Text = string.Empty;
            txtAge.Text = string.Empty;
            txtCategoryAttribute.Text = string.Empty;
            txtSpeciesAttribute.Text = string.Empty;
            txtName.Focus();
        }

        /// <summary>
        /// Returns the name of the currently selected category.
        /// </summary>
        /// <returns>The category name, or an empty string when nothing is selected.</returns>
        private string GetSelectedCategory()
        {
            if (lstCategory.SelectedItem == null)
            {
                return string.Empty;
            }

            return lstCategory.SelectedItem.ToString();
        }

        /// <summary>
        /// Returns the name of the currently selected species.
        /// </summary>
        /// <returns>The species name, or an empty string when nothing is selected.</returns>
        private string GetSelectedSpecies()
        {
            if (lstSpecies.SelectedItem == null)
            {
                return string.Empty;
            }

            return lstSpecies.SelectedItem.ToString();
        }

        /// <summary>
        /// Returns the gender chosen in the gender combo box.
        /// A missing or unknown text safely falls back to Unknown.
        /// </summary>
        /// <returns>The selected gender value.</returns>
        private GenderType GetSelectedGender()
        {
            GenderType gender;

            if (cmbGender.SelectedItem != null &&
                Enum.TryParse(cmbGender.SelectedItem.ToString(), out gender))
            {
                return gender;
            }

            return GenderType.Unknown;
        }

        /// <summary>
        /// Safely reads a whole number from a text box.
        /// </summary>
        /// <param name="textBox">The text box to read.</param>
        /// <param name="fieldName">The name of the field used in the message.</param>
        /// <param name="value">The parsed value when the read succeeds.</param>
        /// <returns>True when the text is a whole number that is zero or higher.</returns>
        private bool TryReadWholeNumber(TextBox textBox, string fieldName, out int value)
        {
            if (!int.TryParse(textBox.Text.Trim(), out value) || value < 0)
            {
                ShowValidationMessage("Please enter the " + fieldName + " as a whole number that is zero or higher.");
                textBox.Focus();
                return false;
            }

            return true;
        }

        /// <summary>
        /// Safely reads a decimal number from a text box.
        /// Both a point and a comma are accepted as the decimal separator
        /// by first trying the current culture and then invariant culture.
        /// </summary>
        /// <param name="textBox">The text box to read.</param>
        /// <param name="fieldName">The name of the field used in the message.</param>
        /// <param name="value">The parsed value when the read succeeds.</param>
        /// <returns>True when the text is a number that is zero or higher.</returns>
        private bool TryReadDecimalNumber(TextBox textBox, string fieldName, out double value)
        {
            string text = textBox.Text.Trim();

            bool parsed = double.TryParse(text, NumberStyles.Number,
                              CultureInfo.CurrentCulture, out value) ||
                          double.TryParse(text, NumberStyles.Number,
                              CultureInfo.InvariantCulture, out value);

            if (!parsed || value < 0)
            {
                value = 0.0;
                ShowValidationMessage("Please enter the " + fieldName + " as a number that is zero or higher.");
                textBox.Focus();
                return false;
            }

            return true;
        }

        /// <summary>
        /// Shows a validation message to the user without crashing the program.
        /// </summary>
        /// <param name="message">The message to show.</param>
        private void ShowValidationMessage(string message)
        {
            MessageBox.Show(message, "Animal Motel",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

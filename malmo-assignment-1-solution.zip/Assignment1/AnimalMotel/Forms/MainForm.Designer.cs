namespace AnimalMotel.Forms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Cleans up any resources being used.
        /// </summary>
        /// <param name="disposing">True when managed resources should be disposed.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support.
        /// All controls are created here with meaningful texts only, so the
        /// form contains no design time placeholder texts at program start.
        /// The lists and input fields start empty and are filled in code.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpCategory = new System.Windows.Forms.GroupBox();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lstCategory = new System.Windows.Forms.ListBox();
            this.lblSpecies = new System.Windows.Forms.Label();
            this.lstSpecies = new System.Windows.Forms.ListBox();
            this.grpAnimalData = new System.Windows.Forms.GroupBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblAge = new System.Windows.Forms.Label();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.lblGender = new System.Windows.Forms.Label();
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.lblCategoryAttribute = new System.Windows.Forms.Label();
            this.txtCategoryAttribute = new System.Windows.Forms.TextBox();
            this.lblSpeciesAttribute = new System.Windows.Forms.Label();
            this.txtSpeciesAttribute = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.chkListAllAnimals = new System.Windows.Forms.CheckBox();
            this.lblAnimals = new System.Windows.Forms.Label();
            this.lstAnimals = new System.Windows.Forms.ListBox();
            this.btnLoadImage = new System.Windows.Forms.Button();
            this.picAnimal = new System.Windows.Forms.PictureBox();
            this.grpCategory.SuspendLayout();
            this.grpAnimalData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAnimal)).BeginInit();
            this.SuspendLayout();
            //
            // grpCategory
            //
            this.grpCategory.Controls.Add(this.lblCategory);
            this.grpCategory.Controls.Add(this.lstCategory);
            this.grpCategory.Controls.Add(this.lblSpecies);
            this.grpCategory.Controls.Add(this.lstSpecies);
            this.grpCategory.Location = new System.Drawing.Point(12, 12);
            this.grpCategory.Name = "grpCategory";
            this.grpCategory.Size = new System.Drawing.Size(300, 190);
            this.grpCategory.TabIndex = 0;
            this.grpCategory.TabStop = false;
            this.grpCategory.Text = "Category and species";
            //
            // lblCategory
            //
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(6, 22);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(52, 15);
            this.lblCategory.TabIndex = 0;
            this.lblCategory.Text = "Category:";
            //
            // lstCategory
            //
            this.lstCategory.FormattingEnabled = true;
            this.lstCategory.ItemHeight = 15;
            this.lstCategory.Location = new System.Drawing.Point(6, 42);
            this.lstCategory.Name = "lstCategory";
            this.lstCategory.Size = new System.Drawing.Size(135, 139);
            this.lstCategory.TabIndex = 1;
            this.lstCategory.SelectedIndexChanged += new System.EventHandler(this.lstCategory_SelectedIndexChanged);
            //
            // lblSpecies
            //
            this.lblSpecies.AutoSize = true;
            this.lblSpecies.Location = new System.Drawing.Point(155, 22);
            this.lblSpecies.Name = "lblSpecies";
            this.lblSpecies.Size = new System.Drawing.Size(49, 15);
            this.lblSpecies.TabIndex = 2;
            this.lblSpecies.Text = "Species:";
            //
            // lstSpecies
            //
            this.lstSpecies.FormattingEnabled = true;
            this.lstSpecies.ItemHeight = 15;
            this.lstSpecies.Location = new System.Drawing.Point(155, 42);
            this.lstSpecies.Name = "lstSpecies";
            this.lstSpecies.Size = new System.Drawing.Size(135, 139);
            this.lstSpecies.TabIndex = 3;
            this.lstSpecies.SelectedIndexChanged += new System.EventHandler(this.lstSpecies_SelectedIndexChanged);
            //
            // grpAnimalData
            //
            this.grpAnimalData.Controls.Add(this.lblName);
            this.grpAnimalData.Controls.Add(this.txtName);
            this.grpAnimalData.Controls.Add(this.lblAge);
            this.grpAnimalData.Controls.Add(this.txtAge);
            this.grpAnimalData.Controls.Add(this.lblGender);
            this.grpAnimalData.Controls.Add(this.cmbGender);
            this.grpAnimalData.Controls.Add(this.lblCategoryAttribute);
            this.grpAnimalData.Controls.Add(this.txtCategoryAttribute);
            this.grpAnimalData.Controls.Add(this.lblSpeciesAttribute);
            this.grpAnimalData.Controls.Add(this.txtSpeciesAttribute);
            this.grpAnimalData.Location = new System.Drawing.Point(330, 12);
            this.grpAnimalData.Name = "grpAnimalData";
            this.grpAnimalData.Size = new System.Drawing.Size(330, 190);
            this.grpAnimalData.TabIndex = 1;
            this.grpAnimalData.TabStop = false;
            this.grpAnimalData.Text = "Animal data";
            //
            // lblName
            //
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(6, 25);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(42, 15);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name:";
            //
            // txtName
            //
            this.txtName.Location = new System.Drawing.Point(150, 22);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(170, 23);
            this.txtName.TabIndex = 1;
            //
            // lblAge
            //
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(6, 54);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(31, 15);
            this.lblAge.TabIndex = 2;
            this.lblAge.Text = "Age:";
            //
            // txtAge
            //
            this.txtAge.Location = new System.Drawing.Point(150, 51);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(170, 23);
            this.txtAge.TabIndex = 3;
            //
            // lblGender
            //
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(6, 83);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(48, 15);
            this.lblGender.TabIndex = 4;
            this.lblGender.Text = "Gender:";
            //
            // cmbGender
            //
            this.cmbGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.Location = new System.Drawing.Point(150, 80);
            this.cmbGender.Name = "cmbGender";
            this.cmbGender.Size = new System.Drawing.Size(170, 23);
            this.cmbGender.TabIndex = 5;
            //
            // lblCategoryAttribute
            //
            this.lblCategoryAttribute.AutoSize = true;
            this.lblCategoryAttribute.Location = new System.Drawing.Point(6, 112);
            this.lblCategoryAttribute.Name = "lblCategoryAttribute";
            this.lblCategoryAttribute.Size = new System.Drawing.Size(100, 15);
            this.lblCategoryAttribute.TabIndex = 6;
            this.lblCategoryAttribute.Text = "Number of teeth:";
            //
            // txtCategoryAttribute
            //
            this.txtCategoryAttribute.Location = new System.Drawing.Point(150, 109);
            this.txtCategoryAttribute.Name = "txtCategoryAttribute";
            this.txtCategoryAttribute.Size = new System.Drawing.Size(170, 23);
            this.txtCategoryAttribute.TabIndex = 7;
            //
            // lblSpeciesAttribute
            //
            this.lblSpeciesAttribute.AutoSize = true;
            this.lblSpeciesAttribute.Location = new System.Drawing.Point(6, 141);
            this.lblSpeciesAttribute.Name = "lblSpeciesAttribute";
            this.lblSpeciesAttribute.Size = new System.Drawing.Size(88, 15);
            this.lblSpeciesAttribute.TabIndex = 8;
            this.lblSpeciesAttribute.Text = "Tail length in cm:";
            //
            // txtSpeciesAttribute
            //
            this.txtSpeciesAttribute.Location = new System.Drawing.Point(150, 138);
            this.txtSpeciesAttribute.Name = "txtSpeciesAttribute";
            this.txtSpeciesAttribute.Size = new System.Drawing.Size(170, 23);
            this.txtSpeciesAttribute.TabIndex = 9;
            //
            // btnAdd
            //
            this.btnAdd.Location = new System.Drawing.Point(330, 208);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(160, 28);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Add animal";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            //
            // chkListAllAnimals
            //
            this.chkListAllAnimals.AutoSize = true;
            this.chkListAllAnimals.Location = new System.Drawing.Point(12, 212);
            this.chkListAllAnimals.Name = "chkListAllAnimals";
            this.chkListAllAnimals.Size = new System.Drawing.Size(110, 19);
            this.chkListAllAnimals.TabIndex = 3;
            this.chkListAllAnimals.Text = "List all animals";
            this.chkListAllAnimals.UseVisualStyleBackColor = true;
            this.chkListAllAnimals.CheckedChanged += new System.EventHandler(this.chkListAllAnimals_CheckedChanged);
            //
            // lblAnimals
            //
            this.lblAnimals.AutoSize = true;
            this.lblAnimals.Location = new System.Drawing.Point(12, 245);
            this.lblAnimals.Name = "lblAnimals";
            this.lblAnimals.Size = new System.Drawing.Size(114, 15);
            this.lblAnimals.TabIndex = 4;
            this.lblAnimals.Text = "Registered animals:";
            //
            // lstAnimals
            //
            this.lstAnimals.FormattingEnabled = true;
            this.lstAnimals.HorizontalScrollbar = true;
            this.lstAnimals.ItemHeight = 15;
            this.lstAnimals.Location = new System.Drawing.Point(12, 265);
            this.lstAnimals.Name = "lstAnimals";
            this.lstAnimals.Size = new System.Drawing.Size(648, 169);
            this.lstAnimals.TabIndex = 5;
            //
            // btnLoadImage
            //
            this.btnLoadImage.Location = new System.Drawing.Point(680, 208);
            this.btnLoadImage.Name = "btnLoadImage";
            this.btnLoadImage.Size = new System.Drawing.Size(160, 28);
            this.btnLoadImage.TabIndex = 6;
            this.btnLoadImage.Text = "Load image...";
            this.btnLoadImage.UseVisualStyleBackColor = true;
            this.btnLoadImage.Click += new System.EventHandler(this.btnLoadImage_Click);
            //
            // picAnimal
            //
            this.picAnimal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picAnimal.Location = new System.Drawing.Point(680, 12);
            this.picAnimal.Name = "picAnimal";
            this.picAnimal.Size = new System.Drawing.Size(160, 190);
            this.picAnimal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picAnimal.TabIndex = 7;
            this.picAnimal.TabStop = false;
            //
            // MainForm
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(854, 446);
            this.Controls.Add(this.grpCategory);
            this.Controls.Add(this.grpAnimalData);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.chkListAllAnimals);
            this.Controls.Add(this.lblAnimals);
            this.Controls.Add(this.lstAnimals);
            this.Controls.Add(this.btnLoadImage);
            this.Controls.Add(this.picAnimal);
            this.Name = "MainForm";
            this.Text = "Apu's Animal Motel - Version 1";
            this.grpCategory.ResumeLayout(false);
            this.grpCategory.PerformLayout();
            this.grpAnimalData.ResumeLayout(false);
            this.grpAnimalData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAnimal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.GroupBox grpCategory;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.ListBox lstCategory;
        private System.Windows.Forms.Label lblSpecies;
        private System.Windows.Forms.ListBox lstSpecies;
        private System.Windows.Forms.GroupBox grpAnimalData;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.ComboBox cmbGender;
        private System.Windows.Forms.Label lblCategoryAttribute;
        private System.Windows.Forms.TextBox txtCategoryAttribute;
        private System.Windows.Forms.Label lblSpeciesAttribute;
        private System.Windows.Forms.TextBox txtSpeciesAttribute;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.CheckBox chkListAllAnimals;
        private System.Windows.Forms.Label lblAnimals;
        private System.Windows.Forms.ListBox lstAnimals;
        private System.Windows.Forms.Button btnLoadImage;
        private System.Windows.Forms.PictureBox picAnimal;
    }
}

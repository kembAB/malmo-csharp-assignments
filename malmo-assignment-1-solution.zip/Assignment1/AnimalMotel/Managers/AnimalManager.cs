using System.Collections.Generic;
using AnimalMotel.Animals;

namespace AnimalMotel.Managers
{
    /// <summary>
    /// Registry class for all animals staying at the motel.
    /// The class owns the list of animals and the counter that is used
    /// to generate a unique identity for every new animal.
    /// Both fields are strict private: no public property and no public
    /// method in this class exposes the list itself or the counter itself.
    /// Callers work with one animal at a time or with a copy of the
    /// information strings, never with the list object.
    /// </summary>
    public class AnimalManager
    {
        // The registry itself. Strict private by assignment requirement 3.6.
        private readonly List<Animal> animalList;

        // Counter for generating unique identities. Strict private by
        // assignment requirement 3.5. The first generated identity uses 1.
        private int idCounter;

        /// <summary>
        /// Initializes a new instance of the AnimalManager class.
        /// The registry starts empty and the identity counter starts at zero.
        /// </summary>
        public AnimalManager()
        {
            animalList = new List<Animal>();
            idCounter = 0;
        }

        /// <summary>
        /// Gets the number of animals currently registered in the motel.
        /// Only the count is exposed, never the list itself.
        /// </summary>
        public int Count
        {
            get { return animalList.Count; }
        }

        /// <summary>
        /// Adds a new animal to the registry and assigns the animal a
        /// unique generated identity before the animal is stored.
        /// </summary>
        /// <param name="animal">The animal object to add.</param>
        /// <returns>True when the animal was added, false when the reference was null.</returns>
        public bool AddAnimal(Animal animal)
        {
            // A null reference carries no data and is refused without an error.
            if (animal == null)
            {
                return false;
            }

            // Generate the next unique identity inside the manager only.
            idCounter++;
            animal.Id = "ANM-" + idCounter.ToString("000");

            animalList.Add(animal);
            return true;
        }

        /// <summary>
        /// Returns the animal stored at the given position in the registry.
        /// </summary>
        /// <param name="index">The zero based position in the registry.</param>
        /// <returns>The animal at the position, or null when the index is out of range.</returns>
        public Animal GetAnimalAt(int index)
        {
            // Guard against indexes that do not exist so callers never crash.
            if (index < 0 || index >= animalList.Count)
            {
                return null;
            }

            return animalList[index];
        }

        /// <summary>
        /// Builds an array holding the information string of every animal.
        /// Each string comes from the ToString method of the concrete
        /// species through dynamic binding, so category data and species
        /// data are included for every animal.
        /// </summary>
        /// <returns>A string array with one information string per animal.</returns>
        public string[] GetAnimalInfoArray()
        {
            string[] infoArray = new string[animalList.Count];

            for (int index = 0; index < animalList.Count; index++)
            {
                infoArray[index] = animalList[index].ToString();
            }

            return infoArray;
        }
    }
}

using System;
using AnimalMotel.Animals;
using AnimalMotel.Managers;

namespace Harness
{
    /// <summary>
    /// Console test harness for the Animal Motel model and manager.
    /// This program is not part of the submitted Windows Forms application.
    /// It links the same animal and manager source files, creates one
    /// animal of each species through a base class Animal reference to
    /// show dynamic binding, and prints the results from the manager.
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// Creates the test animals, registers them and prints the results.
        /// </summary>
        private static void Main()
        {
            Console.WriteLine("Apu's Animal Motel - Harness Test");
            Console.WriteLine("=================================");

            AnimalManager manager = new AnimalManager();

            // Dynamic binding: each reference is declared as Animal and
            // each concrete species object is assigned to that reference.
            Animal dog = new Dog("Buddy", 4, GenderType.Male, 42, 28.5);
            Animal cat = new Cat("Misty", 3, GenderType.Female, 30, "Siamese");
            Animal dove = new Dove("Pearly", 2, GenderType.Female, 55.0, 62.0);
            Animal eagle = new Eagle("Aquila", 6, GenderType.Male, 120.0, 5.5);

            manager.AddAnimal(dog);
            manager.AddAnimal(cat);
            manager.AddAnimal(dove);
            manager.AddAnimal(eagle);

            Console.WriteLine("Count: " + manager.Count);
            Console.WriteLine();
            Console.WriteLine("All animals from GetAnimalInfoArray:");

            string[] infoArray = manager.GetAnimalInfoArray();

            foreach (string info in infoArray)
            {
                Console.WriteLine(info);
            }

            Console.WriteLine();
            Console.WriteLine("Animal at index 1 from GetAnimalAt:");

            Animal fetched = manager.GetAnimalAt(1);

            if (fetched != null)
            {
                Console.WriteLine(fetched.ToString());
            }
            else
            {
                Console.WriteLine("No animal found at index 1.");
            }
        }
    }
}
